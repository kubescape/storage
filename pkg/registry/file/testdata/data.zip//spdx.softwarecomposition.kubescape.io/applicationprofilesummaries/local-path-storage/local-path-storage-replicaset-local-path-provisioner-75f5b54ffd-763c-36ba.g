{
  "name": "local-path-storage-replicaset-local-path-provisioner-75f5b54ffd-763c-36ba",
  "namespace": "local-path-storage",
  "uid": "4b26b9d2-4a49-4358-8ccd-d0e3c1852d9a",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-05T15:28:37Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "Deployment",
    "kubescape.io/workload-name": "local-path-provisioner",
    "kubescape.io/workload-namespace": "local-path-storage",
    "kubescape.io/workload-resource-version": "582352"
  },
  "annotations": {
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-local-path-storage/deployment-local-path-provisioner"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-05T15:28:37Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        }
      }
    }
  ]
}