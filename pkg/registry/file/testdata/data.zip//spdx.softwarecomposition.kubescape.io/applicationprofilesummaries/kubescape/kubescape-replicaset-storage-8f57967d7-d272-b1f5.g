{
  "name": "kubescape-replicaset-storage-8f57967d7-d272-b1f5",
  "namespace": "kubescape",
  "uid": "d4ccad33-a2d4-4e8c-b0dd-f509a40434f0",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-05T15:35:49Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "Deployment",
    "kubescape.io/workload-name": "storage",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "583796"
  },
  "annotations": {
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-storage"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-05T15:35:49Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        }
      }
    }
  ]
}