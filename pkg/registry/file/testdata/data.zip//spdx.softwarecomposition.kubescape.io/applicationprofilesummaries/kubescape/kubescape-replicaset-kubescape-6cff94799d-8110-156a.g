{
  "name": "kubescape-replicaset-kubescape-6cff94799d-8110-156a",
  "namespace": "kubescape",
  "uid": "47be5586-3836-4552-afca-173d70c4e664",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-05T15:29:17Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "Deployment",
    "kubescape.io/workload-name": "kubescape",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "584235"
  },
  "annotations": {
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-kubescape"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-05T15:29:17Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        }
      }
    }
  ]
}