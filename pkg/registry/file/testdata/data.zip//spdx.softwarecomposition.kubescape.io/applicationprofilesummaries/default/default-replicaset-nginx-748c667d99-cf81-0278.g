{
  "name": "default-replicaset-nginx-748c667d99-cf81-0278",
  "namespace": "default",
  "uid": "840b2bb1-f3ff-491f-baf9-e6287cd80669",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-05T15:28:53Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "Deployment",
    "kubescape.io/workload-name": "nginx",
    "kubescape.io/workload-namespace": "default",
    "kubescape.io/workload-resource-version": "584084"
  },
  "annotations": {
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-default/deployment-nginx"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-05T15:28:53Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        }
      }
    }
  ]
}