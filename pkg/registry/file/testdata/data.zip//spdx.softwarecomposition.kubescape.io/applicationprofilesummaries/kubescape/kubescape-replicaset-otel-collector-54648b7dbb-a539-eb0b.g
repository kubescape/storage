{
  "name": "kubescape-replicaset-otel-collector-54648b7dbb-a539-eb0b",
  "namespace": "kubescape",
  "uid": "e1ea3fc2-cb70-4bcb-b08a-4ccd78c8350b",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-05T15:29:23Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "Deployment",
    "kubescape.io/workload-name": "otel-collector",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "584266"
  },
  "annotations": {
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-otel-collector"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-05T15:29:23Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        }
      }
    }
  ]
}