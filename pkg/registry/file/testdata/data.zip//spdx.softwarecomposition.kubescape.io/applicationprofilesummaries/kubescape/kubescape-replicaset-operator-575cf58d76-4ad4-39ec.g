{
  "name": "kubescape-replicaset-operator-575cf58d76-4ad4-39ec",
  "namespace": "kubescape",
  "uid": "0b7b9f56-6d69-4572-b499-a24bb16cd7f4",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-05T15:29:22Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "Deployment",
    "kubescape.io/workload-name": "operator",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "584310"
  },
  "annotations": {
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-operator"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-05T15:29:22Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        }
      }
    }
  ]
}