{
  "name": "gadget-daemonset-gadget-0d7c-fd3c",
  "namespace": "gadget",
  "uid": "060f077e-4753-4247-8887-268a9edf5281",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-05T15:39:01Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "DaemonSet",
    "kubescape.io/workload-name": "gadget",
    "kubescape.io/workload-namespace": "gadget",
    "kubescape.io/workload-resource-version": "584112"
  },
  "annotations": {
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-gadget/daemonset-gadget"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-05T15:39:01Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        }
      }
    }
  ]
}