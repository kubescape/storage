{
  "name": "kubescape-replicaset-operator-5b99d66db7-3195-f368",
  "namespace": "kubescape",
  "uid": "d24725e6-2c40-4f48-bc60-98073ada122e",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:46:05Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-container-name": "operator",
    "kubescape.io/workload-kind": "Deployment",
    "kubescape.io/workload-name": "operator",
    "kubescape.io/workload-namespace": "kubescape"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/kubescape/operator@sha256:e38b22d522bf1d622c56efc04e6aac6982a8307ccc0c59951652a63bd6dc38da",
    "kubescape.io/instance-id": "apiVersion-apps/v1/namespace-kubescape/kind-ReplicaSet/name-operator-5b99d66db7/containerName-operator",
    "kubescape.io/status": "",
    "kubescape.io/wlid": "wlid://cluster-gke_elated-pottery-310110_us-central1-c_cluster-1/namespace-kubescape/deployment-operator",
    "kubescape.io/workload-container-name": "operator"
  },
  "Spec": {
    "Metadata": {
      "Tool": {
        "Name": "",
        "Version": "v0.76.0"
      },
      "Report": {
        "CreatedAt": null
      }
    },
    "SPDX": {
      "DocumentDescribes": null,
      "SPDXVersion": "SPDX-2.3",
      "DataLicense": "CC0-1.0",
      "SPDXIdentifier": "SPDXRef-DOCUMENT",
      "DocumentName": "quay.io/kubescape/operator@sha256:e38b22d522bf1d622c56efc04e6aac6982a8307ccc0c59951652a63bd6dc38da",
      "DocumentNamespace": "https://anchore.com/syft/image/quay.io/kubescape/operator@sha256-e38b22d522bf1d622c56efc04e6aac6982a8307ccc0c59951652a63bd6dc38da-81191701-a1b9-44b3-a5fb-d49d64a5383e",
      "ExternalDocumentReferences": null,
      "DocumentComment": "",
      "CreationInfo": {
        "LicenseListVersion": "3.20",
        "Creators": [
          "Organization: Anchore, Inc",
          "Tool: syft-v0.76.0",
          "Organization: Kubescape",
          "Tool: KubescapeNodeAgent"
        ],
        "Created": "2023-11-29T12:45:06Z",
        "CreatorComment": ""
      },
      "Packages": [],
      "Files": null,
      "OtherLicenses": [
        {
          "LicenseIdentifier": "LicenseRef-GPL",
          "ExtractedText": "NONE",
          "LicenseName": "GPL",
          "LicenseCrossReferences": null,
          "LicenseComment": ""
        }
      ],
      "Relationships": [
        {
          "RefA": "SPDXRef-DOCUMENT",
          "RefB": "SPDXRef-DOCUMENT",
          "Relationship": "DESCRIBES",
          "RelationshipComment": ""
        }
      ],
      "Annotations": null,
      "Snippets": null,
      "Reviews": null
    }
  },
  "Status": {}
}