{
  "name": "gke.gcr.io-prometheus-engine-alertmanager-v0.25.1-gmp.0-gke.1-sha256-927b106154a88f2c26fe68bd00fe96605564e4c654c71fa14b69b3d359fb8625-fb8625",
  "namespace": "kubescape",
  "uid": "ae3ec594-5273-4ed2-9a6f-5cb4a9dd6cc1",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:48Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-prometheus-engine-alertmanager-sha256-927b106154a88f",
    "kubescape.io/image-name": "gke-gcr-io-prometheus-engine-alertmanager"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/prometheus-engine/alertmanager@sha256:927b106154a88f2c26fe68bd00fe96605564e4c654c71fa14b69b3d359fb8625",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:44:48Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}