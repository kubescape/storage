{
  "name": "gke.gcr.io-k8s-dns-kube-dns-1.22.22-gke.0-sha256-76dcedf9b475902042f9ee22609e475fca96e29880315e9530a694bdd924897e-24897e",
  "namespace": "kubescape",
  "uid": "bdbe939c-7af1-4c5c-87c8-d7b47a63b041",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:17Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-k8s-dns-kube-dns-sha256-76dcedf9b475902042f9ee22609e",
    "kubescape.io/image-name": "gke-gcr-io-k8s-dns-kube-dns"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/k8s-dns-kube-dns@sha256:76dcedf9b475902042f9ee22609e475fca96e29880315e9530a694bdd924897e",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:17Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}