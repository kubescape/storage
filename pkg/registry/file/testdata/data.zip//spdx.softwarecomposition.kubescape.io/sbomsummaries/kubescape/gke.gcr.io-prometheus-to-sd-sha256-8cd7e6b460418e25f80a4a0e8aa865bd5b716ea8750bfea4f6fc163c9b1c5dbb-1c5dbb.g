{
  "name": "gke.gcr.io-prometheus-to-sd-sha256-8cd7e6b460418e25f80a4a0e8aa865bd5b716ea8750bfea4f6fc163c9b1c5dbb-1c5dbb",
  "namespace": "kubescape",
  "uid": "317f7bc6-b8b1-4f00-b7fc-9747f2f704cd",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:00Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-prometheus-to-sd-sha256-8cd7e6b460418e25f80a4a0e8aa8",
    "kubescape.io/image-name": "gke-gcr-io-prometheus-to-sd"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/prometheus-to-sd@sha256:8cd7e6b460418e25f80a4a0e8aa865bd5b716ea8750bfea4f6fc163c9b1c5dbb",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:00Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}