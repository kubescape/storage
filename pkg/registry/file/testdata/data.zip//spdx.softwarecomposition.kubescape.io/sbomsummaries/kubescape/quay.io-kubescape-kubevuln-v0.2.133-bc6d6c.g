{
  "name": "quay.io-kubescape-kubevuln-v0.2.133-bc6d6c",
  "namespace": "kubescape",
  "uid": "fa27ee12-cc19-468a-be80-7c9a81128aed",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:33Z",
  "labels": {
    "kubescape.io/image-id": "quay-io-kubescape-kubevuln-sha256-6a88bfbe387e9260596aa21c49c0b",
    "kubescape.io/image-name": "quay-io-kubescape-kubevuln"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/kubescape/kubevuln@sha256:6a88bfbe387e9260596aa21c49c0b835589777443141ba4154787ceeb5bc6d6c",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:33Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}