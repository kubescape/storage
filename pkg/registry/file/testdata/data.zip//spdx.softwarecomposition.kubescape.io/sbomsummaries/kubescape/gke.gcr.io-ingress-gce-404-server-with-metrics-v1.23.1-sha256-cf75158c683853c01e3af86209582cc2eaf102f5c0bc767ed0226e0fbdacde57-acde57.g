{
  "name": "gke.gcr.io-ingress-gce-404-server-with-metrics-v1.23.1-sha256-cf75158c683853c01e3af86209582cc2eaf102f5c0bc767ed0226e0fbdacde57-acde57",
  "namespace": "kubescape",
  "uid": "e6202815-4440-4378-ac30-a36da4db670e",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:47Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-ingress-gce-404-server-with-metrics-sha256-cf75158c6",
    "kubescape.io/image-name": "gke-gcr-io-ingress-gce-404-server-with-metrics"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/ingress-gce-404-server-with-metrics@sha256:cf75158c683853c01e3af86209582cc2eaf102f5c0bc767ed0226e0fbdacde57",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:47Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}