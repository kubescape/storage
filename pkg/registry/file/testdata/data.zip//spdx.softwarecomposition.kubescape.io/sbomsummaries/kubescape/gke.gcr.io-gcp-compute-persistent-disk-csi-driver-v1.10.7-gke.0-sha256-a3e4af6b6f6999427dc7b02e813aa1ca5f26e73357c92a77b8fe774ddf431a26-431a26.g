{
  "name": "gke.gcr.io-gcp-compute-persistent-disk-csi-driver-v1.10.7-gke.0-sha256-a3e4af6b6f6999427dc7b02e813aa1ca5f26e73357c92a77b8fe774ddf431a26-431a26",
  "namespace": "kubescape",
  "uid": "4b2d67cb-2ac7-4b90-85c9-43e388c04e16",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:56Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-gcp-compute-persistent-disk-csi-driver-sha256-a3e4af",
    "kubescape.io/image-name": "gke-gcr-io-gcp-compute-persistent-disk-csi-driver"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/gcp-compute-persistent-disk-csi-driver@sha256:a3e4af6b6f6999427dc7b02e813aa1ca5f26e73357c92a77b8fe774ddf431a26",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:56Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}