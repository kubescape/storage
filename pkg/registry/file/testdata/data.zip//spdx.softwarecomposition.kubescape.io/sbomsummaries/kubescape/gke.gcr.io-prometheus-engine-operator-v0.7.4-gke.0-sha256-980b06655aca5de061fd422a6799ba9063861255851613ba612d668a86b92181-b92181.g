{
  "name": "gke.gcr.io-prometheus-engine-operator-v0.7.4-gke.0-sha256-980b06655aca5de061fd422a6799ba9063861255851613ba612d668a86b92181-b92181",
  "namespace": "kubescape",
  "uid": "bbb9a164-4cc4-4a4f-b6e5-dc6d9659b699",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:44Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-prometheus-engine-operator-sha256-980b06655aca5de061",
    "kubescape.io/image-name": "gke-gcr-io-prometheus-engine-operator"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/prometheus-engine/operator@sha256:980b06655aca5de061fd422a6799ba9063861255851613ba612d668a86b92181",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:44Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}