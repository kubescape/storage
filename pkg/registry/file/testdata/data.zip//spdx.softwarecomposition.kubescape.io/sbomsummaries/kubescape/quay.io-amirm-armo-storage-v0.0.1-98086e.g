{
  "name": "quay.io-amirm-armo-storage-v0.0.1-98086e",
  "namespace": "kubescape",
  "uid": "d35871e5-27bc-4cb4-8602-ffa3ff303a57",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:46:05Z",
  "labels": {
    "kubescape.io/image-id": "quay-io-amirm-armo-storage-sha256-58df3eb1f8eb865588cb345045964",
    "kubescape.io/image-name": "quay-io-amirm-armo-storage"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/amirm_armo/storage@sha256:58df3eb1f8eb865588cb34504596421772f61e33e8ba7a0d6ae87bb67398086e",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:46:05Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}