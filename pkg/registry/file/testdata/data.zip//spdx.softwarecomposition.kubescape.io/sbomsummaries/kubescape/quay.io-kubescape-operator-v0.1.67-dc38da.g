{
  "name": "quay.io-kubescape-operator-v0.1.67-dc38da",
  "namespace": "kubescape",
  "uid": "fcdbeace-e17d-4d3d-81f5-b43b59b7ac95",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:07Z",
  "labels": {
    "kubescape.io/image-id": "quay-io-kubescape-operator-sha256-e38b22d522bf1d622c56efc04e6aa",
    "kubescape.io/image-name": "quay-io-kubescape-operator"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/kubescape/operator@sha256:e38b22d522bf1d622c56efc04e6aac6982a8307ccc0c59951652a63bd6dc38da",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:07Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}