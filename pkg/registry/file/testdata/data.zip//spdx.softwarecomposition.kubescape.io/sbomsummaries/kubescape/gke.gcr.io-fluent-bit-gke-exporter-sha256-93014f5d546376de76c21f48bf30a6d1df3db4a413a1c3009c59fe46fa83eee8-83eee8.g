{
  "name": "gke.gcr.io-fluent-bit-gke-exporter-sha256-93014f5d546376de76c21f48bf30a6d1df3db4a413a1c3009c59fe46fa83eee8-83eee8",
  "namespace": "kubescape",
  "uid": "33b772b2-925f-4eb9-bdc3-ade5d358bfd7",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:14Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-fluent-bit-gke-exporter-sha256-93014f5d546376de76c21",
    "kubescape.io/image-name": "gke-gcr-io-fluent-bit-gke-exporter"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/fluent-bit-gke-exporter@sha256:93014f5d546376de76c21f48bf30a6d1df3db4a413a1c3009c59fe46fa83eee8",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:14Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}