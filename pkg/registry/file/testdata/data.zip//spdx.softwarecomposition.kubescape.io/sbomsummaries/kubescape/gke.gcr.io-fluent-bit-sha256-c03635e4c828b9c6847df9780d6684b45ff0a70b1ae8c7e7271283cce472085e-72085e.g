{
  "name": "gke.gcr.io-fluent-bit-sha256-c03635e4c828b9c6847df9780d6684b45ff0a70b1ae8c7e7271283cce472085e-72085e",
  "namespace": "kubescape",
  "uid": "671fdef6-3327-48ce-8eb2-f4ecd0a36af1",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:12Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-fluent-bit-sha256-c03635e4c828b9c6847df9780d6684b45f",
    "kubescape.io/image-name": "gke-gcr-io-fluent-bit"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/fluent-bit@sha256:c03635e4c828b9c6847df9780d6684b45ff0a70b1ae8c7e7271283cce472085e",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:12Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}