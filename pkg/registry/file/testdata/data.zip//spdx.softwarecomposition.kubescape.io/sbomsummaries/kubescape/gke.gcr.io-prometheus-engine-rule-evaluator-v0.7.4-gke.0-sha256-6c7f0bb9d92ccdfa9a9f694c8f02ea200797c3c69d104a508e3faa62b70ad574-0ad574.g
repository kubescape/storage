{
  "name": "gke.gcr.io-prometheus-engine-rule-evaluator-v0.7.4-gke.0-sha256-6c7f0bb9d92ccdfa9a9f694c8f02ea200797c3c69d104a508e3faa62b70ad574-0ad574",
  "namespace": "kubescape",
  "uid": "dad9de84-90fa-412b-8c4b-4d6de994abd9",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:58Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-prometheus-engine-rule-evaluator-sha256-6c7f0bb9d92c",
    "kubescape.io/image-name": "gke-gcr-io-prometheus-engine-rule-evaluator"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/prometheus-engine/rule-evaluator@sha256:6c7f0bb9d92ccdfa9a9f694c8f02ea200797c3c69d104a508e3faa62b70ad574",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:44:58Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}