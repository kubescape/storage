{
  "name": "gke.gcr.io-prometheus-to-sd-v0.11.5-gke.0-sha256-654791db0d4d17c5847221fd3ace5c23ea1bb20c5976db9fda0853fd6000ab65-00ab65",
  "namespace": "kubescape",
  "uid": "199c9b57-dbef-4a20-9eac-52cf139a607a",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:23Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-prometheus-to-sd-sha256-654791db0d4d17c5847221fd3ace",
    "kubescape.io/image-name": "gke-gcr-io-prometheus-to-sd"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/prometheus-to-sd@sha256:654791db0d4d17c5847221fd3ace5c23ea1bb20c5976db9fda0853fd6000ab65",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:23Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}