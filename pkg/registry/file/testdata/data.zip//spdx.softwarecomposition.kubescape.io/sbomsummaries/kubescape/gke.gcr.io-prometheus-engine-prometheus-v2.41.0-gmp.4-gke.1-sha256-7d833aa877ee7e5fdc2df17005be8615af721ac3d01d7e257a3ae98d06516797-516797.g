{
  "name": "gke.gcr.io-prometheus-engine-prometheus-v2.41.0-gmp.4-gke.1-sha256-7d833aa877ee7e5fdc2df17005be8615af721ac3d01d7e257a3ae98d06516797-516797",
  "namespace": "kubescape",
  "uid": "fd395afe-68d2-4a9b-a5ab-594b667bc0e9",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:39Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-prometheus-engine-prometheus-sha256-7d833aa877ee7e5f",
    "kubescape.io/image-name": "gke-gcr-io-prometheus-engine-prometheus"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/prometheus-engine/prometheus@sha256:7d833aa877ee7e5fdc2df17005be8615af721ac3d01d7e257a3ae98d06516797",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:39Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}