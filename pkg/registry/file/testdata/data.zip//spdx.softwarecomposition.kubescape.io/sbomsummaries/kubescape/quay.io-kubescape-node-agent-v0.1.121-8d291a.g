{
  "name": "quay.io-kubescape-node-agent-v0.1.121-8d291a",
  "namespace": "kubescape",
  "uid": "4f903549-b565-4798-aca5-9c10e06eae0b",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:46:00Z",
  "labels": {
    "kubescape.io/image-id": "quay-io-kubescape-node-agent-sha256-e96deebf5dd040397ca547c17e0",
    "kubescape.io/image-name": "quay-io-kubescape-node-agent"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/kubescape/node-agent@sha256:e96deebf5dd040397ca547c17e092f866232e2f8ef76b6374f3ea3b7168d291a",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:46:00Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}