{
  "name": "gke.gcr.io-gke-metrics-agent-1.10.0-gke.0-sha256-0e56abb7da3b2419f6ef300a402c29f9e2810ba135db04621518581ffa48aae9-48aae9",
  "namespace": "kubescape",
  "uid": "68db304e-5b21-4907-a11c-8cf2eec83053",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:41Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-gke-metrics-agent-sha256-0e56abb7da3b2419f6ef300a402",
    "kubescape.io/image-name": "gke-gcr-io-gke-metrics-agent"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/gke-metrics-agent@sha256:0e56abb7da3b2419f6ef300a402c29f9e2810ba135db04621518581ffa48aae9",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:41Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}