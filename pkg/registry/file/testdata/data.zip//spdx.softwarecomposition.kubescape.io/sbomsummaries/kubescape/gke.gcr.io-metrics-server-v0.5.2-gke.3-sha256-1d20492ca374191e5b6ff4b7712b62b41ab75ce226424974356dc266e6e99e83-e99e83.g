{
  "name": "gke.gcr.io-metrics-server-v0.5.2-gke.3-sha256-1d20492ca374191e5b6ff4b7712b62b41ab75ce226424974356dc266e6e99e83-e99e83",
  "namespace": "kubescape",
  "uid": "1d20b92c-6699-47bf-9c79-d2d2d3e28510",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:43Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-metrics-server-sha256-1d20492ca374191e5b6ff4b7712b62",
    "kubescape.io/image-name": "gke-gcr-io-metrics-server"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/metrics-server@sha256:1d20492ca374191e5b6ff4b7712b62b41ab75ce226424974356dc266e6e99e83",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:44:43Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}