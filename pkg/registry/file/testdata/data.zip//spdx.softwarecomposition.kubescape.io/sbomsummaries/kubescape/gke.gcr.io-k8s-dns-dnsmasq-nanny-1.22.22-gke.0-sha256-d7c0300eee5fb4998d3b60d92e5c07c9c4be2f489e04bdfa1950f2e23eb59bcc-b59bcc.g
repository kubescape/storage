{
  "name": "gke.gcr.io-k8s-dns-dnsmasq-nanny-1.22.22-gke.0-sha256-d7c0300eee5fb4998d3b60d92e5c07c9c4be2f489e04bdfa1950f2e23eb59bcc-b59bcc",
  "namespace": "kubescape",
  "uid": "d5985f3e-9872-407d-ab78-cccf1ab73132",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:19Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-k8s-dns-dnsmasq-nanny-sha256-d7c0300eee5fb4998d3b60d",
    "kubescape.io/image-name": "gke-gcr-io-k8s-dns-dnsmasq-nanny"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/k8s-dns-dnsmasq-nanny@sha256:d7c0300eee5fb4998d3b60d92e5c07c9c4be2f489e04bdfa1950f2e23eb59bcc",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:19Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}