{
  "name": "gke.gcr.io-csi-node-driver-registrar-v2.8.0-gke.4-sha256-715a1581ce158fbf95f7ca351e25c7d6a0a1599e46e270e72238cc8a0aef1c43-ef1c43",
  "namespace": "kubescape",
  "uid": "d39c6ea0-83e1-46ff-aa1c-30afa61afb75",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:51Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-csi-node-driver-registrar-sha256-715a1581ce158fbf95f",
    "kubescape.io/image-name": "gke-gcr-io-csi-node-driver-registrar"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/csi-node-driver-registrar@sha256:715a1581ce158fbf95f7ca351e25c7d6a0a1599e46e270e72238cc8a0aef1c43",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:51Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}