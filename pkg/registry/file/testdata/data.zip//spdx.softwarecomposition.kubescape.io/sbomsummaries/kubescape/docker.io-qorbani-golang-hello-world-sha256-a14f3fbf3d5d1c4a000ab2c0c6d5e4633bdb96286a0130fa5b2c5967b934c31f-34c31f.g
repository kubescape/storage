{
  "name": "docker.io-qorbani-golang-hello-world-sha256-a14f3fbf3d5d1c4a000ab2c0c6d5e4633bdb96286a0130fa5b2c5967b934c31f-34c31f",
  "namespace": "kubescape",
  "uid": "cbb3ce15-f036-450f-ba3b-64aaecb4e0ea",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:50Z",
  "labels": {
    "kubescape.io/image-id": "docker-io-qorbani-golang-hello-world-sha256-a14f3fbf3d5d1c4a000",
    "kubescape.io/image-name": "docker-io-qorbani-golang-hello-world"
  },
  "annotations": {
    "kubescape.io/image-id": "docker.io/qorbani/golang-hello-world@sha256:a14f3fbf3d5d1c4a000ab2c0c6d5e4633bdb96286a0130fa5b2c5967b934c31f",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:50Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}