{
  "name": "gke.gcr.io-prometheus-engine-config-reloader-v0.7.4-gke.0-sha256-7c290f7ac85228c341d79a05f1cbd75c309d6d0573c4ec32e113dc749e8076d9-8076d9",
  "namespace": "kubescape",
  "uid": "6b23b0ff-e2be-489a-8e6d-3f2897ecbe2b",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:51Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-prometheus-engine-config-reloader-sha256-7c290f7ac85",
    "kubescape.io/image-name": "gke-gcr-io-prometheus-engine-config-reloader"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/prometheus-engine/config-reloader@sha256:7c290f7ac85228c341d79a05f1cbd75c309d6d0573c4ec32e113dc749e8076d9",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:44:51Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}