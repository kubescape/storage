{
  "name": "gke.gcr.io-addon-resizer-1.8.18-gke.0-sha256-73f83a267713c9ec9bdb5564be404567b8d446813d39c74a5eff2fdbcc91ebf2-91ebf2",
  "namespace": "kubescape",
  "uid": "cdde5de5-3877-4fda-ae34-ccc62cd51719",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:49Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-addon-resizer-sha256-73f83a267713c9ec9bdb5564be40456",
    "kubescape.io/image-name": "gke-gcr-io-addon-resizer"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/addon-resizer@sha256:73f83a267713c9ec9bdb5564be404567b8d446813d39c74a5eff2fdbcc91ebf2",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:44:49Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}