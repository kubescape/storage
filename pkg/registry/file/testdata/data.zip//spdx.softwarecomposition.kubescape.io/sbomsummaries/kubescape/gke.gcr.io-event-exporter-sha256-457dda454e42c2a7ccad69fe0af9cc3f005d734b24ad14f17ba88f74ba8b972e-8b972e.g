{
  "name": "gke.gcr.io-event-exporter-sha256-457dda454e42c2a7ccad69fe0af9cc3f005d734b24ad14f17ba88f74ba8b972e-8b972e",
  "namespace": "kubescape",
  "uid": "4cae438b-d0f0-49e0-a62c-ae3b1a1f4a68",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:54Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-event-exporter-sha256-457dda454e42c2a7ccad69fe0af9cc",
    "kubescape.io/image-name": "gke-gcr-io-event-exporter"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/event-exporter@sha256:457dda454e42c2a7ccad69fe0af9cc3f005d734b24ad14f17ba88f74ba8b972e",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:44:54Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}