{
  "name": "gke.gcr.io-cluster-proportional-autoscaler-1.8.4-gke.1-sha256-0f232ba18b63363e33f205d0242ef98324fb388434f8598c2fc8e967dca146bc-a146bc",
  "namespace": "kubescape",
  "uid": "4e34a73d-15c5-41f8-83d1-bf5a0c6b231d",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:55Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-cluster-proportional-autoscaler-sha256-0f232ba18b633",
    "kubescape.io/image-name": "gke-gcr-io-cluster-proportional-autoscaler"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/cluster-proportional-autoscaler@sha256:0f232ba18b63363e33f205d0242ef98324fb388434f8598c2fc8e967dca146bc",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:44:55Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}