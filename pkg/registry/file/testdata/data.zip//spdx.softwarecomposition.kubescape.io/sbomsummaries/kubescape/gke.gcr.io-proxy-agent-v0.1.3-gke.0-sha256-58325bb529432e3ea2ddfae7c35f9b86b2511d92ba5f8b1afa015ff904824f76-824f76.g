{
  "name": "gke.gcr.io-proxy-agent-v0.1.3-gke.0-sha256-58325bb529432e3ea2ddfae7c35f9b86b2511d92ba5f8b1afa015ff904824f76-824f76",
  "namespace": "kubescape",
  "uid": "700663b9-10ac-4ca2-8aad-fbc780b284ac",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:46Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-proxy-agent-sha256-58325bb529432e3ea2ddfae7c35f9b86b",
    "kubescape.io/image-name": "gke-gcr-io-proxy-agent"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/proxy-agent@sha256:58325bb529432e3ea2ddfae7c35f9b86b2511d92ba5f8b1afa015ff904824f76",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:46Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}