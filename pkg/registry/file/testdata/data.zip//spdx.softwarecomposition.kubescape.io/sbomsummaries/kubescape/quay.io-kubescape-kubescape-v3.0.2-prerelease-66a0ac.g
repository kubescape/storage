{
  "name": "quay.io-kubescape-kubescape-v3.0.2-prerelease-66a0ac",
  "namespace": "kubescape",
  "uid": "e2b52d13-f2d6-4a71-ab4b-3921283e70bc",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:28Z",
  "labels": {
    "kubescape.io/image-id": "quay-io-kubescape-kubescape-sha256-8cea6c0e9d2355e6ae7576bd29fb",
    "kubescape.io/image-name": "quay-io-kubescape-kubescape"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/kubescape/kubescape@sha256:8cea6c0e9d2355e6ae7576bd29fbf4e7614abc480781a7404a8913170c66a0ac",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:28Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}