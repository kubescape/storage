{
  "name": "gke.gcr.io-k8s-dns-sidecar-1.22.22-gke.0-sha256-fd7dc24c8331bbd9d0178f65cfcfe7ef42c003b7ee25b8df595d80d0f237486a-37486a",
  "namespace": "kubescape",
  "uid": "1e5c2a84-7de7-4353-b24f-17ff9d9f4cf2",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:21Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-k8s-dns-sidecar-sha256-fd7dc24c8331bbd9d0178f65cfcfe",
    "kubescape.io/image-name": "gke-gcr-io-k8s-dns-sidecar"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/k8s-dns-sidecar@sha256:fd7dc24c8331bbd9d0178f65cfcfe7ef42c003b7ee25b8df595d80d0f237486a",
    "kubescape.io/status": ""
  },
  "managedFields": [
    {
      "manager": "kubevuln",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-11-29T12:45:21Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/status": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/image-id": {},
            "f:kubescape.io/image-name": {}
          }
        }
      }
    }
  ],
  "Spec": {},
  "Status": {}
}