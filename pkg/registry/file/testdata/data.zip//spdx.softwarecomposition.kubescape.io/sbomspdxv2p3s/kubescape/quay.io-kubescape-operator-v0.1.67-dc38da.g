{
  "name": "quay.io-kubescape-operator-v0.1.67-dc38da",
  "namespace": "kubescape",
  "uid": "6246df26-937a-4afe-9299-b0cfb1689da4",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:07Z",
  "labels": {
    "kubescape.io/image-id": "quay-io-kubescape-operator-sha256-e38b22d522bf1d622c56efc04e6aa",
    "kubescape.io/image-name": "quay-io-kubescape-operator"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/kubescape/operator@sha256:e38b22d522bf1d622c56efc04e6aac6982a8307ccc0c59951652a63bd6dc38da",
    "kubescape.io/status": ""
  },
  "Spec": {
    "Metadata": {
      "Tool": {
        "Name": "",
        "Version": "v0.76.0"
      },
      "Report": {
        "CreatedAt": null
      }
    },
    "SPDX": {
      "DocumentDescribes": null,
      "SPDXVersion": "SPDX-2.3",
      "DataLicense": "CC0-1.0",
      "SPDXIdentifier": "SPDXRef-DOCUMENT",
      "DocumentName": "quay.io/kubescape/operator@sha256:e38b22d522bf1d622c56efc04e6aac6982a8307ccc0c59951652a63bd6dc38da",
      "DocumentNamespace": "https://anchore.com/syft/image/quay.io/kubescape/operator@sha256-e38b22d522bf1d622c56efc04e6aac6982a8307ccc0c59951652a63bd6dc38da-81191701-a1b9-44b3-a5fb-d49d64a5383e",
      "ExternalDocumentReferences": null,
      "DocumentComment": "",
      "CreationInfo": {
        "LicenseListVersion": "3.20",
        "Creators": [
          "Organization: Anchore, Inc",
          "Tool: syft-v0.76.0"
        ],
        "Created": "2023-11-29T12:45:06Z",
        "CreatorComment": ""
      },
      "Packages": [
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "base-files",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-base-files-804e0f6f409b3aac",
          "PackageVersion": "11.1+deb11u8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Santiago Vila \u003csanvila@debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/base-files/copyright, /var/lib/dpkg/status.d/base-files",
          "PackageLicenseConcluded": "LicenseRef-GPL",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "LicenseRef-GPL",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base-files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base_files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base-files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base_files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base-files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base_files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/base-files@11.1+deb11u8?arch=amd64\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "cloud.google.com/go/compute/metadata",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-cloud.google.com-go-compute-metadata-94b43f7f72691629",
          "PackageVersion": "v0.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9a0e23964ee60808fac57a7d509e1f8c8f55508e6bb9bb86056e5a27b52704c6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:compute\\/metadata:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/cloud.google.com/go/compute/metadata@v0.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "cloud.google.com/go/container",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-cloud.google.com-go-container-a765b0fdef0e98e1",
          "PackageVersion": "v1.24.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "379d6dfdc810245a830ff5bb31bf88be600f1eb7fc01b3f1ec16fb685e2544e1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:container:v1.24.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/cloud.google.com/go/container@v1.24.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/azcore",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-azcore-b5c0014372cbc1a7",
          "PackageVersion": "v1.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f240ea0e7807f839950620ad2230854c66bb3019ec20e905f4871c2271446e39"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/azcore:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/azcore:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/azcore@v1.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/azidentity",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-azidentity-f6d23a39e6e7cc08",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bdc6020337baa75f6a056ecc859c9b22ca83f2c315f23b3437240cf090e756d8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/azidentity:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/azidentity:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/azidentity@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/internal",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-internal-1b31829c722b796c",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b17afe724f3883f66565439988d10b22798c80eb2e1b07638d590421d7b43ad6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/internal:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/internal:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/internal@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-resourcemanager-authorization-armauthorization-81ab21f409e64007",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "aad45c83963b8cd2788c4ccfab81a958b7d3b291dd35ed992ba2e3c067238265"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-resourcemanager-authorization-armauthorization-v2-174ad502089a5f2f",
          "PackageVersion": "v2.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e80e0cf2c985fb2f2733f0d8b0b350cfd9fb9f664668456a7f3f195908ab4242"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization\\/v2:v2.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization\\/v2:v2.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2@v2.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/containerservice/armcontainerservice/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-resourcemanager-containerservice-armcontainerservice-v2-f966769aa4760635",
          "PackageVersion": "v2.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d6efcad8116fd0cc241ba85ef1162e51c6db78adb6ae4a196e0e2529afe6b195"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/resourcemanager\\/containerservice\\/armcontainerservice\\/v2:v2.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/resourcemanager\\/containerservice\\/armcontainerservice\\/v2:v2.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/containerservice/armcontainerservice/v2@v2.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/AzureAD/microsoft-authentication-library-for-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-AzureAD-microsoft-authentication-library-for-go-d364a40b9a759c44",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "38186a922be486432a2cfca6584a69926eef80f418d97b07a0491a310d007596"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:AzureAD:microsoft-authentication-library-for-go:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:AzureAD:microsoft_authentication_library_for_go:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/AzureAD/microsoft-authentication-library-for-go@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/OneOfOne/xxhash",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-OneOfOne-xxhash-7faaf8006f1e81ac",
          "PackageVersion": "v1.2.8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "df57332bf4c8f6c364c4829f6947c6954e3b040c50d33b4681df6f3f2aa299ff"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:OneOfOne:xxhash:v1.2.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/OneOfOne/xxhash@v1.2.8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/agnivade/levenshtein",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-agnivade-levenshtein-54f692d69595bda7",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "418f0cf769ebce49abefdf200a8de498ccaa5c5cdd415a712e518f4418a3d0ff"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:agnivade:levenshtein:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/agnivade/levenshtein@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/armoapi-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-armoapi-go-2cb461b0612e5563",
          "PackageVersion": "v0.0.256",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "795f16590d6bfb60f428784b03abb1ea5c7aefebaa9187bfb951eb39416acf97"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:armoapi-go:v0.0.256:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:armoapi_go:v0.0.256:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/armoapi-go@v0.0.256",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/cluster-notifier-api-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-cluster-notifier-api-go-3f5dcfe643cef34e",
          "PackageVersion": "v0.0.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "50a639f1e84aa1c2a0b6aceb6b0c9a20725ae69686f40e2caeffb8ffa9fe133e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:cluster-notifier-api-go:v0.0.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:cluster_notifier_api_go:v0.0.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/cluster-notifier-api-go@v0.0.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/gojay",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-gojay-c9506aedf727089e",
          "PackageVersion": "v1.2.15",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b12076be702f69c50d930f67cd461929c3f38493b293aff92cad8908d766a196"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:gojay:v1.2.15:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/gojay@v1.2.15",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/registryx",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-registryx-67006171c709ab4b",
          "PackageVersion": "v0.0.15",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "fa208ef93ba138be1cc2ff491e94cc9a6af8a08db0715652f24fd2d539492897"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:registryx:v0.0.15:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/registryx@v0.0.15",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/utils-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-utils-go-542215e0c85eef10",
          "PackageVersion": "v0.0.40",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "15d1fc4f1446d121f785e28bad9d0c8f47aae5d360939828f3f9ad7920a0db06"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils-go:v0.0.40:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils_go:v0.0.40:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/utils-go@v0.0.40",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/utils-k8s-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-utils-k8s-go-bfb8f6ce45b581bb",
          "PackageVersion": "v0.0.18",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4819a3fa3ff926b44e55054b8e51eca0c70f64a2bf00a5842b548c31fde17755"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils-k8s-go:v0.0.18:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils_k8s_go:v0.0.18:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/utils-k8s-go@v0.0.18",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/asaskevich/govalidator",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-asaskevich-govalidator-22befc5615c28828",
          "PackageVersion": "v0.0.0-20230301143203-a9d515a09cc2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0e496cac6dddc81085123e488546e72a9b63c5ab64174edc1766a4df28bbeeca"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:asaskevich:govalidator:v0.0.0-20230301143203-a9d515a09cc2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/asaskevich/govalidator@v0.0.0-20230301143203-a9d515a09cc2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-52d2eca312200f6c",
          "PackageVersion": "v1.44.312",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "965ac495fcdea86fd838b1452a3835c4da59085276c6b6888b73ea4ae3fef799"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go:v1.44.312:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go:v1.44.312:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go@v1.44.312",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-c1437d03ff711fc8",
          "PackageVersion": "v1.19.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "493b3495b6e95eeddbc933dc9d12e086cd831f4ca4f6a283a36ed3cb22522ac3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2:v1.19.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2:v1.19.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2@v1.19.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/config",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-config-b25b89f5232235e2",
          "PackageVersion": "v1.18.30",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4d30174089f7d6a6055108e45bab2256b4535f5bb1fac00364339ede3b1970c8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/config:v1.18.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/config:v1.18.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/config@v1.18.30",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/credentials",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-credentials-42ff38c97c405dd8",
          "PackageVersion": "v1.13.29",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "28d802a53846b99c828eaf44baeaa82c37a728a3303bfc755f1d357240daed52"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/credentials:v1.13.29:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/credentials:v1.13.29:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/credentials@v1.13.29",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/feature/ec2/imds",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-feature-ec2-imds-cedc5af9d92ee717",
          "PackageVersion": "v1.13.6",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "928aed2b5db62ef4d4df80865ff17da09a5e9572a4100da3fcc5b8f0823ef3ef"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/feature\\/ec2\\/imds:v1.13.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/feature\\/ec2\\/imds:v1.13.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/feature/ec2/imds@v1.13.6",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/internal/configsources",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-internal-configsources-31ffd852f8e069e0",
          "PackageVersion": "v1.1.36",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "91b93cd5194fa02e9ee1ca3b710c76140bc7f5381bcf122a0aa8a8b0016207ec"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/internal\\/configsources:v1.1.36:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/internal\\/configsources:v1.1.36:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/internal/configsources@v1.1.36",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/internal/endpoints/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-internal-endpoints-v2-6b867e4ea6a031d0",
          "PackageVersion": "v2.4.30",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "94c97c4b9481f2334207e4adcb6126e259eedc8272b5c78741deea6e67ea28bd"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/internal\\/endpoints\\/v2:v2.4.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/internal\\/endpoints\\/v2:v2.4.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/internal/endpoints/v2@v2.4.30",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/internal/ini",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-internal-ini-8402188e7eaad45a",
          "PackageVersion": "v1.3.37",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0578aabcded6b95fe9321cfc0a2be13bc706f227097239e31ee9a27f8ba44347"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/internal\\/ini:v1.3.37:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/internal\\/ini:v1.3.37:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/internal/ini@v1.3.37",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/ecr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-ecr-b631e95f75c5263",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e5155a9c3f8ff8bd96f56534efff09fc0e76be7422ec5dc294175642db606258"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/ecr:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/ecr:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/ecr@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/eks",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-eks-8e01e08648ca9174",
          "PackageVersion": "v1.28.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "480fbdf119de865d8a5dec2f1977362f0da7b37638b7d8dd30798463985c370b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/eks:v1.28.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/eks:v1.28.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/eks@v1.28.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/iam",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-iam-8ceecb9bcabcaadc",
          "PackageVersion": "v1.19.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f6f0b29e8a82f9d83164aaec8ef0278b2228a6cbf745916c67ac2443ecb1b63f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/iam:v1.19.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/iam:v1.19.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/iam@v1.19.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/internal/presigned-url",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-internal-presigned-url-121dd910cd577f99",
          "PackageVersion": "v1.9.30",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "51c559c4b54d638c9ac829a21bde067b7976a9b73958407fa1ae119a3a10122d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/internal\\/presigned-url:v1.9.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/internal\\/presigned_url:v1.9.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/internal/presigned-url@v1.9.30",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/sso",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-sso-208d4849200fa725",
          "PackageVersion": "v1.12.14",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8148f3eedadfcfda819b402590a4ef24705710b8b5c2fc3ed8b03d19f0f602c3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/sso:v1.12.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/sso:v1.12.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/sso@v1.12.14",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/ssooidc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-ssooidc-959ad5951cc00ac1",
          "PackageVersion": "v1.14.14",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f1b12dc55e544fdb9c7561977d9ec233771a4214871a35a74c7b7439e17b9bbb"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/ssooidc:v1.14.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/ssooidc:v1.14.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/ssooidc@v1.14.14",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/sts",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-sts-340d5a11c0993a83",
          "PackageVersion": "v1.20.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "53b87d08fa3231f5683798d48250742e094230fd7400ae2f301b1bb0228cf18c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/sts:v1.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/sts:v1.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/sts@v1.20.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/smithy-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-smithy-go-44e38a3699c8fae2",
          "PackageVersion": "v1.13.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "860cf45ff0d7d1d1aa4d8a4600ba9726844a463e6843bd79d22e4575378fccef"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:smithy-go:v1.13.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:smithy_go:v1.13.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/smithy-go@v1.13.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/beorn7/perks",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-beorn7-perks-19883e8dc5e9da29",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5656ca2a735f57c6c9cdeaa86b870e2aa3ba6d8af75a0299c4ef19d7afa1b0e3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:beorn7:perks:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/beorn7/perks@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/briandowns/spinner",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-briandowns-spinner-61cd8c34c54a43b",
          "PackageVersion": "v1.23.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6a50c5da0b915aa6bf14e6596168e5308c762fa1f4c327b03f1a3f087e0fb760"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:briandowns:spinner:v1.23.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/briandowns/spinner@v1.23.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/cenkalti/backoff/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-cenkalti-backoff-v4-472878df9a901230",
          "PackageVersion": "v4.2.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cb8399b429e882608fc3df198f2b796baf90c0f2c692242c616e6852aca561b3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:cenkalti:backoff\\/v4:v4.2.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/cenkalti/backoff/v4@v4.2.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/cespare/xxhash/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-cespare-xxhash-v2-d225f3a0765a56d1",
          "PackageVersion": "v2.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0c2d82675129e58e24dd943cf7d0e575ea60adac9150613a04167f71df428f8e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:cespare:xxhash\\/v2:v2.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/cespare/xxhash/v2@v2.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/containerd/stargz-snapshotter/estargz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-containerd-stargz-snapshotter-estargz-c963b971ab04a4a3",
          "PackageVersion": "v0.14.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3aa94308add95543ba0b707fe454a40f06e41044caf38910804785c030beeb69"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:containerd:stargz-snapshotter\\/estargz:v0.14.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:containerd:stargz_snapshotter\\/estargz:v0.14.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/containerd/stargz-snapshotter/estargz@v0.14.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/coreos/go-oidc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-coreos-go-oidc-3fe254ef151aa753",
          "PackageVersion": "v2.2.1+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9a1e3cabf06a5ea823547a72d9963b5a75806de9f1463b33f4dd62d58c631c09"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go-oidc:v2.2.1\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go_oidc:v2.2.1\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/coreos/go-oidc@v2.2.1+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/davecgh/go-spew",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-davecgh-go-spew-cc5a50fb2dba633c",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be3f63feed5baa7bc211f24ec1486d94e011aacdfeae41d8635de36164d4f7b7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:davecgh:go-spew:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:davecgh:go_spew:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/davecgh/go-spew@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/deckarep/golang-set/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-deckarep-golang-set-v2-4dc3b8af9ada9be3",
          "PackageVersion": "v2.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "aacd7c10a51f1e6d97f5f039d0caff33985c720dad36756ab220489a7c83b348"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:deckarep:golang-set\\/v2:v2.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:deckarep:golang_set\\/v2:v2.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/deckarep/golang-set/v2@v2.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/cli",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-cli-7ebc970d63a993a7",
          "PackageVersion": "v23.0.5+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b9f5a600eb83dd59abec93f61b92b7732b8d0b86195a202cb8312f15554369f1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:cli:v23.0.5\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/cli@v23.0.5+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/distribution",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-distribution-5dea70a51c4396dc",
          "PackageVersion": "v2.8.2+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4f775ee6bab4741d63df4ae9d2c036ac447e9b7db6101ce78813c1e99233ba1f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:distribution:v2.8.2\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/distribution@v2.8.2+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/docker",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-docker-56e20a646f8ed603",
          "PackageVersion": "v24.0.5+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5a681c1387f1c88e84117c41471b079d95eb3b5a50dec9a2d24fe3868e072de6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:docker:v24.0.5\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/docker@v24.0.5+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/docker-credential-helpers",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-docker-credential-helpers-a72b4e15d1e42d92",
          "PackageVersion": "v0.7.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c6d087b23c688000cd65c76fd692941d7af279f8e5551a96a88864fee5c9a740"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:docker-credential-helpers:v0.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:docker_credential_helpers:v0.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/docker-credential-helpers@v0.7.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/go-connections",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-go-connections-f235cb20210f58fc",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "125f7154849e95107b06e16eb2b668ce39e420ce589f309588d2a884016a4494"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go-connections:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go_connections:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/go-connections@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/go-units",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-go-units-38123aad318062de",
          "PackageVersion": "v0.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ebdaf15dc064dbb4af49a6b14ed2e1ffc9657070fcbd81d3ed649d459fe3bebe"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go-units:v0.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go_units:v0.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/go-units@v0.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/emicklei/go-restful/v3",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-emicklei-go-restful-v3-f21db480d48ac477",
          "PackageVersion": "v3.10.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "adce36639613a7b026ec24badf40fb2668518eae1494452e10a7eb0da7386d24"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:emicklei:go-restful\\/v3:v3.10.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:emicklei:go_restful\\/v3:v3.10.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/emicklei/go-restful/v3@v3.10.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/fatih/color",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-fatih-color-53708f48d59166c0",
          "PackageVersion": "v1.15.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "90eaa1e981c1b4af1acb0c467ab306d84ab71fa420a2a7a8d77064d8cbff9c1b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:fatih:color:v1.15.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/fatih/color@v1.15.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/felixge/httpsnoop",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-felixge-httpsnoop-46334e9a225ae48e",
          "PackageVersion": "v1.0.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b3f9e3f860acc17633379bf60e934cb8c4187bed030f0b79595094e825817579"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:felixge:httpsnoop:v1.0.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/felixge/httpsnoop@v1.0.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/francoispqt/gojay",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-francoispqt-gojay-b9a11cc07b153b60",
          "PackageVersion": "v1.2.13",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7769b7b058e5a2aa085105374ec1c1823eaa83f0551a54c17870d49b22675ca9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:francoispqt:gojay:v1.2.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/francoispqt/gojay@v1.2.13",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/fsnotify/fsnotify",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-fsnotify-fsnotify-a71e409576452ecd",
          "PackageVersion": "v1.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9fee56aae1b47dc5a85a9eb13d67c775bb2430241a1671ba3df06b8752b2e076"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:fsnotify:fsnotify:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/fsnotify/fsnotify@v1.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/ghodss/yaml",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-ghodss-yaml-7bd9431d07f8123e",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c101ca11a8612fac265ddcf0586d7580854290ebf4e5b34e87e4719f4ca78009"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:ghodss:yaml:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/ghodss/yaml@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-ini/ini",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-ini-ini-f197455e930f6c7e",
          "PackageVersion": "v1.67.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cfa66b4c466a496393c87d8596094d6cd8004721c6f282d6f603042ea2abd3a0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-ini:ini:v1.67.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_ini:ini:v1.67.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:ini:v1.67.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-ini/ini@v1.67.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-logr/logr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-logr-logr-e98fc44a97c88850",
          "PackageVersion": "v1.2.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "834d46482c220f0db14997e3276fd3f4cf92ea915d70db4562ca7e638dc76034"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-logr:logr:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_logr:logr:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:logr:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-logr/logr@v1.2.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-logr/stdr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-logr-stdr-f12507155e575cc1",
          "PackageVersion": "v1.2.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8525b11e8a93816d92daa19cd0b4c0239eb7299e582984614f730529931b8da8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-logr:stdr:v1.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_logr:stdr:v1.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:stdr:v1.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-logr/stdr@v1.2.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/analysis",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-analysis-36ac8d4715cb4231",
          "PackageVersion": "v0.21.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "64314bbd2371a436a89ae0ae78cd019525f1a4034194562206fafe197aef2077"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:analysis:v0.21.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:analysis:v0.21.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:analysis:v0.21.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/analysis@v0.21.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/errors",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-errors-ce3129db739c6eb0",
          "PackageVersion": "v0.20.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "af3ea4882f38b2a350a2aaedba5cda2ff5444609280b207a59d124736ba3cd47"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:errors:v0.20.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:errors:v0.20.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:errors:v0.20.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/errors@v0.20.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/jsonpointer",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-jsonpointer-992fa6b55eb4e836",
          "PackageVersion": "v0.19.6",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "782b377f1a088b75a1eafb6098b4ce8dd852a62aa9850f8368f9f7f0dd9976b1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:jsonpointer:v0.19.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:jsonpointer:v0.19.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:jsonpointer:v0.19.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/jsonpointer@v0.19.6",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/jsonreference",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-jsonreference-56f956a642a97dec",
          "PackageVersion": "v0.20.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1412e7cb2802e3f21966bf3dde88a899cf576a0868bde613acb0b517ce87203f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:jsonreference:v0.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:jsonreference:v0.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:jsonreference:v0.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/jsonreference@v0.20.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/loads",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-loads-bf4e4fd6a9a16902",
          "PackageVersion": "v0.21.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "af66bfc45218799e107764e71a958321035c3fcd1d21a6607fbd38cdaf1e9eba"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:loads:v0.21.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:loads:v0.21.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:loads:v0.21.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/loads@v0.21.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/runtime",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-runtime-fda435911847cf61",
          "PackageVersion": "v0.26.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1d8385b46d3414cd54beaadcc5b10983f4b0bc346f60b40a1a1c36cda4234dc7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:runtime:v0.26.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:runtime:v0.26.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:runtime:v0.26.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/runtime@v0.26.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/spec",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-spec-1e7191cb6cadd9a3",
          "PackageVersion": "v0.20.8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b9b1e65cd63714220e8a74fc44daeb3df19cf6dec8d6a84fb5d386a06d80c515"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:spec:v0.20.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:spec:v0.20.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:spec:v0.20.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/spec@v0.20.8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/strfmt",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-strfmt-9a7f59bf8aeda2fe",
          "PackageVersion": "v0.21.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "aeca625e035681e533863a35614d35768eaab1a86d24d0728cb55b3cb3476fc9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:strfmt:v0.21.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:strfmt:v0.21.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:strfmt:v0.21.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/strfmt@v0.21.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/swag",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-swag-57f8e7500b93cd65",
          "PackageVersion": "v0.22.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c8c06a9a743483266f11bffe2b3b9664e5e0965ad74f84800d86ef0da5c7bff8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:swag:v0.22.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:swag:v0.22.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:swag:v0.22.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/swag@v0.22.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/validate",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-validate-27b42d866b7b2a4c",
          "PackageVersion": "v0.22.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1be736b9beaae3b91f5f5b0e04bc08430cc156df2a98e000472a3ff45aacf4d5"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:validate:v0.22.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:validate:v0.22.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:validate:v0.22.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/validate@v0.22.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gobwas/glob",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gobwas-glob-ddf01739b0a37896",
          "PackageVersion": "v0.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "038c436e58c82d744e87e90e6c88b2e6421a3d80fc7bdeb1d6d80185423927e6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gobwas:glob:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gobwas/glob@v0.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gogo/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gogo-protobuf-847fdc1d3586a307",
          "PackageVersion": "v1.3.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3afd5cbdce7c505ddbe578c19d9bfbfa8a5c4dc40565e6d88d6ce2df8bdd9b84"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gogo:protobuf:v1.3.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gogo/protobuf@v1.3.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang-jwt/jwt/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-jwt-jwt-v4-2ccf2092bdc44385",
          "PackageVersion": "v4.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "edc6265b55e5318ee1ee28bb5215320a14a04b9c142449e6f6e6554c6a8e5b38"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang-jwt:jwt\\/v4:v4.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang_jwt:jwt\\/v4:v4.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:jwt\\/v4:v4.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang-jwt/jwt/v4@v4.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/glog",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-glog-baa91e221546a51a",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8f1a62d9e5a853ce306d7f62204c8079ea1a73714bba27d9a58f6d70d503f64c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:glog:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/glog@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/groupcache",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-groupcache-555d17a8386f47a2",
          "PackageVersion": "v0.0.0-20210331224755-41bb18bfe9da",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a08e710aab02a39eb897c88d53e0f00797a9c66b1aa81fab8462f49b98ed62a1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:groupcache:v0.0.0-20210331224755-41bb18bfe9da:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/groupcache@v0.0.0-20210331224755-41bb18bfe9da",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-protobuf-6807f3cc43d89c28",
          "PackageVersion": "v1.5.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2a1ca3295520ed4b2bfdd62c752aa816f78c61de64a3bd83fb300dc251b59a68"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:protobuf:v1.5.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/protobuf@v1.5.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/gnostic",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-gnostic-d9b7d7101781f2e6",
          "PackageVersion": "v0.5.7-v3refs",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1614cc38a8f65618e9a2ec6f589015d532f7d38b8c95bf73703aa497a704239e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:gnostic:v0.5.7-v3refs:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/gnostic@v0.5.7-v3refs",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/go-cmp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-go-cmp-a7fec6b675fea001",
          "PackageVersion": "v0.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a1fca1c6f5dc66132c539ba56c588b2a5fd7045a84d464aaedab6ef2d0264d12"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go-cmp:v0.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go_cmp:v0.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/go-cmp@v0.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/go-containerregistry",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-go-containerregistry-92d26f9a0edb8a66",
          "PackageVersion": "v0.15.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "30c91287eb6349d9e62593bb963bc4a95d438df7a407a554100660cb76be4d01"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go-containerregistry:v0.15.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go_containerregistry:v0.15.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/go-containerregistry@v0.15.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/gofuzz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-gofuzz-bfbd53a6315a7c3e",
          "PackageVersion": "v1.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c51cb803e46165a88a8c9d5b3dfc10f2c79d080f984b661c0875ba79cec9322d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:gofuzz:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/gofuzz@v1.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/s2a-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-s2a-go-3e74e3c971c6fd46",
          "PackageVersion": "v0.1.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d6467fb10337b2b78fbcab37b5702f433a3ae977dc45ea2a16922921c704ece7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:s2a-go:v0.1.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:s2a_go:v0.1.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/s2a-go@v0.1.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/uuid",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-uuid-77fb18a5a0a5c680",
          "PackageVersion": "v1.3.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2a325a27d8966778ce15921fd4ba9fe256834426ac8e5d010a69c41b191d2dbe"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:uuid:v1.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/uuid@v1.3.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/googleapis/enterprise-certificate-proxy",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-googleapis-enterprise-certificate-proxy-9bdac028706a09fb",
          "PackageVersion": "v0.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ca4f7f72a44ab53f705d94ac447f5abab5c4a495fe53a14bb69613742dd1d3a9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:enterprise-certificate-proxy:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:enterprise_certificate_proxy:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/googleapis/enterprise-certificate-proxy@v0.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/googleapis/gax-go/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-googleapis-gax-go-v2-ec7ef718b8926937",
          "PackageVersion": "v2.11.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f55f4f59712c5a73e9421bbf3de408912e1e1b33254cb1a0b7cd1c51423c2a2e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:gax-go\\/v2:v2.11.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:gax_go\\/v2:v2.11.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/googleapis/gax-go/v2@v2.11.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gorilla/mux",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gorilla-mux-f6c7e8df009cbee7",
          "PackageVersion": "v1.8.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8b8d1aa9f911d61d9294df61a23c15e5903dd7071714ebe474d21e1433f99282"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gorilla:mux:v1.8.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gorilla/mux@v1.8.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gorilla/websocket",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gorilla-websocket-c24e64e560424678",
          "PackageVersion": "v1.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3cfc069368f3ec478fa681cdffe0a56d9bbc48fc62aa5bb5db064fff7b169a77"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gorilla:websocket:v1.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gorilla/websocket@v1.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/grpc-ecosystem/grpc-gateway/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-grpc-ecosystem-grpc-gateway-v2-ba181afe4e6b4638",
          "PackageVersion": "v2.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "46d46c89a1af5b173077ccb7062459c6cca53d3f212d667948f71f23edc80cd9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc-ecosystem:grpc-gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc-ecosystem:grpc_gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc_ecosystem:grpc-gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc_ecosystem:grpc_gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc:grpc-gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc:grpc_gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/grpc-ecosystem/grpc-gateway/v2@v2.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/go-version",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-go-version-f0be5324b4c67212",
          "PackageVersion": "v1.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7de4d37c53678cff7aeeb942c4cfc8f60ef4d6353e44def860ac7698e90879e9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go-version:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go_version:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/go-version@v1.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/golang-lru/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-golang-lru-v2-dda3f249e7cc7b5d",
          "PackageVersion": "v2.0.6",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "df18bf09a7ddd4d6a81274bfc83b2c222b95783572c14d107451a5dda41a4073"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:golang-lru\\/v2:v2.0.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:golang_lru\\/v2:v2.0.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/golang-lru/v2@v2.0.6",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/hcl",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-hcl-b5b4071cfbdaabb0",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d009e5ce3a62e2f11ab1378d167da62c98134b0b74fbab1fb224c6f2a7161b1e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:hcl:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/hcl@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/imdario/mergo",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-imdario-mergo-4e2202ad6fc3fe39",
          "PackageVersion": "v0.3.13",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "945ccfe7b6ea4bfc2ca8ab2c0869ad2c06fc034c0a8cb1abbdedaadcf3d57019"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:imdario:mergo:v0.3.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/imdario/mergo@v0.3.13",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/jmespath/go-jmespath",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-jmespath-go-jmespath-cad4d18026354426",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "04480b9f97298e7f14375980c38363c03ad2df939d79bc84b457bef583e84148"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:jmespath:go-jmespath:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:jmespath:go_jmespath:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/jmespath/go-jmespath@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/josharian/intern",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-josharian-intern-bbb07ac88785bfd3",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be54b8cf9e2849d8e6d1b823462808f86d47a45fad23ef6b1392cbcce83c1e66"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:josharian:intern:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/josharian/intern@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/json-iterator/go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-json-iterator-go-a56f7aa7b7582cd",
          "PackageVersion": "v1.1.12",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3d5f29788e1ad32b27733ae0f8bb71ca40fc2df298f4c2fabb68e7c5a127ae73"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json-iterator:go:v1.1.12:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json_iterator:go:v1.1.12:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json:go:v1.1.12:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/json-iterator/go@v1.1.12",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/klauspost/compress",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-klauspost-compress-36c69c2b514333aa",
          "PackageVersion": "v1.16.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "205576a14354cd96b3f97caeb31a4bce9cd2f0fb79ae1d19d7a168aff7639722"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klauspost:compress:v1.16.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/klauspost/compress@v1.16.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/backend",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-backend-17b9eaf39b35e7f4",
          "PackageVersion": "v0.0.15",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2ce408870bbeb605e39b840638b9cab8fc4ff333a4a9decd6a241b6e7615a021"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:backend:v0.0.15:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/backend@v0.0.15",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/go-logger",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-go-logger-6875216f23a75191",
          "PackageVersion": "v0.0.21",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e19448130dd41941fa046fdc1f7ca2a858a9cd049f180a02af196c66e937ef2b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:go-logger:v0.0.21:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:go_logger:v0.0.21:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/go-logger@v0.0.21",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/k8s-interface",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-k8s-interface-84af6b26dad205da",
          "PackageVersion": "v0.0.148",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bed5c3523bc2a30e7031d0ef6f973f4ddf52a5a7de46ab15fcb9ce77435556c1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:k8s-interface:v0.0.148:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:k8s_interface:v0.0.148:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/k8s-interface@v0.0.148",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/opa-utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-opa-utils-7d70f3119ad494c1",
          "PackageVersion": "v0.0.270",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0d74f0fa9eef244e38b3c6ed625731a89769905957ba129ebde489584142d233"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:opa-utils:v0.0.270:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:opa_utils:v0.0.270:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/opa-utils@v0.0.270",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/operator",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-operator-194a68fcf907cb11",
          "PackageVersion": "v0.0.0-20231128162052-c220fcf51d6f",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:operator:v0.0.0-20231128162052-c220fcf51d6f:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/operator@v0.0.0-20231128162052-c220fcf51d6f",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/rbac-utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-rbac-utils-6cf2adb7a18e565b",
          "PackageVersion": "v0.0.20",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d4c331b02b026779ed0e2f1ff59618718f8aedbbf9d1b0d6e59be71a784c849c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:rbac-utils:v0.0.20:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:rbac_utils:v0.0.20:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/rbac-utils@v0.0.20",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/storage",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-storage-80809200d093f1cf",
          "PackageVersion": "v0.0.29",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e783d1d91aefc01fa993e5b5bab4bd218af2b637fe571c80bf49223430dd6622"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:storage:v0.0.29:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/storage@v0.0.29",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kylelemons/godebug",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kylelemons-godebug-96af403c24c9d933",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "44f36bb215880c8e86da0456f441e2956b65ed9e926f5051d31ba74817f448d7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kylelemons:godebug:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kylelemons/godebug@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/magiconair/properties",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-magiconair-properties-44f901fdd4eb287b",
          "PackageVersion": "v1.8.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "21e4176408907292fd9a07007b536ee9c5fd2cbc3a1311072a337455076f3c36"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:magiconair:properties:v1.8.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/magiconair/properties@v1.8.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mailru/easyjson",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mailru-easyjson-c5cf25ba887dac7f",
          "PackageVersion": "v0.7.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "506600bcac5edec06c103ccef1979639294841f5859716f32d97bb87015446bd"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mailru:easyjson:v0.7.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mailru/easyjson@v0.7.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mattn/go-colorable",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mattn-go-colorable-1f5d0ab9e422f645",
          "PackageVersion": "v0.1.13",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7c5038599c5d105e2d5cf65528c2f00fca149c24d3a34f1db94ef0c5e71d12f0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go-colorable:v0.1.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go_colorable:v0.1.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mattn/go-colorable@v0.1.13",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mattn/go-isatty",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mattn-go-isatty-fbf8965b6fbc7bd",
          "PackageVersion": "v0.0.19",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2484ee6d07f430e2dd94646e46afa3b6c0e57a47583e26bd645b01f21fc03cf0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go-isatty:v0.0.19:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go_isatty:v0.0.19:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mattn/go-isatty@v0.0.19",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/matttproud/golang_protobuf_extensions",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-matttproud-golang-protobuf-extensions-81aa733afa532725",
          "PackageVersion": "v1.0.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9a60d5a2b5ccecf0862b0f7872ce7391f03d3d2cb9a44bcd5913f4113d13215a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang-protobuf-extensions:v1.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang_protobuf_extensions:v1.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/matttproud/golang_protobuf_extensions@v1.0.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/go-homedir",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-go-homedir-a66ddac304af67da",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "96e905f738971710c53e4035becaf9ce97355ee3c39ffc059edab9986fb81346"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:go-homedir:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:go_homedir:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/go-homedir@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/mapstructure",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-mapstructure-f83678a001605c7",
          "PackageVersion": "v1.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8de32c648604ff4f6c58b6b3e373cbec6cba46e3230f6789572b9a73967685d6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:mapstructure:v1.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/mapstructure@v1.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/modern-go/concurrent",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-modern-go-concurrent-dabc22e9698edebd",
          "PackageVersion": "v0.0.0-20180306012644-bacd9c7ef1dd",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4d12da67d703ff0f0f561f779ec3d76b556b43a8e5c0be6837c975e1095c35f8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern-go:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern_go:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/modern-go/concurrent@v0.0.0-20180306012644-bacd9c7ef1dd",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/modern-go/reflect2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-modern-go-reflect2-2da79887911f054a",
          "PackageVersion": "v1.0.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c416a0a0bb45b3de02067b7196e29e696813329bcbc42e2eaf79cc682f46cf43"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern-go:reflect2:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern_go:reflect2:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern:reflect2:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/modern-go/reflect2@v1.0.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/munnerz/goautoneg",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-munnerz-goautoneg-80fea4bcf172c634",
          "PackageVersion": "v0.0.0-20191010083416-a7dc8b61c822",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0b7c3d3ea208d35fceab57359d4026f3c30e1dc402f65e6622548c02964cac70"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:munnerz:goautoneg:v0.0.0-20191010083416-a7dc8b61c822:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/munnerz/goautoneg@v0.0.0-20191010083416-a7dc8b61c822",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/oklog/ulid",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-oklog-ulid-f6917aec74718203",
          "PackageVersion": "v1.3.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1067cd0c4c7a32a1f3f01dee355e900226f5511d8b9bdeec1e2de8700e84489e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:oklog:ulid:v1.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/oklog/ulid@v1.3.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/open-policy-agent/opa",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-open-policy-agent-opa-4e7067c30ac253c6",
          "PackageVersion": "v0.55.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b3b566e2987acc3aaa3ff2b3bd44b0f5fb0a56c9bd9616d3661606c714caee6a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open-policy-agent:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open_policy_agent:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open-policy:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open_policy:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/open-policy-agent/opa@v0.55.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/opencontainers/go-digest",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-opencontainers-go-digest-846ff8896d12e8f5",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6a93945ace755b93e586ec86cb3f4509e78120e50303fea75bc3a2ff23a18795"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:go-digest:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:go_digest:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/opencontainers/go-digest@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/opencontainers/image-spec",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-opencontainers-image-spec-cfee96e6a3634ee",
          "PackageVersion": "v1.1.0-rc4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a0ec4a5095a7142e1818708230daa5d71e186837d80534b9638c7f0a07a8d44d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:image-spec:v1.1.0-rc4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:image_spec:v1.1.0-rc4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/opencontainers/image-spec@v1.1.0-rc4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/panjf2000/ants/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-panjf2000-ants-v2-834f3d0cb932d7b",
          "PackageVersion": "v2.8.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0be9ff7fef9a896f241c21312a5a57e97fa8926c4a5cfec358bbadc6e00fbb04"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:panjf2000:ants\\/v2:v2.8.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/panjf2000/ants/v2@v2.8.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pelletier/go-toml/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pelletier-go-toml-v2-74eac3d85b33b70e",
          "PackageVersion": "v2.0.8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d1cb5beacf66137d61d3f961bbe27a38f995783c499fe9189c97368d947db464"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pelletier:go-toml\\/v2:v2.0.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pelletier:go_toml\\/v2:v2.0.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pelletier/go-toml/v2@v2.0.8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pkg/browser",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pkg-browser-3d49a2cd1b7e26cd",
          "PackageVersion": "v0.0.0-20210911075715-681adbf594b8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2a85a68efc3e9ec60ea36f5824af6f0c0eb944613736b3a752d3bb6be445f475"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pkg:browser:v0.0.0-20210911075715-681adbf594b8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pkg/browser@v0.0.0-20210911075715-681adbf594b8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pkg/errors",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pkg-errors-7d7af0f977c8d37e",
          "PackageVersion": "v0.9.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "14404bc75cd2db5e28c298f2eeab017a2c5b51192e850030acae54c0b193c2de"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pkg:errors:v0.9.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pkg/errors@v0.9.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pmezard/go-difflib",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pmezard-go-difflib-f7263862bcd7ab74",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e030700c4d0d1b24280476cb4183f04943e808c591e41133224fdfd6565b0103"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pmezard:go-difflib:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pmezard:go_difflib:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pmezard/go-difflib@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pquerna/cachecontrol",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pquerna-cachecontrol-c753fbcbea8ffc25",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bc15d236e1393183fd209e648ec768f2eabec38d6348f82f6dad83127911c7d9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pquerna:cachecontrol:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pquerna/cachecontrol@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_golang",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-golang-f07c764afdc423b9",
          "PackageVersion": "v1.16.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ca4fe1c7d8436eb187a2f6dc8b8058fa944c7d2bae6adeb6e9e16c1dbeed993f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-golang:v1.16.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_golang:v1.16.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_golang@v1.16.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_model",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-model-c4d4c9500e5184cb",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e654170f770083539705fe16ab4de04eb5c779a5744d0bc67d4a2809fc75caa6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-model:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_model:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_model@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/common",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-common-31ed08c104eed263",
          "PackageVersion": "v0.42.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "10ab1f5c4628e09a563071f9720f8a39459eb894a8bf521df33191f1e788d583"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:common:v0.42.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/common@v0.42.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/procfs",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-procfs-535dadf3258076d9",
          "PackageVersion": "v0.10.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9182b555afd8325badcc219acecc281caa3ffed655945a4a621f8fca6ce25008"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:procfs:v0.10.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/procfs@v0.10.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/rcrowley/go-metrics",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-rcrowley-go-metrics-7d65021540ceb262",
          "PackageVersion": "v0.0.0-20200313005456-10cdbea86bc0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "32457eefb18b50da39a09d237fcef48ad5a6dc3d128e1efe65af606b329ce4b4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:rcrowley:go-metrics:v0.0.0-20200313005456-10cdbea86bc0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:rcrowley:go_metrics:v0.0.0-20200313005456-10cdbea86bc0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/rcrowley/go-metrics@v0.0.0-20200313005456-10cdbea86bc0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/sirupsen/logrus",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-sirupsen-logrus-887f2f34bb498660",
          "PackageVersion": "v1.9.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "76e794409d42daaf6813717bc2f992180695b539948b345ebba7e337cbaacdb4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:sirupsen:logrus:v1.9.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/sirupsen/logrus@v1.9.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/afero",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-afero-25dcedbb2c43910c",
          "PackageVersion": "v1.9.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b2d329392645b3fff42efdbd1ddb829a58b71947e916817763543f6978ffc153"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:afero:v1.9.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/afero@v1.9.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/cast",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-cast-800c4f470cce7d01",
          "PackageVersion": "v1.5.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "47e90eb5f856404e93550cd8fb80fbc092c18247556ac0841714940580582250"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:cast:v1.5.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/cast@v1.5.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/jwalterweatherman",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-jwalterweatherman-24229b12cb858b2f",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b9eeafa02e5b47917c6312394baee3f62e7cd8553842fa366e6aa7a8c6000c59"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:jwalterweatherman:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/jwalterweatherman@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/pflag",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-pflag-44794eb552dd2ba2",
          "PackageVersion": "v1.0.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8b2f951543823f56bef3216da3f76b836089e6ed3246807b7d9c370cabff2570"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:pflag:v1.0.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/pflag@v1.0.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/viper",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-viper-6a96ea2bcb944fc5",
          "PackageVersion": "v1.16.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ac6187d170d985d50eaf28835a3988bd4496a5b36a8ac2bc5a4d15c9e7f0f217"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:viper:v1.16.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/viper@v1.16.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/stretchr/testify",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-stretchr-testify-800e455db175efc3",
          "PackageVersion": "v1.8.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "09c5718dfdd0f0f33498750a242767f9e659b66e724307a1479c9e4954107149"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:stretchr:testify:v1.8.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/stretchr/testify@v1.8.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/stripe/stripe-go/v74",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-stripe-stripe-go-v74-d11a7d86a32f1a9",
          "PackageVersion": "v74.28.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "22dccf3f2f9c8cc29b4773a28649edffc76fe8f00da778534e1506663845f657"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:stripe:stripe-go\\/v74:v74.28.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:stripe:stripe_go\\/v74:v74.28.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/stripe/stripe-go/v74@v74.28.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/subosito/gotenv",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-subosito-gotenv-5931810e3195766b",
          "PackageVersion": "v1.4.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5f54ee04b00c0c56da4c00a180204bbb70d4dd43f210ba671768e3276733fd2f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:subosito:gotenv:v1.4.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/subosito/gotenv@v1.4.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/tchap/go-patricia/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-tchap-go-patricia-v2-b68131293fc7cf13",
          "PackageVersion": "v2.3.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "eab429dfd96021867e30799d12ae31cee935b7b39d0b7e73ff19b404685391eb"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tchap:go-patricia\\/v2:v2.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tchap:go_patricia\\/v2:v2.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/tchap/go-patricia/v2@v2.3.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/uptrace/opentelemetry-go-extra/otelutil",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-uptrace-opentelemetry-go-extra-otelutil-35e4df6ba03aa024",
          "PackageVersion": "v0.2.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "08dce758792b6c0ea8d6ad87fc1b07e2d2077f8cdb28db6775ea15f801fccf45"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry-go-extra\\/otelutil:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry_go_extra\\/otelutil:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/uptrace/opentelemetry-go-extra/otelutil@v0.2.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/uptrace/opentelemetry-go-extra/otelzap",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-uptrace-opentelemetry-go-extra-otelzap-40674e1a3d15e5d5",
          "PackageVersion": "v0.2.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bb2ad6d3aa098b8896be18cf2d57e4e2aad23f6666d00328cca2839a9ea2e291"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry-go-extra\\/otelzap:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry_go_extra\\/otelzap:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/uptrace/opentelemetry-go-extra/otelzap@v0.2.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/uptrace/uptrace-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-uptrace-uptrace-go-d4d6d4da68037873",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "458d79ab2d7d0b48ab6ded940b141b8de9e4f16c9476f515ef9e91f59a6a0862"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:uptrace-go:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:uptrace_go:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/uptrace/uptrace-go@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/vbatts/tar-split",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-vbatts-tar-split-57b199907de75eb3",
          "PackageVersion": "v0.11.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "84b16ab0e2d0d52b29a503533299293d70a52c37c2d80dd9832f4e514f9155c9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:vbatts:tar-split:v0.11.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:vbatts:tar_split:v0.11.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/vbatts/tar-split@v0.11.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/xeipuuv/gojsonpointer",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-xeipuuv-gojsonpointer-b662000929102115",
          "PackageVersion": "v0.0.0-20190905194746-02993c407bfb",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cc658502d88c732af2507a148d4257d3f96dd47dbe8b629ada7f83dc322648da"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:xeipuuv:gojsonpointer:v0.0.0-20190905194746-02993c407bfb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/xeipuuv/gojsonpointer@v0.0.0-20190905194746-02993c407bfb",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/xeipuuv/gojsonreference",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-xeipuuv-gojsonreference-f2c9afd845bd70c",
          "PackageVersion": "v0.0.0-20180127040603-bd5ef7bd5415",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "133256807a2fa27b7b36c723a40c57b0303c4bc04c62f7bc639fbb72e444ed1d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:xeipuuv:gojsonreference:v0.0.0-20180127040603-bd5ef7bd5415:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/xeipuuv/gojsonreference@v0.0.0-20180127040603-bd5ef7bd5415",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/yashtewari/glob-intersection",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-yashtewari-glob-intersection-2d2f2be6eee75fa1",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f22b8774df3cc98b82cc2763b748037bee9b02153005e116a93844c6ee784458"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:yashtewari:glob-intersection:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:yashtewari:glob_intersection:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/yashtewari/glob-intersection@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.mongodb.org/mongo-driver",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.mongodb.org-mongo-driver-f2ee08413d3d762d",
          "PackageVersion": "v1.11.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "425e8aeaa60713307ac6fbb8f80534068468a9ff6f14f71ce28ecc50874f5bc6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.mongodb.org/mongo-driver@v1.11.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opencensus.io",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opencensus.io-1e63a8698e0f65ec",
          "PackageVersion": "v0.24.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cbbdee494e89d79ed030fda49f6af7d2fc16d40d96d961704821a7015c5e683d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opencensus.io@v0.24.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/contrib/instrumentation/github.com/gorilla/mux/otelmux",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-contrib-instrumentation-github.com-gorilla-mux-otelmux-4745f9b247240f11",
          "PackageVersion": "v0.44.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "41a35494bbe67adb5dd6f9e6147ae005840779aaf158fdee3b8878177a55b643"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:contrib:instrumentation\\/github.com\\/gorilla\\/mux\\/otelmux:v0.44.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/contrib/instrumentation/github.com/gorilla/mux/otelmux@v0.44.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/contrib/instrumentation/runtime",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-contrib-instrumentation-runtime-83c03ae414bd70fe",
          "PackageVersion": "v0.44.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4d7bb6d272f8c987c99507aa1bf0f721ae9bd29d876662df26da3d86a25343f7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:contrib:instrumentation\\/runtime:v0.44.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/contrib/instrumentation/runtime@v0.44.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-393c9cf52793acb0",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4e0568ccf199d359c7c836712b95863c507d41ec5e4cc5c41fbfad2029567f3b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlpmetric",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlpmetric-65fdaf0c4c545529",
          "PackageVersion": "v0.41.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "93493b84534377c2b888e3095e3eecf2c1da0b89a14e501ea694666572e067a9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlpmetric:v0.41.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlpmetric@v0.41.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlpmetric-otlpmetricgrpc-c0789aa8a0081aed",
          "PackageVersion": "v0.41.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1e06c34c3f298a815d63735173f602bec5a3a903edc1e1b25f16b7d8b8274cec"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlpmetric\\/otlpmetricgrpc:v0.41.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc@v0.41.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlptrace",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlptrace-975257d31059ea74",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "200b65fbb82e6b5df8c5c5773627838491e38ce55e2615c09d87ffd21b308d46"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlptrace:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlptrace@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlptrace-otlptracegrpc-cdbdea30cacdf8b7",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c84df66b2ee6246da579ccdf444121a16dd57d2648bc7681fa0bd5a35a3c0d0f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlptrace\\/otlptracegrpc:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/stdout/stdouttrace",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-stdout-stdouttrace-54a1326bec80c5c5",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "852596bc38d71d52eaf4392607eefb7e5f2fefeb7ec98892f9e3648a99432b9e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/stdout\\/stdouttrace:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/stdout/stdouttrace@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/metric",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-metric-e6d38d7b810f0178",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "270573c3de146266f1dde8fef82c0b51067110e0c38ffa4eb930afce1b51ad24"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:metric:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/metric@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/sdk",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-sdk-4590154c5077caa6",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7b76c0074c01dcc9631f7f2c1f3a55fea5ab393085add645d9cb7d17cac191c6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:sdk:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/sdk@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/sdk/metric",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-sdk-metric-58f58ddeb286a5ac",
          "PackageVersion": "v0.41.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "737b00b7dfe94397d22147e5d203ed0a55771e1135f03095cc1c83df747fcec9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:sdk\\/metric:v0.41.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/sdk/metric@v0.41.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/trace",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-trace-a2c8076da830802c",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "358f9ccf06c76e69ddc688d310a892307906d8294d1f63f099c1eb768d09635d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:trace:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/trace@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/proto/otlp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-proto-otlp-e4a4e8cb93d4ad2a",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4f44d7d2d99753c6b709b357cc4286794e6621539d7f4a3290ffaeda521553f2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:proto:otlp:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/proto/otlp@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.uber.org/multierr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.uber.org-multierr-848eb2fe88157327",
          "PackageVersion": "v1.11.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6e55d72644b14927c1541942efaa71a9e3be2cddda0df2d0a3edf4f7126cb4ed"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.uber.org/multierr@v1.11.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.uber.org/zap",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.uber.org-zap-904b613e7b5d591a",
          "PackageVersion": "v1.26.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b08ee4e8bf795ce292dbcd4d85528e14250d22fbfd7b4c38045f0ddeefad091a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.uber.org/zap@v1.26.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/crypto",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-crypto-ab0cb64019ebf9a7",
          "PackageVersion": "v0.14.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c01a865f35895ba9b55eb20a9401f41ecd4927bfbd281c2720ef2feba43d7077"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/crypto:v0.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/crypto@v0.14.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/exp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-exp-7da7811321e3ffda",
          "PackageVersion": "v0.0.0-20230728194245-b0cb94b80691",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ff244ffb400dee67f90e40f704023a4ce167779d601280c46fca37e63205b60c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/exp:v0.0.0-20230728194245-b0cb94b80691:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/exp@v0.0.0-20230728194245-b0cb94b80691",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/net",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-net-1b342d40b60e45b4",
          "PackageVersion": "v0.17.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a5569771cbb6a333e30977b07ebd52ef1cdaff37174e2b72f5c09d5d06128c83"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/net:v0.17.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/net@v0.17.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/oauth2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-oauth2-55a0c0be8c30ced1",
          "PackageVersion": "v0.12.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b2654f1b18a793e9f5648e699106bccba7d94f4456d0c8023b96c5a5ea72e01e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/oauth2:v0.12.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/oauth2@v0.12.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sync",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sync-b2c8f0786df7cd56",
          "PackageVersion": "v0.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7ed09880cc7acd3fdab0752b3f0f012cbb1c62d1b39ec2c09e3ab9447f4feba1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sync:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sync@v0.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sys",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sys-f4f5ccaeb2c4cdc3",
          "PackageVersion": "v0.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "01ff2728f9ae172a625018d5a14f55db41626855ce72e648db5a74c9c5586061"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sys:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sys@v0.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/term",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-term-fd9689d01298e7a8",
          "PackageVersion": "v0.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6dbf88f5c4df15acc65b9d4c66a055999cbbf89109328b941d351229540b05e9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/term:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/term@v0.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/text",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-text-2dc5eb715f9c0084",
          "PackageVersion": "v0.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "69b950a1251dd2d45d2b165ec0ff3407e05aa9e289b9586e4718ff764aee9f79"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/text:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/text@v0.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/time",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-time-6bd719ba0a1845dc",
          "PackageVersion": "v0.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ae0e6b2cc8cdccc4b546434bcc21b7f1e6a95a19d82c56170d78f680e96bf23e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/time:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/time@v0.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/api",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-api-60677abdf9c88144",
          "PackageVersion": "v0.126.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ab8189abe70074c002ed73fb9e3bd0e2dbe88462e24a5cadb8be014316c867ea"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:api:v0.126.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/api@v0.126.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/appengine",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-appengine-a178682cd4708d17",
          "PackageVersion": "v1.6.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "159475ab47b1830c733f3a7f685f9571c1ab49fc5f3e9901aa320812adebbba7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:appengine:v1.6.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/appengine@v1.6.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-2dbf044f2d34f62a",
          "PackageVersion": "v0.0.0-20230822172742-b8732ec3820d",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "541bb962a28fbfa5e2275f7d7b177c06bf807adcfea34f05f8f2cc9f02501c06"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20230822172742-b8732ec3820d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto@v0.0.0-20230822172742-b8732ec3820d",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto/googleapis/api",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-googleapis-api-7ad2c3c5e7510835",
          "PackageVersion": "v0.0.0-20230913181813-007df8e322eb",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "94ad2895e49cec842c5313b75394e32fd0d696cc691017a687ece907b22a8562"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20230913181813-007df8e322eb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto/googleapis/api@v0.0.0-20230913181813-007df8e322eb",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto/googleapis/rpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-googleapis-rpc-c74ccc187925d224",
          "PackageVersion": "v0.0.0-20230913181813-007df8e322eb",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "22c935b121fb6e8bf1f11b62db064ad14645ea8ada0432bbe2ea322c411514dd"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20230913181813-007df8e322eb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto/googleapis/rpc@v0.0.0-20230913181813-007df8e322eb",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/grpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-grpc-f322ad793d688923",
          "PackageVersion": "v1.58.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0639e95eeb756ed6ed80dffab29f9bac1d8a6e6d8b8cd5e789d62e8c055b4a84"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:grpc:v1.58.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/grpc@v1.58.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-protobuf-d66af9ab8f9e56d7",
          "PackageVersion": "v1.31.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8342c31091e0ac197d37daf5ed1bb7b2a5a1908c76341ebba240473f00bb86cf"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:protobuf:v1.31.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/protobuf@v1.31.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/inf.v0",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-inf.v0-2bfac2f0a6aee70",
          "PackageVersion": "v0.9.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ef73390a86728b764b30ec83950874df50b1e8df4d0c9d95bdf97be840c08037"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/inf.v0@v0.9.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/ini.v1",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-ini.v1-e7c7f3a75e24f137",
          "PackageVersion": "v1.67.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0e09f1fbafa77c4f887f38d410848d7b274f261f405cd36c59b18ff4acc2b0e0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/ini.v1@v1.67.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/mgo.v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-mgo.v2-f955182a789f903c",
          "PackageVersion": "v2.0.0-20190816093944-a6b53ec6cb22",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5693acf88c189d805a167acd01e07c5145ad2f7bc4527cd208bd675633e1aabc"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/mgo.v2@v2.0.0-20190816093944-a6b53ec6cb22",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/square/go-jose.v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-square-go-jose.v2-4a0318c68e545f57",
          "PackageVersion": "v2.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "34693be164e73ca04d521373417ecf61c4cb523a2aee6cca93638a6efc24da22"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/square/go-jose.v2@v2.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/yaml.v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-yaml.v2-2d5d90d59fde74a5",
          "PackageVersion": "v2.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0fcc60c04098ec262fc7e6369f8b01cfddc99fd251bf1762cb2a3c0937ee29a6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/yaml.v2@v2.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/yaml.v3",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-yaml.v3-6ffeec2cc662d498",
          "PackageVersion": "v3.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7f1566fc6cc0cc45aa2c7baf72d23dd4a4bd8613669963a85aed174d8252ec20"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/yaml.v3@v3.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/api",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-api-158b40cd568f928c",
          "PackageVersion": "v0.27.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d290a8fc037d84e35acc12a53547614329a69df2d16d26637791f91f77f46d2b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/api@v0.27.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/apimachinery",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-apimachinery-d5432a6f57a80686",
          "PackageVersion": "v0.27.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "09dc5f943e0017ad727b0ba27747cb97a6cce1adead388d67a5d0894ff9a623b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/apimachinery@v0.27.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/client-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-client-go-5aad05a9de58f34f",
          "PackageVersion": "v0.27.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be3d984ed489e89e0ac5a0bcf0fe2930f11010258c63c82a3eab138142b3be39"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/client-go@v0.27.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/klog/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-klog-v2-fb4fd4109aa21634",
          "PackageVersion": "v2.100.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ed608728ae8af1f3614ea7c184848743decaae724d15931c42f2a9ee03ffb668"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klog:v2:v2.100.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/klog/v2@v2.100.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/kube-openapi",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-kube-openapi-c71a570d5cb1cd78",
          "PackageVersion": "v0.0.0-20230501164219-8b0f38b5fd1f",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "da458f6a43778bf93cd5bd20bc3e42e452769319b55ab4056a759c8722aea868"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/kube-openapi@v0.0.0-20230501164219-8b0f38b5fd1f",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-utils-54ec3fa3ff9a2ea5",
          "PackageVersion": "v0.0.0-20230726121419-3b25d923346b",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b209f7654efcdd20a0b5a4898e971556546a77a1929e54cb2a0a4002db49be92"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/utils@v0.0.0-20230726121419-3b25d923346b",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "netbase",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-netbase-fdbf312837579aa",
          "PackageVersion": "6.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Marco d'Itri \u003cmd@linux.it\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/netbase/copyright, /var/lib/dpkg/status.d/netbase",
          "PackageLicenseConcluded": "GPL-2.0-only",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "GPL-2.0-only",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:netbase:netbase:6.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/netbase@6.3?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/controller-runtime",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-controller-runtime-8cf5f760d7a0ebbe",
          "PackageVersion": "v0.15.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "30bfb901db77a999cc498c59ee002f7ab04b34f48c40489bb73020a7450fa235"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/controller-runtime@v0.15.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/json",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-json-a529ea2388b56a19",
          "PackageVersion": "v0.0.0-20221116044647-bc3834ca7abd",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1033c15c202ca72195e23425a594ae74f78c9abd5b34979f9eea8bb1102c1d9a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/json@v0.0.0-20221116044647-bc3834ca7abd",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/structured-merge-diff/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-structured-merge-diff-v4-9d51b6a001363979",
          "PackageVersion": "v4.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5196d90197d7d30576cebed8668ac3cfa19744e7c3163e8bbea0919b855454a9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured-merge-diff:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured_merge_diff:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured-merge:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured_merge:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/structured-merge-diff/v4@v4.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/yaml",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-yaml-ea3a0c73084d39dd",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6b655c94bcce1abc0e1c3895f047c11a1be31ef3f8e82b56e63e8f3af858186a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/operator",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/yaml@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "tzdata",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-tzdata-a257ef3c84e6537f",
          "PackageVersion": "2021a-1+deb11u10",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: GNU Libc Maintainers \u003cdebian-glibc@lists.debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/tzdata/copyright, /var/lib/dpkg/status.d/tzdata",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tzdata:tzdata:2021a-1\\+deb11u10:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/tzdata@2021a-1+deb11u10?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        }
      ],
      "Files": null,
      "OtherLicenses": [
        {
          "LicenseIdentifier": "LicenseRef-GPL",
          "ExtractedText": "NONE",
          "LicenseName": "GPL",
          "LicenseCrossReferences": null,
          "LicenseComment": ""
        }
      ],
      "Relationships": [
        {
          "RefA": "SPDXRef-DOCUMENT",
          "RefB": "SPDXRef-DOCUMENT",
          "Relationship": "DESCRIBES",
          "RelationshipComment": ""
        }
      ],
      "Annotations": null,
      "Snippets": null,
      "Reviews": null
    }
  },
  "Status": {}
}