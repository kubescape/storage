{
  "name": "gke.gcr.io-metrics-server-v0.5.2-gke.3-sha256-1d20492ca374191e5b6ff4b7712b62b41ab75ce226424974356dc266e6e99e83-e99e83",
  "namespace": "kubescape",
  "uid": "aa7001bf-6b08-4060-b0b0-859e5f5a1b3d",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:44:43Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-metrics-server-sha256-1d20492ca374191e5b6ff4b7712b62",
    "kubescape.io/image-name": "gke-gcr-io-metrics-server"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/metrics-server@sha256:1d20492ca374191e5b6ff4b7712b62b41ab75ce226424974356dc266e6e99e83",
    "kubescape.io/status": ""
  },
  "Spec": {
    "Metadata": {
      "Tool": {
        "Name": "",
        "Version": "v0.76.0"
      },
      "Report": {
        "CreatedAt": null
      }
    },
    "SPDX": {
      "DocumentDescribes": null,
      "SPDXVersion": "SPDX-2.3",
      "DataLicense": "CC0-1.0",
      "SPDXIdentifier": "SPDXRef-DOCUMENT",
      "DocumentName": "gke.gcr.io/metrics-server@sha256:1d20492ca374191e5b6ff4b7712b62b41ab75ce226424974356dc266e6e99e83",
      "DocumentNamespace": "https://anchore.com/syft/image/gke.gcr.io/metrics-server@sha256-1d20492ca374191e5b6ff4b7712b62b41ab75ce226424974356dc266e6e99e83-e5345f15-22c8-44dd-9ff3-480dbee79045",
      "ExternalDocumentReferences": null,
      "DocumentComment": "",
      "CreationInfo": {
        "LicenseListVersion": "3.20",
        "Creators": [
          "Organization: Anchore, Inc",
          "Tool: syft-v0.76.0"
        ],
        "Created": "2023-11-29T12:44:43Z",
        "CreatorComment": ""
      },
      "Packages": [
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "base-files",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-base-files-7114c1f7fd988f4b",
          "PackageVersion": "11.1+deb11u4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Santiago Vila \u003csanvila@debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/base-files/copyright, /var/lib/dpkg/status.d/base",
          "PackageLicenseConcluded": "LicenseRef-GPL",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "LicenseRef-GPL",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base-files:11.1\\+deb11u4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base_files:11.1\\+deb11u4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base-files:11.1\\+deb11u4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base_files:11.1\\+deb11u4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base-files:11.1\\+deb11u4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base_files:11.1\\+deb11u4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/base-files@11.1+deb11u4?arch=amd64\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/NYTimes/gziphandler",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-NYTimes-gziphandler-4ee9f88a8ea4e2ae",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6540e3a5069edbd8f4af2ad2d2efc1f0765f241b414078eac36ad0d9ca944372"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:NYTimes:gziphandler:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/NYTimes/gziphandler@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/PuerkitoBio/purell",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-PuerkitoBio-purell-38f4e9a7e319aaa9",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "58442a96a6866eb3e4c4b2567c1c1099f10013567b38d7432eaacddfcb4d15f2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:PuerkitoBio:purell:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/PuerkitoBio/purell@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/PuerkitoBio/urlesc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-PuerkitoBio-urlesc-82d2c6403a742183",
          "PackageVersion": "v0.0.0-20170810143723-de5bf2ad4578",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "77e05cedae6b2ee7d5fec4a4ffc76782e7ea7a57e1ea39eb8bce6b88c01a17f3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:PuerkitoBio:urlesc:v0.0.0-20170810143723-de5bf2ad4578:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/PuerkitoBio/urlesc@v0.0.0-20170810143723-de5bf2ad4578",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/beorn7/perks",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-beorn7-perks-bd4526f4a5f445ca",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5656ca2a735f57c6c9cdeaa86b870e2aa3ba6d8af75a0299c4ef19d7afa1b0e3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:beorn7:perks:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/beorn7/perks@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/blang/semver",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-blang-semver-53680bbfd79e8899",
          "PackageVersion": "v3.5.1+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7103530a3a75dea2fc282dcd6f1affcb606a6fade85fac1d9e78e925b90ce094"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:blang:semver:v3.5.1\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/blang/semver@v3.5.1+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/cespare/xxhash/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-cespare-xxhash-v2-10574c1fa5cfeea8",
          "PackageVersion": "v2.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e8c9d137c353efe601a54216c47b5e7c564e29300f8068e9412c6a2cd9f4faa6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:cespare:xxhash\\/v2:v2.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/cespare/xxhash/v2@v2.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/coreos/go-semver",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-coreos-go-semver-dd29d0336afe7188",
          "PackageVersion": "v0.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c241cb8b0d163404d99d21bb7a92ecba388c0a03c073dc618c9e2d82703199f3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go-semver:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go_semver:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/coreos/go-semver@v0.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/coreos/go-systemd",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-coreos-go-systemd-24e74de9f6794226",
          "PackageVersion": "v0.0.0-20190321100706-95778dfbb74e",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "59fe87a877d271624df7f6637542b28e8a7899fdd075dfb54efbe5b40bccde6f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go-systemd:v0.0.0-20190321100706-95778dfbb74e:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go_systemd:v0.0.0-20190321100706-95778dfbb74e:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/coreos/go-systemd@v0.0.0-20190321100706-95778dfbb74e",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/coreos/pkg",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-coreos-pkg-1f5d61d8d7b69175",
          "PackageVersion": "v0.0.0-20180928190104-399ea9e2e55f",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "94134e7396ab8efb3c13998edad6e90692e8cb2bbc07a7b8e13ee1272ea9a2d8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:pkg:v0.0.0-20180928190104-399ea9e2e55f:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/coreos/pkg@v0.0.0-20180928190104-399ea9e2e55f",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/davecgh/go-spew",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-davecgh-go-spew-f685edf335340646",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be3f63feed5baa7bc211f24ec1486d94e011aacdfeae41d8635de36164d4f7b7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:davecgh:go-spew:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:davecgh:go_spew:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/davecgh/go-spew@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/emicklei/go-restful",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-emicklei-go-restful-685a6857d0a0c7c1",
          "PackageVersion": "v2.9.5+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b294ed6419390d812f6f1315bad52e4f2875028dabe22caf2dd002aac97f2e39"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:emicklei:go-restful:v2.9.5\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:emicklei:go_restful:v2.9.5\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/emicklei/go-restful@v2.9.5+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/evanphx/json-patch",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-evanphx-json-patch-f35fedbf888517d1",
          "PackageVersion": "v4.9.0+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "90b70e3197ae2c026f2f604f58b3088f9a1a650a1bae402aacbf96159c10b1eb"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:evanphx:json-patch:v4.9.0\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:evanphx:json_patch:v4.9.0\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/evanphx/json-patch@v4.9.0+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-logr/logr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-logr-logr-b3518e628dc2ab01",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2bbfc1d63b7a7c805055de0ec2fd8ca8640295c81fd11dbaebeec2fd08d170b7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-logr:logr:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_logr:logr:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:logr:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-logr/logr@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/jsonpointer",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-jsonpointer-4c71c711f9bcd8e4",
          "PackageVersion": "v0.19.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "819afe088601c94aa372078b5e742eda01d8402f68ef71b65d478e1581080ae6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:jsonpointer:v0.19.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:jsonpointer:v0.19.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:jsonpointer:v0.19.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/jsonpointer@v0.19.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/jsonreference",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-jsonreference-faf78136308796fe",
          "PackageVersion": "v0.19.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d5624fff08b83a3078895f0a55b1fbdeb41aa226a526baaff208ad64bc462ed3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:jsonreference:v0.19.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:jsonreference:v0.19.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:jsonreference:v0.19.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/jsonreference@v0.19.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/spec",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-spec-99c2cdf991816f49",
          "PackageVersion": "v0.20.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b87f5143abddc8f4acda94b2f5f2fc40fb290c5d8030830fb662b97284928ed4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:spec:v0.20.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:spec:v0.20.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:spec:v0.20.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/spec@v0.20.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/swag",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-swag-f8dad61e6a880742",
          "PackageVersion": "v0.19.14",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "826def38e5df8aec398bda7937dc49bdf8efba87e9caf2c0f56afa41f2b91678"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:swag:v0.19.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:swag:v0.19.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:swag:v0.19.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/swag@v0.19.14",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gogo/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gogo-protobuf-46fd0946b555c47e",
          "PackageVersion": "v1.3.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3afd5cbdce7c505ddbe578c19d9bfbfa8a5c4dc40565e6d88d6ce2df8bdd9b84"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gogo:protobuf:v1.3.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gogo/protobuf@v1.3.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/groupcache",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-groupcache-43dbddb6afc52478",
          "PackageVersion": "v0.0.0-20200121045136-8c9f03a8e57e",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d6bee952b69baa9d7c84e05cc01c224ec6e715e4d91d5f5e111fd04f92556716"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:groupcache:v0.0.0-20200121045136-8c9f03a8e57e:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/groupcache@v0.0.0-20200121045136-8c9f03a8e57e",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-protobuf-fa99a36788c979ab",
          "PackageVersion": "v1.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2d454a9027af88550c2aa1dae2d5c82228ff95b86731b3fb167e7029d2a4461e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:protobuf:v1.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/protobuf@v1.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/go-cmp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-go-cmp-b29b00f77eff3962",
          "PackageVersion": "v0.5.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2a1c7bb2fac2a66c71b4706ae63da6a7fc558ec8bc85031f34bbc914096b1a05"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go-cmp:v0.5.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go_cmp:v0.5.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/go-cmp@v0.5.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/gofuzz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-gofuzz-f23568e1a4b6b378",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1ec6bc986d1d438ea28fc4a5d806090d4bf5a00f7f77a564fb72c6f7d39ed368"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:gofuzz:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/gofuzz@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/uuid",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-uuid-89020a7432804bb7",
          "PackageVersion": "v1.1.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "11585d4fed4ab1eca2d7fa5499729a17162c0cdcbd450624316447ebc27f5bb6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:uuid:v1.1.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/uuid@v1.1.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/googleapis/gnostic",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-googleapis-gnostic-9228e9d80021cd70",
          "PackageVersion": "v0.4.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0cb242cb59ffbeb0f81cf8cebd8713f1a6105e93c8ce845938d698c32c9c23e2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:gnostic:v0.4.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/googleapis/gnostic@v0.4.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/grpc-ecosystem/go-grpc-prometheus",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-grpc-ecosystem-go-grpc-prometheus-795887c1e02fce7a",
          "PackageVersion": "v1.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3afb36eb11e42aa573b51a48ac5ffdd8172ecae43f616e0d488a681ad7d7361a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc-ecosystem:go-grpc-prometheus:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc-ecosystem:go_grpc_prometheus:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc_ecosystem:go-grpc-prometheus:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc_ecosystem:go_grpc_prometheus:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc:go-grpc-prometheus:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc:go_grpc_prometheus:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/grpc-ecosystem/go-grpc-prometheus@v1.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/golang-lru",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-golang-lru-4dc20d16ece0368c",
          "PackageVersion": "v0.5.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d2111104c244d5e8ad88b92286b32f455058024a47cdcfc9dd074337e7407205"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:golang-lru:v0.5.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:golang_lru:v0.5.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/golang-lru@v0.5.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/imdario/mergo",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-imdario-mergo-3528ce482837cc94",
          "PackageVersion": "v0.3.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "25ba0192c4708a20095af218255a38e807d5f88008299a5fad2cd52a3e364784"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:imdario:mergo:v0.3.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/imdario/mergo@v0.3.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/josharian/intern",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-josharian-intern-67fdcc99e95cdfcb",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be54b8cf9e2849d8e6d1b823462808f86d47a45fad23ef6b1392cbcce83c1e66"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:josharian:intern:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/josharian/intern@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/json-iterator/go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-json-iterator-go-59b3678504d252d5",
          "PackageVersion": "v1.1.10",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2b3e82be7befdb019d686fd5f3232f7e498d897abd61ad8a52fe2ba2e249afaf"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json-iterator:go:v1.1.10:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json_iterator:go:v1.1.10:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json:go:v1.1.10:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/json-iterator/go@v1.1.10",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mailru/easyjson",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mailru-easyjson-cc65cc6e64e93a0",
          "PackageVersion": "v0.7.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "506600bcac5edec06c103ccef1979639294841f5859716f32d97bb87015446bd"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mailru:easyjson:v0.7.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mailru/easyjson@v0.7.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/matttproud/golang_protobuf_extensions",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-matttproud-golang-protobuf-extensions-5e7ac64c781d173",
          "PackageVersion": "v1.0.2-0.20181231171920-c182affec369",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2345d6f7e7b55d60f175c127895e2b40020e3d4183abaec94828910a018264b2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang-protobuf-extensions:v1.0.2-0.20181231171920-c182affec369:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang_protobuf_extensions:v1.0.2-0.20181231171920-c182affec369:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/matttproud/golang_protobuf_extensions@v1.0.2-0.20181231171920-c182affec369",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/moby/term",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-moby-term-e4fffa1d4acb848b",
          "PackageVersion": "v0.0.0-20201216013528-df9cb8a40635",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "af37f4c0bd021d573c084b20cb2806d0c9fd08d0823d9a8e3dacfc4628876109"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:moby:term:v0.0.0-20201216013528-df9cb8a40635:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/moby/term@v0.0.0-20201216013528-df9cb8a40635",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/modern-go/concurrent",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-modern-go-concurrent-eeec06d3b27ca833",
          "PackageVersion": "v0.0.0-20180306012644-bacd9c7ef1dd",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4d12da67d703ff0f0f561f779ec3d76b556b43a8e5c0be6837c975e1095c35f8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern-go:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern_go:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/modern-go/concurrent@v0.0.0-20180306012644-bacd9c7ef1dd",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/modern-go/reflect2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-modern-go-reflect2-20ef59516317f813",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f5fe35dacfba4666172d665213355580f18aec2d8fa611e3e5126bbdfc7d0162"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern-go:reflect2:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern_go:reflect2:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern:reflect2:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/modern-go/reflect2@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/munnerz/goautoneg",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-munnerz-goautoneg-eda1815536541216",
          "PackageVersion": "v0.0.0-20191010083416-a7dc8b61c822",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0b7c3d3ea208d35fceab57359d4026f3c30e1dc402f65e6622548c02964cac70"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:munnerz:goautoneg:v0.0.0-20191010083416-a7dc8b61c822:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/munnerz/goautoneg@v0.0.0-20191010083416-a7dc8b61c822",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pkg/errors",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pkg-errors-8f01a23354464a55",
          "PackageVersion": "v0.9.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "14404bc75cd2db5e28c298f2eeab017a2c5b51192e850030acae54c0b193c2de"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pkg:errors:v0.9.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pkg/errors@v0.9.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_golang",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-golang-8dfa3ae3c73df949",
          "PackageVersion": "v1.7.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3531b2d496bda41c8efb101e1ffaa25a72eb2adaf78493cd8da554c278e97690"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-golang:v1.7.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_golang:v1.7.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_golang@v1.7.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_model",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-model-11e06c48a90a2bd1",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "baae61d1df86bb18972c92cd001320a76a945833e22ef802cf3d9d511fbf5bf3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-model:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_model:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_model@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/common",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-common-a2de8b2ebcfef355",
          "PackageVersion": "v0.25.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "223258649088f07658b6a037c58c06c83cd20b2d6be0203619187ee2f74e9ad1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:common:v0.25.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/common@v0.25.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/procfs",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-procfs-9b66d639c2722db1",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c07e2f03ba5c8cab99ce317b94cf1ac24e1f9ee24eea275e9995e82a750b531e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:procfs:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/procfs@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/cobra",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-cobra-4255c4f86ae664e3",
          "PackageVersion": "v1.1.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c6085b7ea3e4c73c4fdc2fdfde7e4376901b74a2e3e19138056408dfada5e773"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:cobra:v1.1.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/cobra@v1.1.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/pflag",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-pflag-4f2977dfad825004",
          "PackageVersion": "v1.0.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8b2f951543823f56bef3216da3f76b836089e6ed3246807b7d9c370cabff2570"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:pflag:v1.0.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/pflag@v1.0.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.etcd.io/etcd",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.etcd.io-etcd-75729aca7193cf78",
          "PackageVersion": "v0.5.0-alpha.5.0.20200910180754-dd1b699fc489",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d4914b06ac0881dc8737566d8234c1c0ef9b940ea054e999baba62304b044caa"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.etcd.io/etcd@v0.5.0-alpha.5.0.20200910180754-dd1b699fc489",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.uber.org/atomic",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.uber.org-atomic-176c81058a102f69",
          "PackageVersion": "v1.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "388e6df2c0dad4eafeabc01e13ec8a781fd20d88a84870207159638fd2481136"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.uber.org/atomic@v1.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.uber.org/multierr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.uber.org-multierr-46287877c11a8107",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b053e7d862dcde9a0291fae92171a1043d97d02308a3843fcd250b5eb8fffae7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.uber.org/multierr@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.uber.org/zap",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.uber.org-zap-c6648074a29713b9",
          "PackageVersion": "v1.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9d1e8da0306001febbb3af0d85a5dbb288ccfb6831a774b58569070e5dbba555"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.uber.org/zap@v1.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/crypto",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-crypto-ccf05114044a6f48",
          "PackageVersion": "v0.0.0-20210220033148-5ea612d1eb83",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "fd949c117f127c49941911ecd20c69aad78ee677cd5ba6b1c996c1770f40d768"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/crypto:v0.0.0-20210220033148-5ea612d1eb83:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/crypto@v0.0.0-20210220033148-5ea612d1eb83",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/net",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-net-e6f8a444ecc324d5",
          "PackageVersion": "v0.0.0-20210224082022-3d97a244fca7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3a052ebfc96c4690626c635b4a2cd5c0a5a5cac8da373982f6060c84f55fa853"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/net:v0.0.0-20210224082022-3d97a244fca7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/net@v0.0.0-20210224082022-3d97a244fca7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/oauth2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-oauth2-48f0d31e0095a9f3",
          "PackageVersion": "v0.0.0-20200107190931-bf48bf16ab8d",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4f35d25c1a38da6f6041e9e81376fd046884a60e481b62645391643c86b082dc"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/oauth2:v0.0.0-20200107190931-bf48bf16ab8d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/oauth2@v0.0.0-20200107190931-bf48bf16ab8d",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sync",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sync-f31cf618ed696a1a",
          "PackageVersion": "v0.0.0-20201020160332-67f06af15bc9",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4901706928b9e6b53bbdd36cf58af4677db854d96b17ed3032a4574f84adf1c9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sync:v0.0.0-20201020160332-67f06af15bc9:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sync@v0.0.0-20201020160332-67f06af15bc9",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sys",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sys-f1ab0e4e3c4bef0f",
          "PackageVersion": "v0.0.0-20210426230700-d19ff857e887",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7577cc79d9c6261fd25141634cbb16273dcff9342df6a9d1d751a0788def58ab"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sys:v0.0.0-20210426230700-d19ff857e887:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sys@v0.0.0-20210426230700-d19ff857e887",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/term",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-term-8f921cca57022372",
          "PackageVersion": "v0.0.0-20210220032956-6a3ed077a48d",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "499c6f2c1a133f9c873b716b778cf8beb17e0c15fdbcc55a9dc86cc1aebdb681"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/term:v0.0.0-20210220032956-6a3ed077a48d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/term@v0.0.0-20210220032956-6a3ed077a48d",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/text",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-text-a845a4c298db8a8b",
          "PackageVersion": "v0.3.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8ba79967ece4d1239fd31801a44a4f0f5f2a59c25d6baab5b31b774b4933c944"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/text:v0.3.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/text@v0.3.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/time",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-time-75934ae0e6c06edf",
          "PackageVersion": "v0.0.0-20210220033141-f8bda1e9f3ba",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3bc984d3fb78d7d7a8230853169295907893b3f220a3081f923db901c66bb621"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/time:v0.0.0-20210220033141-f8bda1e9f3ba:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/time@v0.0.0-20210220033141-f8bda1e9f3ba",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-827faccfb83eb04e",
          "PackageVersion": "v0.0.0-20201110150050-8816d57aaa9a",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a4ec20e0ea1a45849c8e64782e52e076d9f2a0761348056186a7b9b8f769208f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20201110150050-8816d57aaa9a:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto@v0.0.0-20201110150050-8816d57aaa9a",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/grpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-grpc-ae23f9386e05e754",
          "PackageVersion": "v1.27.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cef223bb8b2a006bf02aca5440e8709e972a49bce2eff1fa42898d3634cbe2c9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:grpc:v1.27.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/grpc@v1.27.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-protobuf-75d68330e43028d1",
          "PackageVersion": "v1.26.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6f1002db14c1b191a26e7d914e7b57d281f9d312ecab2d4ec40f6d4cbde9fe59"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:protobuf:v1.26.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/protobuf@v1.26.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/inf.v0",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-inf.v0-3c6a1b30bca70b9a",
          "PackageVersion": "v0.9.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ef73390a86728b764b30ec83950874df50b1e8df4d0c9d95bdf97be840c08037"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/inf.v0@v0.9.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/natefinch/lumberjack.v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-natefinch-lumberjack.v2-3fedf7f86de00056",
          "PackageVersion": "v2.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d4b734ecaafba98e14d983e8b818e908bc698b2c48568c6a5e09172e49c0384f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/natefinch/lumberjack.v2@v2.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/yaml.v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-yaml.v2-836b51e071d0209d",
          "PackageVersion": "v2.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0fcc60c04098ec262fc7e6369f8b01cfddc99fd251bf1762cb2a3c0937ee29a6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/yaml.v2@v2.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/api",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-api-b2d869af9347b62f",
          "PackageVersion": "v0.21.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f73a774ac94f441fabab18462aaa93a3a56c3771d7d18a5ed67595e94410f929"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/api@v0.21.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/apimachinery",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-apimachinery-e7b1f13bbdaf2a58",
          "PackageVersion": "v0.21.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e7a6e7b0771435ba1209b0fbefd1868b82e1e641d30c55280eb9c76e12d389ac"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/apimachinery@v0.21.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/apiserver",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-apiserver-d4d088c018af5c3f",
          "PackageVersion": "v0.21.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8843ef276bb09b26fb0b879270e8f57e03ca0b20941a0310539f9444413ceef1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/apiserver@v0.21.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/client-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-client-go-88c4129c948d2894",
          "PackageVersion": "v0.21.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ce456276259581c88f298a96a4c14c8c2505fb8ad15dc7e42a8c904b551edb59"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/client-go@v0.21.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/component-base",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-component-base-6dbc21892195a7c5",
          "PackageVersion": "v0.21.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "89c16a7050eb3bd4be150a46a21cd59baa9c7bdbe5a35df52b4af7361125c624"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/component-base@v0.21.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/klog/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-klog-v2-2d02dfcbca42c276",
          "PackageVersion": "v2.8.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "437826b8cf612848de7d6145605d0c6adf98c8526fb14c98bb0c8d349e42f53b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klog:v2:v2.8.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/klog/v2@v2.8.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/kube-openapi",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-kube-openapi-647eeb1745cf5db8",
          "PackageVersion": "v0.0.0-20210305001622-591a79e4bda7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bc4c75dea8ef699e327ce6d24975bb06b31cfca401053fc9c9e7bc5ed2dfe31d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/kube-openapi@v0.0.0-20210305001622-591a79e4bda7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/metrics",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-metrics-241c78ff4dd0e910",
          "PackageVersion": "v0.21.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "95c733b0d3826f01b838a51bc6e9252bd7eff96400d2b0b12c7f3aacd74082ae"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/metrics@v0.21.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-utils-e05adac10834881d",
          "PackageVersion": "v0.0.0-20201110183641-67b214c5f920",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "09b9d466c338f7b8910b940c5641f0ca5f2cdad07783bc9a4879183e4a607a5c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/utils@v0.0.0-20201110183641-67b214c5f920",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "netbase",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-netbase-fdbf312837579aa",
          "PackageVersion": "6.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Marco d'Itri \u003cmd@linux.it\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/netbase/copyright, /var/lib/dpkg/status.d/netbase",
          "PackageLicenseConcluded": "GPL-2.0-only",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "GPL-2.0-only",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:netbase:netbase:6.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/netbase@6.3?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/apiserver-network-proxy/konnectivity-client",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-apiserver-network-proxy-konnectivity-client-4cdbb4dc62890c34",
          "PackageVersion": "v0.0.22",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7e645f97d589e00a499fb2f136e103e26d2dd7caa2bd540ec4fe9a0181bd27a7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver-network-proxy:konnectivity-client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver-network-proxy:konnectivity_client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver_network_proxy:konnectivity-client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver_network_proxy:konnectivity_client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver-network:konnectivity-client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver-network:konnectivity_client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver_network:konnectivity-client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver_network:konnectivity_client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver:konnectivity-client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:apiserver:konnectivity_client:v0.0.22:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/apiserver-network-proxy/konnectivity-client@v0.0.22",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/metrics-server",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-metrics-server-1cd03bde0843d9a4",
          "PackageVersion": "(devel)",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/metrics-server@(devel)",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/structured-merge-diff/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-structured-merge-diff-v4-bdec08f9705314d3",
          "PackageVersion": "v4.1.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1ebfe1b4a1662446ed3204bf503d0dfa0b6072d02acfcd6dde7bbeb0fcf29e7a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured-merge-diff:v4:v4.1.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured_merge_diff:v4:v4.1.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured-merge:v4:v4.1.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured_merge:v4:v4.1.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured:v4:v4.1.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/structured-merge-diff/v4@v4.1.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/yaml",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-yaml-2401a000e7e6cfe8",
          "PackageVersion": "v1.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "92bfcc09e1562564f0c9a1e847d73c1231fd3ae98e9a817d60689977b9459bf4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /metrics-server",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/yaml@v1.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "tzdata",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-tzdata-a9584c319b263a7a",
          "PackageVersion": "2021a-1+deb11u4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: GNU Libc Maintainers \u003cdebian-glibc@lists.debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/tzdata/copyright, /var/lib/dpkg/status.d/tzdata",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tzdata:tzdata:2021a-1\\+deb11u4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/tzdata@2021a-1+deb11u4?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        }
      ],
      "Files": null,
      "OtherLicenses": [
        {
          "LicenseIdentifier": "LicenseRef-GPL",
          "ExtractedText": "NONE",
          "LicenseName": "GPL",
          "LicenseCrossReferences": null,
          "LicenseComment": ""
        }
      ],
      "Relationships": [
        {
          "RefA": "SPDXRef-DOCUMENT",
          "RefB": "SPDXRef-DOCUMENT",
          "Relationship": "DESCRIBES",
          "RelationshipComment": ""
        }
      ],
      "Annotations": null,
      "Snippets": null,
      "Reviews": null
    }
  },
  "Status": {}
}