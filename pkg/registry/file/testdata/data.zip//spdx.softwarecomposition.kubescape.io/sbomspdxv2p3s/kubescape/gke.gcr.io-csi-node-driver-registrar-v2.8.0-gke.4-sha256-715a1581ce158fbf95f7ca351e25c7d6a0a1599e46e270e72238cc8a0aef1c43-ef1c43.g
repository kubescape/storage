{
  "name": "gke.gcr.io-csi-node-driver-registrar-v2.8.0-gke.4-sha256-715a1581ce158fbf95f7ca351e25c7d6a0a1599e46e270e72238cc8a0aef1c43-ef1c43",
  "namespace": "kubescape",
  "uid": "6e6f4630-228b-4c65-8230-6201b70f1767",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:51Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-csi-node-driver-registrar-sha256-715a1581ce158fbf95f",
    "kubescape.io/image-name": "gke-gcr-io-csi-node-driver-registrar"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/csi-node-driver-registrar@sha256:715a1581ce158fbf95f7ca351e25c7d6a0a1599e46e270e72238cc8a0aef1c43",
    "kubescape.io/status": ""
  },
  "Spec": {
    "Metadata": {
      "Tool": {
        "Name": "",
        "Version": "v0.76.0"
      },
      "Report": {
        "CreatedAt": null
      }
    },
    "SPDX": {
      "DocumentDescribes": null,
      "SPDXVersion": "SPDX-2.3",
      "DataLicense": "CC0-1.0",
      "SPDXIdentifier": "SPDXRef-DOCUMENT",
      "DocumentName": "gke.gcr.io/csi-node-driver-registrar@sha256:715a1581ce158fbf95f7ca351e25c7d6a0a1599e46e270e72238cc8a0aef1c43",
      "DocumentNamespace": "https://anchore.com/syft/image/gke.gcr.io/csi-node-driver-registrar@sha256-715a1581ce158fbf95f7ca351e25c7d6a0a1599e46e270e72238cc8a0aef1c43-970321ed-8099-4b52-b39a-f930c0cd53a0",
      "ExternalDocumentReferences": null,
      "DocumentComment": "",
      "CreationInfo": {
        "LicenseListVersion": "3.20",
        "Creators": [
          "Organization: Anchore, Inc",
          "Tool: syft-v0.76.0"
        ],
        "Created": "2023-11-29T12:45:51Z",
        "CreatorComment": ""
      },
      "Packages": [
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "base-files",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-base-files-4046c56c645e8a80",
          "PackageVersion": "11.1+deb11u7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Santiago Vila \u003csanvila@debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/base-files/copyright, /var/lib/dpkg/status.d/base-files",
          "PackageLicenseConcluded": "LicenseRef-GPL",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "LicenseRef-GPL",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base-files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base_files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base-files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base_files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base-files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base_files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/base-files@11.1+deb11u7?arch=amd64\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/beorn7/perks",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-beorn7-perks-279bc6b9527dda9d",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:beorn7:perks:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/beorn7/perks@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/blang/semver/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-blang-semver-v4-740218de7a3fb13c",
          "PackageVersion": "v4.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:blang:semver\\/v4:v4.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/blang/semver/v4@v4.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/cespare/xxhash/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-cespare-xxhash-v2-7ce8c94da187ef54",
          "PackageVersion": "v2.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:cespare:xxhash\\/v2:v2.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/cespare/xxhash/v2@v2.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/container-storage-interface/spec",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-container-storage-interface-spec-823c1b18b4169a7e",
          "PackageVersion": "v1.7.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:container-storage-interface:spec:v1.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:container_storage_interface:spec:v1.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:container-storage:spec:v1.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:container_storage:spec:v1.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:container:spec:v1.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/container-storage-interface/spec@v1.7.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-logr/logr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-logr-logr-6530db4823d36372",
          "PackageVersion": "v1.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-logr:logr:v1.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_logr:logr:v1.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:logr:v1.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-logr/logr@v1.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gogo/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gogo-protobuf-a5605adf754697f8",
          "PackageVersion": "v1.3.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gogo:protobuf:v1.3.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gogo/protobuf@v1.3.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-protobuf-45edebcf401f13f4",
          "PackageVersion": "v1.5.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:protobuf:v1.5.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/protobuf@v1.5.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubernetes-csi/csi-lib-utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubernetes-csi-csi-lib-utils-61be955ad78680fe",
          "PackageVersion": "v0.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes-csi:csi-lib-utils:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes-csi:csi_lib_utils:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes_csi:csi-lib-utils:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes_csi:csi_lib_utils:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes:csi-lib-utils:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes:csi_lib_utils:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubernetes-csi/csi-lib-utils@v0.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubernetes-csi/node-driver-registrar",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubernetes-csi-node-driver-registrar-90aed1ab9e2f7485",
          "PackageVersion": "v0.0.0-20230427151616-e3aefd1766a2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes-csi:node-driver-registrar:v0.0.0-20230427151616-e3aefd1766a2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes-csi:node_driver_registrar:v0.0.0-20230427151616-e3aefd1766a2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes_csi:node-driver-registrar:v0.0.0-20230427151616-e3aefd1766a2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes_csi:node_driver_registrar:v0.0.0-20230427151616-e3aefd1766a2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes:node-driver-registrar:v0.0.0-20230427151616-e3aefd1766a2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubernetes:node_driver_registrar:v0.0.0-20230427151616-e3aefd1766a2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubernetes-csi/node-driver-registrar@v0.0.0-20230427151616-e3aefd1766a2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/matttproud/golang_protobuf_extensions",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-matttproud-golang-protobuf-extensions-4d3424f54d81601e",
          "PackageVersion": "v1.0.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang-protobuf-extensions:v1.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang_protobuf_extensions:v1.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/matttproud/golang_protobuf_extensions@v1.0.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_golang",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-golang-721a78fab695ec5e",
          "PackageVersion": "v1.14.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-golang:v1.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_golang:v1.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_golang@v1.14.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_model",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-model-bbbdb14f700ff957",
          "PackageVersion": "v0.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-model:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_model:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_model@v0.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/common",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-common-2e7e7d6b56c7361e",
          "PackageVersion": "v0.37.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:common:v0.37.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/common@v0.37.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/procfs",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-procfs-21c75fc2a1c78275",
          "PackageVersion": "v0.8.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:procfs:v0.8.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/procfs@v0.8.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/pflag",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-pflag-af8a4e61d12e83ed",
          "PackageVersion": "v1.0.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:pflag:v1.0.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/pflag@v1.0.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/net",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-net-cebf59873195fe7f",
          "PackageVersion": "v0.8.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/net:v0.8.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/net@v0.8.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sys",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sys-71cd9907a167f992",
          "PackageVersion": "v0.7.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sys:v0.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sys@v0.7.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/text",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-text-25611e1eaf9a2628",
          "PackageVersion": "v0.8.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/text:v0.8.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/text@v0.8.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-bc22a71feca69c1c",
          "PackageVersion": "v0.0.0-20230110181048-76db0878b65f",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20230110181048-76db0878b65f:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto@v0.0.0-20230110181048-76db0878b65f",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/grpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-grpc-46356163ac45f9a9",
          "PackageVersion": "v1.54.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:grpc:v1.54.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/grpc@v1.54.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-protobuf-44e797bd00f86ac8",
          "PackageVersion": "v1.28.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:protobuf:v1.28.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/protobuf@v1.28.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/apimachinery",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-apimachinery-28140b3a9f08ff9f",
          "PackageVersion": "v0.27.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/apimachinery@v0.27.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/component-base",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-component-base-f53b1a3e65365da2",
          "PackageVersion": "v0.27.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/component-base@v0.27.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/klog/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-klog-v2-fef9f04506c37d20",
          "PackageVersion": "v2.90.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klog:v2:v2.90.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/klog/v2@v2.90.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/kubelet",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-kubelet-f2a91639b44c2170",
          "PackageVersion": "v0.27.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /csi-node-driver-registrar",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/kubelet@v0.27.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "netbase",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-netbase-fdbf312837579aa",
          "PackageVersion": "6.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Marco d'Itri \u003cmd@linux.it\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/netbase/copyright, /var/lib/dpkg/status.d/netbase",
          "PackageLicenseConcluded": "GPL-2.0-only",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "GPL-2.0-only",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:netbase:netbase:6.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/netbase@6.3?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "tzdata",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-tzdata-a257ef3c84e6537f",
          "PackageVersion": "2021a-1+deb11u10",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: GNU Libc Maintainers \u003cdebian-glibc@lists.debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/tzdata/copyright, /var/lib/dpkg/status.d/tzdata",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tzdata:tzdata:2021a-1\\+deb11u10:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/tzdata@2021a-1+deb11u10?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        }
      ],
      "Files": null,
      "OtherLicenses": [
        {
          "LicenseIdentifier": "LicenseRef-GPL",
          "ExtractedText": "NONE",
          "LicenseName": "GPL",
          "LicenseCrossReferences": null,
          "LicenseComment": ""
        }
      ],
      "Relationships": [
        {
          "RefA": "SPDXRef-DOCUMENT",
          "RefB": "SPDXRef-DOCUMENT",
          "Relationship": "DESCRIBES",
          "RelationshipComment": ""
        }
      ],
      "Annotations": null,
      "Snippets": null,
      "Reviews": null
    }
  },
  "Status": {}
}