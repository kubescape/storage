{
  "name": "quay.io-kubescape-kubevuln-v0.2.133-bc6d6c",
  "namespace": "kubescape",
  "uid": "879e3095-acb4-4e44-8eb4-a91ee95e6841",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:33Z",
  "labels": {
    "kubescape.io/image-id": "quay-io-kubescape-kubevuln-sha256-6a88bfbe387e9260596aa21c49c0b",
    "kubescape.io/image-name": "quay-io-kubescape-kubevuln"
  },
  "annotations": {
    "kubescape.io/image-id": "quay.io/kubescape/kubevuln@sha256:6a88bfbe387e9260596aa21c49c0b835589777443141ba4154787ceeb5bc6d6c",
    "kubescape.io/status": ""
  },
  "Spec": {
    "Metadata": {
      "Tool": {
        "Name": "",
        "Version": "v0.76.0"
      },
      "Report": {
        "CreatedAt": null
      }
    },
    "SPDX": {
      "DocumentDescribes": null,
      "SPDXVersion": "SPDX-2.3",
      "DataLicense": "CC0-1.0",
      "SPDXIdentifier": "SPDXRef-DOCUMENT",
      "DocumentName": "quay.io/kubescape/kubevuln@sha256:6a88bfbe387e9260596aa21c49c0b835589777443141ba4154787ceeb5bc6d6c",
      "DocumentNamespace": "https://anchore.com/syft/image/quay.io/kubescape/kubevuln@sha256-6a88bfbe387e9260596aa21c49c0b835589777443141ba4154787ceeb5bc6d6c-851a2996-e262-4640-8288-e57408429416",
      "ExternalDocumentReferences": null,
      "DocumentComment": "",
      "CreationInfo": {
        "LicenseListVersion": "3.20",
        "Creators": [
          "Organization: Anchore, Inc",
          "Tool: syft-v0.76.0"
        ],
        "Created": "2023-11-29T12:45:33Z",
        "CreatorComment": ""
      },
      "Packages": [
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "base-files",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-base-files-804e0f6f409b3aac",
          "PackageVersion": "11.1+deb11u8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Santiago Vila \u003csanvila@debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/base-files/copyright, /var/lib/dpkg/status.d/base-files",
          "PackageLicenseConcluded": "LicenseRef-GPL",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "LicenseRef-GPL",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base-files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base_files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base-files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base_files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base-files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base_files:11.1\\+deb11u8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/base-files@11.1+deb11u8?arch=amd64\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "cloud.google.com/go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-cloud.google.com-go-21cb84aa3483eb67",
          "PackageVersion": "v0.110.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ac9c82ee75918368d6199e30489e6763ae464dd609920d1c77fb976fe00223aa"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/cloud.google.com/go@v0.110.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "cloud.google.com/go/compute/metadata",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-cloud.google.com-go-compute-metadata-3f22de3723e3f9dc",
          "PackageVersion": "v0.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9a0e23964ee60808fac57a7d509e1f8c8f55508e6bb9bb86056e5a27b52704c6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:compute\\/metadata:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/cloud.google.com/go/compute/metadata@v0.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "cloud.google.com/go/container",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-cloud.google.com-go-container-f6b28b9f0696fb55",
          "PackageVersion": "v1.24.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "379d6dfdc810245a830ff5bb31bf88be600f1eb7fc01b3f1ec16fb685e2544e1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:container:v1.24.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/cloud.google.com/go/container@v1.24.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "cloud.google.com/go/iam",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-cloud.google.com-go-iam-4fc71c451dcda7df",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "956edfce3d796952176074443aa8d1055f4fb07d19eaef18e3a6b5606bd03f86"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:iam:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/cloud.google.com/go/iam@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "cloud.google.com/go/storage",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-cloud.google.com-go-storage-9ec644cee3bfbc3e",
          "PackageVersion": "v1.30.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b8e74cc40b3c1c4c6a0659cbb674323f4624bdb883a5d1928462adc7a53fa0d3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:storage:v1.30.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/cloud.google.com/go/storage@v1.30.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "command-line-arguments",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-command-line-arguments-e6dc8dae86a2ba07",
          "PackageVersion": "(devel)",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/command-line-arguments@(devel)",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/azcore",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-azcore-5fe10ddd698a7263",
          "PackageVersion": "v1.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f240ea0e7807f839950620ad2230854c66bb3019ec20e905f4871c2271446e39"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/azcore:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/azcore:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/azcore@v1.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/azidentity",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-azidentity-af4976e71fdaba68",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bdc6020337baa75f6a056ecc859c9b22ca83f2c315f23b3437240cf090e756d8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/azidentity:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/azidentity:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/azidentity@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/internal",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-internal-aaca947e8c8e442b",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b17afe724f3883f66565439988d10b22798c80eb2e1b07638d590421d7b43ad6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/internal:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/internal:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/internal@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-resourcemanager-authorization-armauthorization-2cd098c496eb13f8",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "aad45c83963b8cd2788c4ccfab81a958b7d3b291dd35ed992ba2e3c067238265"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-resourcemanager-authorization-armauthorization-v2-21bcb19c5bb0a061",
          "PackageVersion": "v2.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e80e0cf2c985fb2f2733f0d8b0b350cfd9fb9f664668456a7f3f195908ab4242"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization\\/v2:v2.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/resourcemanager\\/authorization\\/armauthorization\\/v2:v2.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/authorization/armauthorization/v2@v2.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/containerservice/armcontainerservice/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Azure-azure-sdk-for-go-sdk-resourcemanager-containerservice-armcontainerservice-v2-5f7f6779c122d968",
          "PackageVersion": "v2.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d6efcad8116fd0cc241ba85ef1162e51c6db78adb6ae4a196e0e2529afe6b195"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure-sdk-for-go\\/sdk\\/resourcemanager\\/containerservice\\/armcontainerservice\\/v2:v2.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Azure:azure_sdk_for_go\\/sdk\\/resourcemanager\\/containerservice\\/armcontainerservice\\/v2:v2.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/containerservice/armcontainerservice/v2@v2.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/AzureAD/microsoft-authentication-library-for-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-AzureAD-microsoft-authentication-library-for-go-9555e220f1d42b2f",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "38186a922be486432a2cfca6584a69926eef80f418d97b07a0491a310d007596"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:AzureAD:microsoft-authentication-library-for-go:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:AzureAD:microsoft_authentication_library_for_go:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/AzureAD/microsoft-authentication-library-for-go@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/CycloneDX/cyclonedx-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-CycloneDX-cyclonedx-go-6878eff410b49601",
          "PackageVersion": "v0.7.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e70d52c631a6f4c4cc353b916c43f2c36d4e6dd6da6a04d617f29f174a874d11"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:CycloneDX:cyclonedx-go:v0.7.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:CycloneDX:cyclonedx_go:v0.7.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/CycloneDX/cyclonedx-go@v0.7.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Masterminds/goutils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Masterminds-goutils-48018428ec7967c1",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e6752b8a2dc53132f976253cd2e9c456f35ebf0d671f8f995780d22d524b4982"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Masterminds:goutils:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Masterminds/goutils@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Masterminds/semver/v3",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Masterminds-semver-v3-315eb5bbc972f796",
          "PackageVersion": "v3.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "dcc12c77448cea3a99a238632d659e058f8a723cbd8ba31001e63b6200cff378"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Masterminds:semver\\/v3:v3.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Masterminds/semver/v3@v3.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/Masterminds/sprig/v3",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-Masterminds-sprig-v3-76c418f200da87c9",
          "PackageVersion": "v3.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "78bd9f64d7b32e89a2d2e38baa342837a05fb030fe7f22ed81b24c023f67e980"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:Masterminds:sprig\\/v3:v3.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/Masterminds/sprig/v3@v3.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/OneOfOne/xxhash",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-OneOfOne-xxhash-8b9f4c88efdbbedb",
          "PackageVersion": "v1.2.8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "df57332bf4c8f6c364c4829f6947c6954e3b040c50d33b4681df6f3f2aa299ff"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:OneOfOne:xxhash:v1.2.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/OneOfOne/xxhash@v1.2.8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/acobaugh/osrelease",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-acobaugh-osrelease-58f0bc4b1580cd6",
          "PackageVersion": "v0.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "61be7d1d00c618d8428f8b2e1da15041f069b39c32a0a2d2497fc9ffe5227d11"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:acobaugh:osrelease:v0.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/acobaugh/osrelease@v0.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/adrg/xdg",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-adrg-xdg-c8515c5f055e733d",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "47346a15c8c7e271390baa13031841b68136211ca30526bad9209bc8f89dbe5b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:adrg:xdg:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/adrg/xdg@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/agnivade/levenshtein",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-agnivade-levenshtein-5918cd6239e5eb7d",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "418f0cf769ebce49abefdf200a8de498ccaa5c5cdd415a712e518f4418a3d0ff"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:agnivade:levenshtein:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/agnivade/levenshtein@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/akyoto/cache",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-akyoto-cache-e41f5c2f98bc831d",
          "PackageVersion": "v1.0.6",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e57195558a22da2f8364b2cfb95217b6c34827fa9a00cd7a5d3d0b6816977769"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:akyoto:cache:v1.0.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/akyoto/cache@v1.0.6",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/go-logger",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-go-logger-d47f2247db061d3a",
          "PackageVersion": "v0.0.0-20220728155337-03b66a5207d8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8a680c03480dd13671ecf49afe9756a9769d06faf3f16b0deb3c92cc27b85d7d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go-logger:v0.0.0-20220728155337-03b66a5207d8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go_logger:v0.0.0-20220728155337-03b66a5207d8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/go-logger@v0.0.0-20220728155337-03b66a5207d8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/go-macholibre",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-go-macholibre-516780888c9ff711",
          "PackageVersion": "v0.0.0-20220308212642-53e6d0aaf6fb",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "883327c7a2c88ed8d9e3a0b46a4aaf797f37585ce1a530f77aa3ad85ac1be6f5"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go-macholibre:v0.0.0-20220308212642-53e6d0aaf6fb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go_macholibre:v0.0.0-20220308212642-53e6d0aaf6fb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/go-macholibre@v0.0.0-20220308212642-53e6d0aaf6fb",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/go-struct-converter",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-go-struct-converter-2c77025dfbd90acf",
          "PackageVersion": "v0.0.0-20221118182256-c68fdcfa2092",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "68cd6b95ca0bcfccb9076af8b532cc8954eb32da5f6343bc11270a2716926847"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go-struct-converter:v0.0.0-20221118182256-c68fdcfa2092:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go_struct_converter:v0.0.0-20221118182256-c68fdcfa2092:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/go-struct-converter@v0.0.0-20221118182256-c68fdcfa2092",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/go-version",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-go-version-eeeb4fd2d6c3cb55",
          "PackageVersion": "v1.2.2-0.20210903204242-51efa5b487c4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ae6646efbb97804fa8da0a3318406850ca57dbb96c92efb1accc25981649b5b8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go-version:v1.2.2-0.20210903204242-51efa5b487c4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:go_version:v1.2.2-0.20210903204242-51efa5b487c4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/go-version@v1.2.2-0.20210903204242-51efa5b487c4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/grype",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-grype-fe4c62f6b3e2421f",
          "PackageVersion": "v0.61.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5a9775297c2e888572de8a6218920146c93113cff8153c5af5a891d92253720a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:grype:v0.61.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/grype@v0.61.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/packageurl-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-packageurl-go-f82df8403921d627",
          "PackageVersion": "v0.1.1-0.20230104203445-02e0a6721501",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "015eea8f031c338afcc05849ab78cb473b5ec37cb02323d345aa65d93d6cf68f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:packageurl-go:v0.1.1-0.20230104203445-02e0a6721501:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:packageurl_go:v0.1.1-0.20230104203445-02e0a6721501:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/packageurl-go@v0.1.1-0.20230104203445-02e0a6721501",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/sqlite",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-sqlite-81108efd3b44e206",
          "PackageVersion": "v1.4.6-0.20220607210448-bcc6ee5c4963",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "beb7f63d81fbeefa95268351d7966e149eb7ab004caab98622dffb56c0612c5f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:sqlite:v1.4.6-0.20220607210448-bcc6ee5c4963:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/sqlite@v1.4.6-0.20220607210448-bcc6ee5c4963",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/stereoscope",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-stereoscope-5790c981569a381",
          "PackageVersion": "v0.0.0-20230323161519-d7551b7f46f5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d88e26fcbe08355572bf4c8146e09a770c4cfa7b89a1a2a3f6204d3f25db48ee"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:stereoscope:v0.0.0-20230323161519-d7551b7f46f5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/stereoscope@v0.0.0-20230323161519-d7551b7f46f5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/anchore/syft",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-anchore-syft-5f5e0cf34509f64",
          "PackageVersion": "v0.76.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0bec934eebc3ad739f99cc92e18768261078bb8ca45b78d91619226e45dd34cb"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:anchore:syft:v0.76.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/anchore/syft@v0.76.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/andybalholm/brotli",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-andybalholm-brotli-8954c8bc2c20cc5a",
          "PackageVersion": "v1.0.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "57b0dd5de26d66c71aa9f36e01d491b91173ba22a51d20bf661df397da98dc96"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:andybalholm:brotli:v1.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/andybalholm/brotli@v1.0.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aquilax/truncate",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aquilax-truncate-6046705cc5c45ce3",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5202064bc53f699e09c8e276877c5c179712434ebe8060678f11f64541c97b45"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aquilax:truncate:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aquilax/truncate@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/armoapi-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-armoapi-go-bdab64942d1609c7",
          "PackageVersion": "v0.0.254",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "fb87e75476d54f04905bdf6deff5e5910013db22796cfaf81c06082203576b1b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:armoapi-go:v0.0.254:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:armoapi_go:v0.0.254:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/armoapi-go@v0.0.254",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/gojay",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-gojay-2d4c81ec6a4b5545",
          "PackageVersion": "v1.2.15",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b12076be702f69c50d930f67cd461929c3f38493b293aff92cad8908d766a196"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:gojay:v1.2.15:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/gojay@v1.2.15",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/utils-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-utils-go-f362a276608afcae",
          "PackageVersion": "v0.0.40",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "15d1fc4f1446d121f785e28bad9d0c8f47aae5d360939828f3f9ad7920a0db06"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils-go:v0.0.40:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils_go:v0.0.40:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/utils-go@v0.0.40",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/armosec/utils-k8s-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-armosec-utils-k8s-go-6551536409b0b44a",
          "PackageVersion": "v0.0.20",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "94b828c24a3925561fe8b178a2c40b80bfbfc3f2d4a6d01175cb528400a197b2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils-k8s-go:v0.0.20:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:armosec:utils_k8s_go:v0.0.20:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/armosec/utils-k8s-go@v0.0.20",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-f3ee1fa3560f70e4",
          "PackageVersion": "v1.44.312",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "965ac495fcdea86fd838b1452a3835c4da59085276c6b6888b73ea4ae3fef799"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go:v1.44.312:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go:v1.44.312:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go@v1.44.312",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-458947740151cb6d",
          "PackageVersion": "v1.19.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "493b3495b6e95eeddbc933dc9d12e086cd831f4ca4f6a283a36ed3cb22522ac3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2:v1.19.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2:v1.19.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2@v1.19.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/config",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-config-27f41e8ce1e731c",
          "PackageVersion": "v1.18.30",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4d30174089f7d6a6055108e45bab2256b4535f5bb1fac00364339ede3b1970c8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/config:v1.18.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/config:v1.18.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/config@v1.18.30",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/credentials",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-credentials-4c9bf4386bc3347e",
          "PackageVersion": "v1.13.29",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "28d802a53846b99c828eaf44baeaa82c37a728a3303bfc755f1d357240daed52"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/credentials:v1.13.29:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/credentials:v1.13.29:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/credentials@v1.13.29",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/feature/ec2/imds",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-feature-ec2-imds-8cc958544be51be3",
          "PackageVersion": "v1.13.6",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "928aed2b5db62ef4d4df80865ff17da09a5e9572a4100da3fcc5b8f0823ef3ef"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/feature\\/ec2\\/imds:v1.13.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/feature\\/ec2\\/imds:v1.13.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/feature/ec2/imds@v1.13.6",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/internal/configsources",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-internal-configsources-2f0168392be07693",
          "PackageVersion": "v1.1.36",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "91b93cd5194fa02e9ee1ca3b710c76140bc7f5381bcf122a0aa8a8b0016207ec"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/internal\\/configsources:v1.1.36:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/internal\\/configsources:v1.1.36:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/internal/configsources@v1.1.36",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/internal/endpoints/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-internal-endpoints-v2-7093de142335d7d8",
          "PackageVersion": "v2.4.30",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "94c97c4b9481f2334207e4adcb6126e259eedc8272b5c78741deea6e67ea28bd"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/internal\\/endpoints\\/v2:v2.4.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/internal\\/endpoints\\/v2:v2.4.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/internal/endpoints/v2@v2.4.30",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/internal/ini",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-internal-ini-223fd1c126708a89",
          "PackageVersion": "v1.3.37",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0578aabcded6b95fe9321cfc0a2be13bc706f227097239e31ee9a27f8ba44347"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/internal\\/ini:v1.3.37:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/internal\\/ini:v1.3.37:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/internal/ini@v1.3.37",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/ecr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-ecr-b59b6e541b4482f",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e5155a9c3f8ff8bd96f56534efff09fc0e76be7422ec5dc294175642db606258"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/ecr:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/ecr:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/ecr@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/eks",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-eks-21bb5950ce326118",
          "PackageVersion": "v1.28.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "480fbdf119de865d8a5dec2f1977362f0da7b37638b7d8dd30798463985c370b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/eks:v1.28.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/eks:v1.28.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/eks@v1.28.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/iam",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-iam-318cb9a037fc61bd",
          "PackageVersion": "v1.19.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f6f0b29e8a82f9d83164aaec8ef0278b2228a6cbf745916c67ac2443ecb1b63f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/iam:v1.19.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/iam:v1.19.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/iam@v1.19.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/internal/presigned-url",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-internal-presigned-url-5e86c2df3f68bacc",
          "PackageVersion": "v1.9.30",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "51c559c4b54d638c9ac829a21bde067b7976a9b73958407fa1ae119a3a10122d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/internal\\/presigned-url:v1.9.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/internal\\/presigned_url:v1.9.30:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/internal/presigned-url@v1.9.30",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/sso",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-sso-84a22c50c71eda9b",
          "PackageVersion": "v1.12.14",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8148f3eedadfcfda819b402590a4ef24705710b8b5c2fc3ed8b03d19f0f602c3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/sso:v1.12.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/sso:v1.12.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/sso@v1.12.14",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/ssooidc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-ssooidc-7791c8a86b7bec92",
          "PackageVersion": "v1.14.14",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f1b12dc55e544fdb9c7561977d9ec233771a4214871a35a74c7b7439e17b9bbb"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/ssooidc:v1.14.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/ssooidc:v1.14.14:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/ssooidc@v1.14.14",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/aws-sdk-go-v2/service/sts",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-aws-sdk-go-v2-service-sts-cec963e342ac40b9",
          "PackageVersion": "v1.20.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "53b87d08fa3231f5683798d48250742e094230fd7400ae2f301b1bb0228cf18c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws-sdk-go-v2\\/service\\/sts:v1.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:aws_sdk_go_v2\\/service\\/sts:v1.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/aws-sdk-go-v2/service/sts@v1.20.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/aws/smithy-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-aws-smithy-go-2d1bbef7fb46507f",
          "PackageVersion": "v1.13.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "860cf45ff0d7d1d1aa4d8a4600ba9726844a463e6843bd79d22e4575378fccef"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:smithy-go:v1.13.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:aws:smithy_go:v1.13.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/aws/smithy-go@v1.13.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/becheran/wildmatch-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-becheran-wildmatch-go-e41381d47434342b",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "984ddd1869139a92ad4f867ef3cb7c452b46e34c8df53fa41441a3d8f6454b30"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:becheran:wildmatch-go:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:becheran:wildmatch_go:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/becheran/wildmatch-go@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/beorn7/perks",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-beorn7-perks-6db4d626294f3fd0",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5656ca2a735f57c6c9cdeaa86b870e2aa3ba6d8af75a0299c4ef19d7afa1b0e3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:beorn7:perks:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/beorn7/perks@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/bgentry/go-netrc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-bgentry-go-netrc-bd71aceb0607748",
          "PackageVersion": "v0.0.0-20140422174119-9fd32a8b3d3d",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c437cd3c0b7c945882d5426ba95deebb2f3ad47093a3bd3ca4331b8c71dd09ab"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:bgentry:go-netrc:v0.0.0-20140422174119-9fd32a8b3d3d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:bgentry:go_netrc:v0.0.0-20140422174119-9fd32a8b3d3d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/bgentry/go-netrc@v0.0.0-20140422174119-9fd32a8b3d3d",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/bmatcuk/doublestar/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-bmatcuk-doublestar-v2-54f4c6ac201dfc7",
          "PackageVersion": "v2.0.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e88ea85224ffb14dbb784d8e15c5aa0612f54b08f2bd0b8eb2cc53e1ad7289d2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:bmatcuk:doublestar\\/v2:v2.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/bmatcuk/doublestar/v2@v2.0.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/bmatcuk/doublestar/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-bmatcuk-doublestar-v4-87418de6323a3e82",
          "PackageVersion": "v4.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1d3bb1cae83c1b215b464adf7c8a7334248ae25b9cd13637c335efcc86611177"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:bmatcuk:doublestar\\/v4:v4.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/bmatcuk/doublestar/v4@v4.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/briandowns/spinner",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-briandowns-spinner-e9e182d68b99555d",
          "PackageVersion": "v1.23.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6a50c5da0b915aa6bf14e6596168e5308c762fa1f4c327b03f1a3f087e0fb760"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:briandowns:spinner:v1.23.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/briandowns/spinner@v1.23.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/cenkalti/backoff/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-cenkalti-backoff-v4-b0d3577ef498cd1",
          "PackageVersion": "v4.2.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cb8399b429e882608fc3df198f2b796baf90c0f2c692242c616e6852aca561b3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:cenkalti:backoff\\/v4:v4.2.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/cenkalti/backoff/v4@v4.2.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/cespare/xxhash/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-cespare-xxhash-v2-95214166ef3ad795",
          "PackageVersion": "v2.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0c2d82675129e58e24dd943cf7d0e575ea60adac9150613a04167f71df428f8e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:cespare:xxhash\\/v2:v2.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/cespare/xxhash/v2@v2.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/containerd/containerd",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-containerd-containerd-809b7e8cd8050372",
          "PackageVersion": "v1.7.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "505da074e367c4ef08e9bc995c38b9b175a25af956dc3fec722edd4d08a6109a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:containerd:containerd:v1.7.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/containerd/containerd@v1.7.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/containerd/stargz-snapshotter/estargz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-containerd-stargz-snapshotter-estargz-aff8978b369c81bf",
          "PackageVersion": "v0.14.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3aa94308add95543ba0b707fe454a40f06e41044caf38910804785c030beeb69"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:containerd:stargz-snapshotter\\/estargz:v0.14.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:containerd:stargz_snapshotter\\/estargz:v0.14.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/containerd/stargz-snapshotter/estargz@v0.14.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/coreos/go-oidc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-coreos-go-oidc-f51f41b67b0ccfa3",
          "PackageVersion": "v2.2.1+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9a1e3cabf06a5ea823547a72d9963b5a75806de9f1463b33f4dd62d58c631c09"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go-oidc:v2.2.1\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:coreos:go_oidc:v2.2.1\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/coreos/go-oidc@v2.2.1+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/davecgh/go-spew",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-davecgh-go-spew-403d35edbb1580ac",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be3f63feed5baa7bc211f24ec1486d94e011aacdfeae41d8635de36164d4f7b7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:davecgh:go-spew:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:davecgh:go_spew:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/davecgh/go-spew@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/distribution/distribution",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-distribution-distribution-3a0011ce200501cd",
          "PackageVersion": "v2.8.2+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "93dfb80ca74e1beaae3c56574ff994b2242b1aef6f602a7e757a6e3e4baa864f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:distribution:distribution:v2.8.2\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/distribution/distribution@v2.8.2+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/cli",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-cli-231c792f73ea3844",
          "PackageVersion": "v23.0.1+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2d1c96213a46ce5d82f5ef6e1b1ce2b29b67c409f5cdf64a5f2d77525d90e683"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:cli:v23.0.1\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/cli@v23.0.1+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/distribution",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-distribution-be41493ecc07d858",
          "PackageVersion": "v2.8.2+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4f775ee6bab4741d63df4ae9d2c036ac447e9b7db6101ce78813c1e99233ba1f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:distribution:v2.8.2\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/distribution@v2.8.2+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/docker",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-docker-85b99b4d8612034",
          "PackageVersion": "v24.0.5+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5a681c1387f1c88e84117c41471b079d95eb3b5a50dec9a2d24fe3868e072de6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:docker:v24.0.5\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/docker@v24.0.5+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/docker-credential-helpers",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-docker-credential-helpers-76d263ba3c6daa1d",
          "PackageVersion": "v0.7.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c6d087b23c688000cd65c76fd692941d7af279f8e5551a96a88864fee5c9a740"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:docker-credential-helpers:v0.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:docker_credential_helpers:v0.7.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/docker-credential-helpers@v0.7.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/go-connections",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-go-connections-c647ba5efb3615b",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "125f7154849e95107b06e16eb2b668ce39e420ce589f309588d2a884016a4494"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go-connections:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go_connections:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/go-connections@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/docker/go-units",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-docker-go-units-ee1b2d1dca059bc6",
          "PackageVersion": "v0.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ebdaf15dc064dbb4af49a6b14ed2e1ffc9657070fcbd81d3ed649d459fe3bebe"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go-units:v0.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:docker:go_units:v0.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/docker/go-units@v0.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/dsnet/compress",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-dsnet-compress-72e734073c59c17f",
          "PackageVersion": "v0.0.2-0.20210315054119-f66993602bf5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "885694c014a8e52bf0e8bec762946eff4944dded016849709cd3b5aa4350c416"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:dsnet:compress:v0.0.2-0.20210315054119-f66993602bf5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/dsnet/compress@v0.0.2-0.20210315054119-f66993602bf5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/dustin/go-humanize",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-dustin-go-humanize-a707ce6815660a85",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1b392163b4f954d8449301f43d52608f3f9f5f5ae106b47ba514f79839297826"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:dustin:go-humanize:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:dustin:go_humanize:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/dustin/go-humanize@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/eapache/go-resiliency",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-eapache-go-resiliency-5e7f5e3fd5f3cbaf",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4512f49e07be7161a5c576d4cc9ef231cabac365c112bd7d74237a1c4086693d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:eapache:go-resiliency:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:eapache:go_resiliency:v1.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/eapache/go-resiliency@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/emicklei/go-restful/v3",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-emicklei-go-restful-v3-36b83af8e6371dff",
          "PackageVersion": "v3.10.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "adce36639613a7b026ec24badf40fb2668518eae1494452e10a7eb0da7386d24"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:emicklei:go-restful\\/v3:v3.10.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:emicklei:go_restful\\/v3:v3.10.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/emicklei/go-restful/v3@v3.10.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/evanphx/json-patch",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-evanphx-json-patch-1e1c45ba738b0be2",
          "PackageVersion": "v4.12.0+incompatible",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e289ea89f95c740f44399e11c55eb8dc3bdfb47e693a52c636d43994f590bbce"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:evanphx:json-patch:v4.12.0\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:evanphx:json_patch:v4.12.0\\+incompatible:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/evanphx/json-patch@v4.12.0+incompatible",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/facebookincubator/nvdtools",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-facebookincubator-nvdtools-e218a4a57f979a3f",
          "PackageVersion": "v0.1.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8db9834f59ddebe93eae5bca86792032892b080cc7a004961392ed1db5f6a854"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:facebookincubator:nvdtools:v0.1.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/facebookincubator/nvdtools@v0.1.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/fatih/color",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-fatih-color-bab23bfd8978e92e",
          "PackageVersion": "v1.15.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "90eaa1e981c1b4af1acb0c467ab306d84ab71fa420a2a7a8d77064d8cbff9c1b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:fatih:color:v1.15.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/fatih/color@v1.15.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/francoispqt/gojay",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-francoispqt-gojay-8257742acb5763d9",
          "PackageVersion": "v1.2.13",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7769b7b058e5a2aa085105374ec1c1823eaa83f0551a54c17870d49b22675ca9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:francoispqt:gojay:v1.2.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/francoispqt/gojay@v1.2.13",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/fsnotify/fsnotify",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-fsnotify-fsnotify-150cd0d98a0b6bd1",
          "PackageVersion": "v1.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9fee56aae1b47dc5a85a9eb13d67c775bb2430241a1671ba3df06b8752b2e076"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:fsnotify:fsnotify:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/fsnotify/fsnotify@v1.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gabriel-vasile/mimetype",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gabriel-vasile-mimetype-8a6d0f1852d42dbc",
          "PackageVersion": "v1.4.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c39a855ba24a073f58dfddd8e2adfbd8ef40edc5127aaba487543b3a10a658a5"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gabriel-vasile:mimetype:v1.4.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gabriel_vasile:mimetype:v1.4.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gabriel:mimetype:v1.4.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gabriel-vasile/mimetype@v1.4.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gammazero/deque",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gammazero-deque-28a3d6f8343b77ee",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4a489ec8d0786e0dbfb9964bc6fc9ad0faba762525c31ee6d93793ec600859a0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gammazero:deque:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gammazero/deque@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gammazero/workerpool",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gammazero-workerpool-90126e6439135b54",
          "PackageVersion": "v1.1.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5a2c4de31cee905a0dd1749e5c5ea9baa12a153976984088f52e96e381d6cbd4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gammazero:workerpool:v1.1.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gammazero/workerpool@v1.1.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/ghodss/yaml",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-ghodss-yaml-51614473348fd268",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c101ca11a8612fac265ddcf0586d7580854290ebf4e5b34e87e4719f4ca78009"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:ghodss:yaml:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/ghodss/yaml@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gin-contrib/sse",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gin-contrib-sse-e532ef3f6616b5ab",
          "PackageVersion": "v0.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "63fca5ffe60d3bc1994a30218ccb12b8bb76f6e5911477476146f9958395f6a1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gin-contrib:sse:v0.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gin_contrib:sse:v0.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gin:sse:v0.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gin-contrib/sse@v0.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gin-gonic/gin",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gin-gonic-gin-2ab08da0ce382bde",
          "PackageVersion": "v1.9.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e227440277109d4e5c07b05e3a43edc637c24b27b40009b547445522a27e2668"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gin-gonic:gin:v1.9.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gin_gonic:gin:v1.9.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gin:gin:v1.9.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gin-gonic/gin@v1.9.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-ini/ini",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-ini-ini-ffc40ccdcbcf8ec",
          "PackageVersion": "v1.67.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cfa66b4c466a496393c87d8596094d6cd8004721c6f282d6f603042ea2abd3a0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-ini:ini:v1.67.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_ini:ini:v1.67.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:ini:v1.67.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-ini/ini@v1.67.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-logr/logr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-logr-logr-3bd7a3ac0a08478b",
          "PackageVersion": "v1.2.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "834d46482c220f0db14997e3276fd3f4cf92ea915d70db4562ca7e638dc76034"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-logr:logr:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_logr:logr:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:logr:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-logr/logr@v1.2.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-logr/stdr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-logr-stdr-beb84b5885682e84",
          "PackageVersion": "v1.2.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8525b11e8a93816d92daa19cd0b4c0239eb7299e582984614f730529931b8da8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-logr:stdr:v1.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_logr:stdr:v1.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:stdr:v1.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-logr/stdr@v1.2.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/jsonpointer",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-jsonpointer-c3ae1c2f0da0c459",
          "PackageVersion": "v0.19.6",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "782b377f1a088b75a1eafb6098b4ce8dd852a62aa9850f8368f9f7f0dd9976b1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:jsonpointer:v0.19.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:jsonpointer:v0.19.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:jsonpointer:v0.19.6:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/jsonpointer@v0.19.6",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/jsonreference",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-jsonreference-d7301d4658f9df2b",
          "PackageVersion": "v0.20.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1412e7cb2802e3f21966bf3dde88a899cf576a0868bde613acb0b517ce87203f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:jsonreference:v0.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:jsonreference:v0.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:jsonreference:v0.20.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/jsonreference@v0.20.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-openapi/swag",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-openapi-swag-11fc73f3ceab23c",
          "PackageVersion": "v0.22.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c8c06a9a743483266f11bffe2b3b9664e5e0965ad74f84800d86ef0da5c7bff8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-openapi:swag:v0.22.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_openapi:swag:v0.22.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:swag:v0.22.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-openapi/swag@v0.22.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-playground/locales",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-playground-locales-27b3ece9d823f4e3",
          "PackageVersion": "v0.14.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "116690ff0b308e295f28b4c40a25f3ed187edc18c585f0c52affe85ec9448c90"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-playground:locales:v0.14.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_playground:locales:v0.14.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:locales:v0.14.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-playground/locales@v0.14.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-playground/universal-translator",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-playground-universal-translator-747f54b0bc84f3d4",
          "PackageVersion": "v0.18.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "05c9e6d19c2c1b259b0b32265effa90099d82bd4b8ef72d016ecc26c36df4856"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-playground:universal-translator:v0.18.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-playground:universal_translator:v0.18.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_playground:universal-translator:v0.18.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_playground:universal_translator:v0.18.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:universal-translator:v0.18.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:universal_translator:v0.18.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-playground/universal-translator@v0.18.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-playground/validator/v10",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-playground-validator-v10-8e0db5856de18531",
          "PackageVersion": "v10.14.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be0bd059edd70b3de021e1439bf1e74c86e3e941a683ffadeb7332194da7e63b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-playground:validator\\/v10:v10.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_playground:validator\\/v10:v10.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:validator\\/v10:v10.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-playground/validator/v10@v10.14.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-restruct/restruct",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-restruct-restruct-3239c6a946175012",
          "PackageVersion": "v1.2.0-alpha",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d8ba78ef84bff7aeb4f92263a55c682ae597d3d26c5c74ab755ecdbf7fe092f7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-restruct:restruct:v1.2.0-alpha:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_restruct:restruct:v1.2.0-alpha:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:restruct:v1.2.0-alpha:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-restruct/restruct@v1.2.0-alpha",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-test/deep",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-test-deep-10fd9b3356c36a4a",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "58e73171d1dcbdd81384d5e3c34b7be8ae361574d4ec7a4d4161e90361c73658"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-test:deep:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_test:deep:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:deep:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-test/deep@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gobwas/glob",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gobwas-glob-bee375bf07b7c8fe",
          "PackageVersion": "v0.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "038c436e58c82d744e87e90e6c88b2e6421a3d80fc7bdeb1d6d80185423927e6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gobwas:glob:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gobwas/glob@v0.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gogo/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gogo-protobuf-23704eb8fa2f07d0",
          "PackageVersion": "v1.3.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3afd5cbdce7c505ddbe578c19d9bfbfa8a5c4dc40565e6d88d6ce2df8bdd9b84"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gogo:protobuf:v1.3.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gogo/protobuf@v1.3.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang-jwt/jwt/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-jwt-jwt-v4-73ba719ea73a24eb",
          "PackageVersion": "v4.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "edc6265b55e5318ee1ee28bb5215320a14a04b9c142449e6f6e6554c6a8e5b38"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang-jwt:jwt\\/v4:v4.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang_jwt:jwt\\/v4:v4.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:jwt\\/v4:v4.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang-jwt/jwt/v4@v4.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/groupcache",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-groupcache-e0ebc4a90474668f",
          "PackageVersion": "v0.0.0-20210331224755-41bb18bfe9da",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a08e710aab02a39eb897c88d53e0f00797a9c66b1aa81fab8462f49b98ed62a1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:groupcache:v0.0.0-20210331224755-41bb18bfe9da:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/groupcache@v0.0.0-20210331224755-41bb18bfe9da",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-protobuf-40b6309a8a30511a",
          "PackageVersion": "v1.5.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2a1ca3295520ed4b2bfdd62c752aa816f78c61de64a3bd83fb300dc251b59a68"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:protobuf:v1.5.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/protobuf@v1.5.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/snappy",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-snappy-1ceefba503be80a4",
          "PackageVersion": "v0.0.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c80197ee1b861d795c2ce12d067178c3b150c00dbac288cd0b039800484b8d03"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:snappy:v0.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/snappy@v0.0.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/gnostic",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-gnostic-6432842802e0501c",
          "PackageVersion": "v0.5.7-v3refs",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1614cc38a8f65618e9a2ec6f589015d532f7d38b8c95bf73703aa497a704239e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:gnostic:v0.5.7-v3refs:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/gnostic@v0.5.7-v3refs",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/go-cmp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-go-cmp-31878403b4e172e9",
          "PackageVersion": "v0.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a1fca1c6f5dc66132c539ba56c588b2a5fd7045a84d464aaedab6ef2d0264d12"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go-cmp:v0.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go_cmp:v0.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/go-cmp@v0.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/go-containerregistry",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-go-containerregistry-b05bb115ff4a81b2",
          "PackageVersion": "v0.14.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cf9f2f32a1f1bb0bc0b15c2f284926541cf64e5801807e64ea4a045c1b65624c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go-containerregistry:v0.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:go_containerregistry:v0.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/go-containerregistry@v0.14.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/gofuzz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-gofuzz-684801c213de614d",
          "PackageVersion": "v1.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c51cb803e46165a88a8c9d5b3dfc10f2c79d080f984b661c0875ba79cec9322d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:gofuzz:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/gofuzz@v1.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/licensecheck",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-licensecheck-ea7efcdd53fe338a",
          "PackageVersion": "v0.3.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "428c60a0391a782e2716bb463758d5ec83e60c21c5348561e787b9852b7ab0fb"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:licensecheck:v0.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/licensecheck@v0.3.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/s2a-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-s2a-go-30cc61dfdb125618",
          "PackageVersion": "v0.1.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d6467fb10337b2b78fbcab37b5702f433a3ae977dc45ea2a16922921c704ece7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:s2a-go:v0.1.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:s2a_go:v0.1.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/s2a-go@v0.1.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/google/uuid",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-google-uuid-3d877d0239e67396",
          "PackageVersion": "v1.3.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2a325a27d8966778ce15921fd4ba9fe256834426ac8e5d010a69c41b191d2dbe"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:uuid:v1.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/google/uuid@v1.3.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/googleapis/enterprise-certificate-proxy",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-googleapis-enterprise-certificate-proxy-cacc861d4cafe624",
          "PackageVersion": "v0.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ca4f7f72a44ab53f705d94ac447f5abab5c4a495fe53a14bb69613742dd1d3a9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:enterprise-certificate-proxy:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:enterprise_certificate_proxy:v0.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/googleapis/enterprise-certificate-proxy@v0.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/googleapis/gax-go/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-googleapis-gax-go-v2-9772dce5ff8ee65a",
          "PackageVersion": "v2.11.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f55f4f59712c5a73e9421bbf3de408912e1e1b33254cb1a0b7cd1c51423c2a2e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:gax-go\\/v2:v2.11.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:googleapis:gax_go\\/v2:v2.11.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/googleapis/gax-go/v2@v2.11.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/gorilla/mux",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-gorilla-mux-c60c43425374e8ff",
          "PackageVersion": "v1.8.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8b8d1aa9f911d61d9294df61a23c15e5903dd7071714ebe474d21e1433f99282"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:gorilla:mux:v1.8.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/gorilla/mux@v1.8.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/grpc-ecosystem/grpc-gateway/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-grpc-ecosystem-grpc-gateway-v2-f7c380c904cd0792",
          "PackageVersion": "v2.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "46d46c89a1af5b173077ccb7062459c6cca53d3f212d667948f71f23edc80cd9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc-ecosystem:grpc-gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc-ecosystem:grpc_gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc_ecosystem:grpc-gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc_ecosystem:grpc_gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc:grpc-gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:grpc:grpc_gateway\\/v2:v2.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/grpc-ecosystem/grpc-gateway/v2@v2.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hako/durafmt",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hako-durafmt-10da52e1d87019f9",
          "PackageVersion": "v0.0.0-20210608085754-5c1018a4e16b",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c0350d0b678a88bdf90db2efb038626e54d45c7c5c38fc10482ce2ef1a5050de"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hako:durafmt:v0.0.0-20210608085754-5c1018a4e16b:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hako/durafmt@v0.0.0-20210608085754-5c1018a4e16b",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/errwrap",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-errwrap-342ca9985b02acf5",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3b1ace7a1ef91145cc63c4c18da8367f35c6678d0b07a20ac38e587865036362"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:errwrap:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/errwrap@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/go-cleanhttp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-go-cleanhttp-89895ce66bf0da90",
          "PackageVersion": "v0.5.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d37e452982168e650bc8544128fb3c4c14288b4c7a77d1b8c5cf677972560194"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go-cleanhttp:v0.5.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go_cleanhttp:v0.5.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/go-cleanhttp@v0.5.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/go-getter",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-go-getter-6d55db552cf3c724",
          "PackageVersion": "v1.7.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "49689258dff8daa76947431d85a39cfdb2d1e3c3cbb8fd5942d60b46533af6e6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go-getter:v1.7.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go_getter:v1.7.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/go-getter@v1.7.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/go-multierror",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-go-multierror-6c7bc123307e95e4",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1f90e412d7fa097745a74374126e540b04295cc5a47bc200d3e943e3c6b0318a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go-multierror:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go_multierror:v1.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/go-multierror@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/go-safetemp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-go-safetemp-bfc11ff5d97aeb45",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d87475f3d78536b8c743210d9d030ca4288102c471cdb4cc220061132131a66a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go-safetemp:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go_safetemp:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/go-safetemp@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/go-version",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-go-version-e2b67818ea86c3ff",
          "PackageVersion": "v1.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7de4d37c53678cff7aeeb942c4cfc8f60ef4d6353e44def860ac7698e90879e9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go-version:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:go_version:v1.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/go-version@v1.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/hashicorp/hcl",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-hashicorp-hcl-e3fd1a5a509ec36d",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d009e5ce3a62e2f11ab1378d167da62c98134b0b74fbab1fb224c6f2a7161b1e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:hashicorp:hcl:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/hashicorp/hcl@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/huandu/xstrings",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-huandu-xstrings-68e43cea85b35393",
          "PackageVersion": "v1.3.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "fc672cb9cd71f0955b27dfeb9727b8c599d501b12419ab93f256de6ea710c2ce"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:huandu:xstrings:v1.3.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/huandu/xstrings@v1.3.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/imdario/mergo",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-imdario-mergo-bdef90f4da8a154f",
          "PackageVersion": "v0.3.13",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "945ccfe7b6ea4bfc2ca8ab2c0869ad2c06fc034c0a8cb1abbdedaadcf3d57019"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:imdario:mergo:v0.3.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/imdario/mergo@v0.3.13",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/jinzhu/copier",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-jinzhu-copier-8d49be1ef521a04f",
          "PackageVersion": "v0.3.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1a5bdf5301e4eb6468920a9536f62c92ed13013085edb007570117a018778898"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:jinzhu:copier:v0.3.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/jinzhu/copier@v0.3.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/jinzhu/inflection",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-jinzhu-inflection-7abf5a3afb1a1d8",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2b7d7b16acee85673c62f4959453020946f7e8efd2f4c08a44323b42444a0ff1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:jinzhu:inflection:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/jinzhu/inflection@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/jinzhu/now",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-jinzhu-now-6bdba8120629667a",
          "PackageVersion": "v1.1.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "fe8f6d94795e3fb80e166b2760dcf74469eacde7c7038ef04292abadd4c8c174"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:jinzhu:now:v1.1.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/jinzhu/now@v1.1.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/jmespath/go-jmespath",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-jmespath-go-jmespath-1a572c077f2a1ad5",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "04480b9f97298e7f14375980c38363c03ad2df939d79bc84b457bef583e84148"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:jmespath:go-jmespath:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:jmespath:go_jmespath:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/jmespath/go-jmespath@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/josharian/intern",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-josharian-intern-fc96c72b018cf126",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be54b8cf9e2849d8e6d1b823462808f86d47a45fad23ef6b1392cbcce83c1e66"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:josharian:intern:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/josharian/intern@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/json-iterator/go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-json-iterator-go-a1cca3bce5948534",
          "PackageVersion": "v1.1.12",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3d5f29788e1ad32b27733ae0f8bb71ca40fc2df298f4c2fabb68e7c5a127ae73"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json-iterator:go:v1.1.12:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json_iterator:go:v1.1.12:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:json:go:v1.1.12:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/json-iterator/go@v1.1.12",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/klauspost/compress",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-klauspost-compress-e6a965bddacdb4d2",
          "PackageVersion": "v1.16.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8942dac9034e45ea1851efb5aad28eab0f42c09bf768d42ef22be8ee5c351d4e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klauspost:compress:v1.16.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/klauspost/compress@v1.16.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/klauspost/pgzip",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-klauspost-pgzip-b6fe255e5f0dadf0",
          "PackageVersion": "v1.2.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "aa7598bef2aa79d385dae947a4c1bbd9742897820b109f24db0c1197f2a6f281"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klauspost:pgzip:v1.2.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/klauspost/pgzip@v1.2.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/knqyf263/go-apk-version",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-knqyf263-go-apk-version-18a022a1e83bf2c3",
          "PackageVersion": "v0.0.0-20200609155635-041fdbb8563f",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1af094e465e11eafbb2de3b3c7f85a1bb1d2219a24977ff41a4a14173b112638"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:knqyf263:go-apk-version:v0.0.0-20200609155635-041fdbb8563f:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:knqyf263:go_apk_version:v0.0.0-20200609155635-041fdbb8563f:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/knqyf263/go-apk-version@v0.0.0-20200609155635-041fdbb8563f",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/knqyf263/go-deb-version",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-knqyf263-go-deb-version-e6dfc22d2d19379",
          "PackageVersion": "v0.0.0-20190517075300-09fca494f03d",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5f871e747e0a9f724fba9030c16ba8e00cd8a75e8fd0ec8b3bd77b3a731973f7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:knqyf263:go-deb-version:v0.0.0-20190517075300-09fca494f03d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:knqyf263:go_deb_version:v0.0.0-20190517075300-09fca494f03d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/knqyf263/go-deb-version@v0.0.0-20190517075300-09fca494f03d",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/knqyf263/go-rpmdb",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-knqyf263-go-rpmdb-6a5987aef8803941",
          "PackageVersion": "v0.0.0-20221030135625-4082a22221ce",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ff0d2101c6aea3f14155a06f34c41d3d980a8d3bb9229de3bc620cd7e55413ba"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:knqyf263:go-rpmdb:v0.0.0-20221030135625-4082a22221ce:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:knqyf263:go_rpmdb:v0.0.0-20221030135625-4082a22221ce:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/knqyf263/go-rpmdb@v0.0.0-20221030135625-4082a22221ce",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/backend",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-backend-c9ed0668242cadb9",
          "PackageVersion": "v0.0.15",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2ce408870bbeb605e39b840638b9cab8fc4ff333a4a9decd6a241b6e7615a021"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:backend:v0.0.15:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/backend@v0.0.15",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/go-logger",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-go-logger-312ab117d3887245",
          "PackageVersion": "v0.0.21",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e19448130dd41941fa046fdc1f7ca2a858a9cd049f180a02af196c66e937ef2b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:go-logger:v0.0.21:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:go_logger:v0.0.21:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/go-logger@v0.0.21",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/k8s-interface",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-k8s-interface-1584cfaada1de839",
          "PackageVersion": "v0.0.135-0.20230730135750-e6e709507847",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "186b92ea913a2866b9abb8fd7e444dde9d5e430d7afe32d43273d1f054f73ba3"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:k8s-interface:v0.0.135-0.20230730135750-e6e709507847:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:k8s_interface:v0.0.135-0.20230730135750-e6e709507847:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/k8s-interface@v0.0.135-0.20230730135750-e6e709507847",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/kubevuln",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-kubevuln-8725ea622adf45f2",
          "PackageVersion": "(devel)",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:kubevuln:\\(devel\\):*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/kubevuln@(devel)",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/opa-utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-opa-utils-4cdee39bce48e4bf",
          "PackageVersion": "v0.0.268",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "988b006e9216d1a224f31af4102b9ff2af60527b4642a250209002b67d619259"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:opa-utils:v0.0.268:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:opa_utils:v0.0.268:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/opa-utils@v0.0.268",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/rbac-utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-rbac-utils-3b2b25f4d8c2d7af",
          "PackageVersion": "v0.0.20",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d4c331b02b026779ed0e2f1ff59618718f8aedbbf9d1b0d6e59be71a784c849c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:rbac-utils:v0.0.20:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:rbac_utils:v0.0.20:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/rbac-utils@v0.0.20",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kubescape/storage",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kubescape-storage-ec93222db913270f",
          "PackageVersion": "v0.0.0-20231016192125-da13f3622eee",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b526fd1f78a3d1b1d54571bf0452397f330582913cd799d7c8ea86dfe741a64a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kubescape:storage:v0.0.0-20231016192125-da13f3622eee:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kubescape/storage@v0.0.0-20231016192125-da13f3622eee",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/kylelemons/godebug",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-kylelemons-godebug-a7d1e521734a458c",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "44f36bb215880c8e86da0456f441e2956b65ed9e926f5051d31ba74817f448d7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:kylelemons:godebug:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/kylelemons/godebug@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/leodido/go-urn",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-leodido-go-urn-d36d7dbe9b20a80a",
          "PackageVersion": "v1.2.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5e5004fdc9bf9aced313f54c56876e4a9341a3273674ec47b393194b000deb74"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:leodido:go-urn:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:leodido:go_urn:v1.2.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/leodido/go-urn@v1.2.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/magiconair/properties",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-magiconair-properties-a82e694cb372dc27",
          "PackageVersion": "v1.8.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "21e4176408907292fd9a07007b536ee9c5fd2cbc3a1311072a337455076f3c36"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:magiconair:properties:v1.8.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/magiconair/properties@v1.8.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mailru/easyjson",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mailru-easyjson-c43b3a7e4ed55559",
          "PackageVersion": "v0.7.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "506600bcac5edec06c103ccef1979639294841f5859716f32d97bb87015446bd"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mailru:easyjson:v0.7.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mailru/easyjson@v0.7.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mattn/go-colorable",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mattn-go-colorable-8546c43d88f46b7e",
          "PackageVersion": "v0.1.13",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7c5038599c5d105e2d5cf65528c2f00fca149c24d3a34f1db94ef0c5e71d12f0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go-colorable:v0.1.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go_colorable:v0.1.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mattn/go-colorable@v0.1.13",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mattn/go-isatty",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mattn-go-isatty-fbec67bc140284f6",
          "PackageVersion": "v0.0.19",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2484ee6d07f430e2dd94646e46afa3b6c0e57a47583e26bd645b01f21fc03cf0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go-isatty:v0.0.19:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go_isatty:v0.0.19:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mattn/go-isatty@v0.0.19",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mattn/go-runewidth",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mattn-go-runewidth-fb70e02431d8e207",
          "PackageVersion": "v0.0.13",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9531a60ec6c062de4398ae8e9e857b12e205d7010814073195deb2a54e0e4a05"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go-runewidth:v0.0.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mattn:go_runewidth:v0.0.13:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mattn/go-runewidth@v0.0.13",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/matttproud/golang_protobuf_extensions",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-matttproud-golang-protobuf-extensions-b5b4bd773bba0021",
          "PackageVersion": "v1.0.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9a60d5a2b5ccecf0862b0f7872ce7391f03d3d2cb9a44bcd5913f4113d13215a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang-protobuf-extensions:v1.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang_protobuf_extensions:v1.0.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/matttproud/golang_protobuf_extensions@v1.0.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mholt/archiver/v3",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mholt-archiver-v3-e052286222153b20",
          "PackageVersion": "v3.5.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ac38ce057f49485e41be8246be3a8ae3bf5a2fbd2a87d0c8a590a5fa4ec2970a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mholt:archiver\\/v3:v3.5.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mholt/archiver/v3@v3.5.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/microsoft/go-rustaudit",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-microsoft-go-rustaudit-aafb2324f29d3b2c",
          "PackageVersion": "v0.0.0-20220730194248-4b17361d90a5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b5044770b4309f0acfab68f642b6bf367ca3c844811b075e05e55d004f645d88"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:microsoft:go-rustaudit:v0.0.0-20220730194248-4b17361d90a5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:microsoft:go_rustaudit:v0.0.0-20220730194248-4b17361d90a5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/microsoft/go-rustaudit@v0.0.0-20220730194248-4b17361d90a5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/copystructure",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-copystructure-d2993d09e87e3feb",
          "PackageVersion": "v1.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be92974cde1ec1c8b4dd596383fabd42f086503b6d04e18121ad795af789246c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:copystructure:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/copystructure@v1.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/go-homedir",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-go-homedir-500b033108f4f2e1",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "96e905f738971710c53e4035becaf9ce97355ee3c39ffc059edab9986fb81346"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:go-homedir:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:go_homedir:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/go-homedir@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/go-testing-interface",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-go-testing-interface-db2db9550a811ac7",
          "PackageVersion": "v1.14.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8eb82c84e85801454d30026229b12eec4a80c20249d89aa9426a4b24ebb4edc5"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:go-testing-interface:v1.14.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:go_testing_interface:v1.14.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/go-testing-interface@v1.14.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/hashstructure/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-hashstructure-v2-c03eb034321b13ba",
          "PackageVersion": "v2.0.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bc6296974609a9437113c77e87c7fa3492dc089ae06e10b835c0f8e8a6af0dde"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:hashstructure\\/v2:v2.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/hashstructure/v2@v2.0.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/mapstructure",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-mapstructure-4e642ed8d4fa88b8",
          "PackageVersion": "v1.5.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8de32c648604ff4f6c58b6b3e373cbec6cba46e3230f6789572b9a73967685d6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:mapstructure:v1.5.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/mapstructure@v1.5.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/mitchellh/reflectwalk",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-mitchellh-reflectwalk-b44636a1b4e28c06",
          "PackageVersion": "v1.0.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1b62f358a8b9db83d681dde62c757c63993bb3a5d4bd3d0679feb3c5221e5da4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:mitchellh:reflectwalk:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/mitchellh/reflectwalk@v1.0.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/modern-go/concurrent",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-modern-go-concurrent-7311969bec707c53",
          "PackageVersion": "v0.0.0-20180306012644-bacd9c7ef1dd",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4d12da67d703ff0f0f561f779ec3d76b556b43a8e5c0be6837c975e1095c35f8"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern-go:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern_go:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern:concurrent:v0.0.0-20180306012644-bacd9c7ef1dd:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/modern-go/concurrent@v0.0.0-20180306012644-bacd9c7ef1dd",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/modern-go/reflect2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-modern-go-reflect2-305c23cedbd1b8ae",
          "PackageVersion": "v1.0.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c416a0a0bb45b3de02067b7196e29e696813329bcbc42e2eaf79cc682f46cf43"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern-go:reflect2:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern_go:reflect2:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:modern:reflect2:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/modern-go/reflect2@v1.0.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/munnerz/goautoneg",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-munnerz-goautoneg-d5a2611e982cb50",
          "PackageVersion": "v0.0.0-20191010083416-a7dc8b61c822",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0b7c3d3ea208d35fceab57359d4026f3c30e1dc402f65e6622548c02964cac70"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:munnerz:goautoneg:v0.0.0-20191010083416-a7dc8b61c822:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/munnerz/goautoneg@v0.0.0-20191010083416-a7dc8b61c822",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/nwaples/rardecode",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-nwaples-rardecode-c453814682ca4631",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bd2c5a63cbd084e715af89a6e5ef179651d64e2338245e74ec0d0a6adab0ecc4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:nwaples:rardecode:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/nwaples/rardecode@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/olekukonko/tablewriter",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-olekukonko-tablewriter-40cc594216181570",
          "PackageVersion": "v0.0.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "3f619af370f7e308b5a3d27a5a1d6646ea9de2617fc7f960052ecdec06c385e7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:olekukonko:tablewriter:v0.0.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/olekukonko/tablewriter@v0.0.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/open-policy-agent/opa",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-open-policy-agent-opa-9ad7f7e77d614d8f",
          "PackageVersion": "v0.55.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b3b566e2987acc3aaa3ff2b3bd44b0f5fb0a56c9bd9616d3661606c714caee6a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open-policy-agent:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open_policy_agent:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open-policy:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open_policy:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:open:opa:v0.55.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/open-policy-agent/opa@v0.55.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/opencontainers/go-digest",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-opencontainers-go-digest-3afd3abd81ff265e",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6a93945ace755b93e586ec86cb3f4509e78120e50303fea75bc3a2ff23a18795"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:go-digest:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:go_digest:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/opencontainers/go-digest@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/opencontainers/image-spec",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-opencontainers-image-spec-4b0cd7980f00a69f",
          "PackageVersion": "v1.1.0-rc4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a0ec4a5095a7142e1818708230daa5d71e186837d80534b9638c7f0a07a8d44d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:image-spec:v1.1.0-rc4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:opencontainers:image_spec:v1.1.0-rc4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/opencontainers/image-spec@v1.1.0-rc4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/openvex/go-vex",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-openvex-go-vex-dc015c14548643c5",
          "PackageVersion": "v0.2.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e35bad769dab1e00060ac1be51b8e67cc1b9096431b35e671aa8abd5e4604ab4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:openvex:go-vex:v0.2.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:openvex:go_vex:v0.2.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/openvex/go-vex@v0.2.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/package-url/packageurl-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-package-url-packageurl-go-5f7e96139dbc23da",
          "PackageVersion": "v0.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "293444d1b2b7b0a6c5280937cb2eb70e97ac914ec2becff1fc36b997e46dcf25"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:package-url:packageurl-go:v0.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:package-url:packageurl_go:v0.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:package_url:packageurl-go:v0.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:package_url:packageurl_go:v0.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:package:packageurl-go:v0.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:package:packageurl_go:v0.1.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/package-url/packageurl-go@v0.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pelletier/go-toml",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pelletier-go-toml-89c35c11a3ed9c17",
          "PackageVersion": "v1.9.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e32050ce41effbb047ab63d0519177331d086311bb2ec3f6db6b3b020777bdef"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pelletier:go-toml:v1.9.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pelletier:go_toml:v1.9.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pelletier/go-toml@v1.9.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pelletier/go-toml/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pelletier-go-toml-v2-65f499f877ce5714",
          "PackageVersion": "v2.0.8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d1cb5beacf66137d61d3f961bbe27a38f995783c499fe9189c97368d947db464"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pelletier:go-toml\\/v2:v2.0.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pelletier:go_toml\\/v2:v2.0.8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pelletier/go-toml/v2@v2.0.8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pierrec/lz4/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pierrec-lz4-v4-f1f7d8c1b58c3ec7",
          "PackageVersion": "v4.1.15",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "30ed3fb9c2619e0abbdbdf5d28bc0832d8137db92848f17a0283180ddf10e2ad"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pierrec:lz4\\/v4:v4.1.15:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pierrec/lz4/v4@v4.1.15",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pkg/browser",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pkg-browser-89376def0bd73594",
          "PackageVersion": "v0.0.0-20210911075715-681adbf594b8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "2a85a68efc3e9ec60ea36f5824af6f0c0eb944613736b3a752d3bb6be445f475"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pkg:browser:v0.0.0-20210911075715-681adbf594b8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pkg/browser@v0.0.0-20210911075715-681adbf594b8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pkg/errors",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pkg-errors-e0cd7376a064c3d3",
          "PackageVersion": "v0.9.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "14404bc75cd2db5e28c298f2eeab017a2c5b51192e850030acae54c0b193c2de"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pkg:errors:v0.9.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pkg/errors@v0.9.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pmezard/go-difflib",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pmezard-go-difflib-195c56e9fcf1f8c0",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e030700c4d0d1b24280476cb4183f04943e808c591e41133224fdfd6565b0103"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pmezard:go-difflib:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pmezard:go_difflib:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pmezard/go-difflib@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/pquerna/cachecontrol",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-pquerna-cachecontrol-b56abeb392e16c14",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bc15d236e1393183fd209e648ec768f2eabec38d6348f82f6dad83127911c7d9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:pquerna:cachecontrol:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/pquerna/cachecontrol@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_golang",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-golang-e6f0090ebd3a665c",
          "PackageVersion": "v1.16.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ca4fe1c7d8436eb187a2f6dc8b8058fa944c7d2bae6adeb6e9e16c1dbeed993f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-golang:v1.16.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_golang:v1.16.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_golang@v1.16.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_model",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-model-48b5c442120d5c73",
          "PackageVersion": "v0.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e654170f770083539705fe16ab4de04eb5c779a5744d0bc67d4a2809fc75caa6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-model:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_model:v0.4.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_model@v0.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/common",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-common-a1a98c9897aff73",
          "PackageVersion": "v0.42.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "10ab1f5c4628e09a563071f9720f8a39459eb894a8bf521df33191f1e788d583"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:common:v0.42.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/common@v0.42.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/procfs",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-procfs-3430221f2f589de",
          "PackageVersion": "v0.10.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9182b555afd8325badcc219acecc281caa3ffed655945a4a621f8fca6ce25008"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:procfs:v0.10.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/procfs@v0.10.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/rcrowley/go-metrics",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-rcrowley-go-metrics-e3453ea0b22722ec",
          "PackageVersion": "v0.0.0-20200313005456-10cdbea86bc0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "32457eefb18b50da39a09d237fcef48ad5a6dc3d128e1efe65af606b329ce4b4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:rcrowley:go-metrics:v0.0.0-20200313005456-10cdbea86bc0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:rcrowley:go_metrics:v0.0.0-20200313005456-10cdbea86bc0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/rcrowley/go-metrics@v0.0.0-20200313005456-10cdbea86bc0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/remyoudompheng/bigfft",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-remyoudompheng-bigfft-dc8c7de73a502707",
          "PackageVersion": "v0.0.0-20200410134404-eec4a21b6bb0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "39d02c4d3cfa3a4158e50c63918c2b0a1c2e46bb85ebd735ebd74f2b6e8d5259"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:remyoudompheng:bigfft:v0.0.0-20200410134404-eec4a21b6bb0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/remyoudompheng/bigfft@v0.0.0-20200410134404-eec4a21b6bb0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/rivo/uniseg",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-rivo-uniseg-eb0ca94eae4b5ae1",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4b5a43f7079906e25d166a303706e98bb049f1335fb725089a3ff45908bbda36"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:rivo:uniseg:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/rivo/uniseg@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/sassoftware/go-rpmutils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-sassoftware-go-rpmutils-ed1913e1b06b578c",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a4a5b41c360c1564396f82503e2237588d76846b15a16d15f3e18ca19888fc91"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:sassoftware:go-rpmutils:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:sassoftware:go_rpmutils:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/sassoftware/go-rpmutils@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/scylladb/go-set",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-scylladb-go-set-2f00a94ab2c08e4d",
          "PackageVersion": "v1.0.3-0.20200225121959-cc7b2070d91e",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "eeae8d4856437867efbed211c01ad4fda7a01182589af7afd1c1c0c28d7bcd94"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:scylladb:go-set:v1.0.3-0.20200225121959-cc7b2070d91e:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:scylladb:go_set:v1.0.3-0.20200225121959-cc7b2070d91e:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/scylladb/go-set@v1.0.3-0.20200225121959-cc7b2070d91e",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/shopspring/decimal",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-shopspring-decimal-45c88c29c360e8b0",
          "PackageVersion": "v1.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "69b4804d7990118c9286ec48e3fbf25b7b55d4caca009cc267fd332d45d86ec4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:shopspring:decimal:v1.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/shopspring/decimal@v1.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/sirupsen/logrus",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-sirupsen-logrus-d073e135da9e6061",
          "PackageVersion": "v1.9.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "76e794409d42daaf6813717bc2f992180695b539948b345ebba7e337cbaacdb4"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:sirupsen:logrus:v1.9.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/sirupsen/logrus@v1.9.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spdx/tools-golang",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spdx-tools-golang-43267e36f07e64e5",
          "PackageVersion": "v0.5.0-rc1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a280927b8f106ad96276a10577e9d2237d3cb7278d4d1e8d26f6ae523dc0a57f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spdx:tools-golang:v0.5.0-rc1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spdx:tools_golang:v0.5.0-rc1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spdx/tools-golang@v0.5.0-rc1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/afero",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-afero-996c5e2b7dee1ff8",
          "PackageVersion": "v1.9.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b2d329392645b3fff42efdbd1ddb829a58b71947e916817763543f6978ffc153"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:afero:v1.9.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/afero@v1.9.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/cast",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-cast-4def9dd3658608c7",
          "PackageVersion": "v1.5.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "47e90eb5f856404e93550cd8fb80fbc092c18247556ac0841714940580582250"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:cast:v1.5.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/cast@v1.5.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/jwalterweatherman",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-jwalterweatherman-db1e3e61a21ec6f9",
          "PackageVersion": "v1.1.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b9eeafa02e5b47917c6312394baee3f62e7cd8553842fa366e6aa7a8c6000c59"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:jwalterweatherman:v1.1.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/jwalterweatherman@v1.1.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/pflag",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-pflag-4a19a0a3b28bf50a",
          "PackageVersion": "v1.0.5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8b2f951543823f56bef3216da3f76b836089e6ed3246807b7d9c370cabff2570"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:pflag:v1.0.5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/pflag@v1.0.5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/spf13/viper",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-spf13-viper-52d90dd80f52c94",
          "PackageVersion": "v1.16.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ac6187d170d985d50eaf28835a3988bd4496a5b36a8ac2bc5a4d15c9e7f0f217"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:spf13:viper:v1.16.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/spf13/viper@v1.16.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/stretchr/testify",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-stretchr-testify-b87a50ee98668e50",
          "PackageVersion": "v1.8.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "09c5718dfdd0f0f33498750a242767f9e659b66e724307a1479c9e4954107149"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:stretchr:testify:v1.8.4:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/stretchr/testify@v1.8.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/stripe/stripe-go/v74",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-stripe-stripe-go-v74-5a88b88da6b585b4",
          "PackageVersion": "v74.28.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "22dccf3f2f9c8cc29b4773a28649edffc76fe8f00da778534e1506663845f657"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:stripe:stripe-go\\/v74:v74.28.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:stripe:stripe_go\\/v74:v74.28.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/stripe/stripe-go/v74@v74.28.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/subosito/gotenv",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-subosito-gotenv-1c7869d19d1e42dc",
          "PackageVersion": "v1.4.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5f54ee04b00c0c56da4c00a180204bbb70d4dd43f210ba671768e3276733fd2f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:subosito:gotenv:v1.4.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/subosito/gotenv@v1.4.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/sylabs/sif/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-sylabs-sif-v2-ebdd0df0d31827c8",
          "PackageVersion": "v2.8.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c21af8573d764577cb9d8c95187a03feb0ff85b17683d396ec12476be588a96f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:sylabs:sif\\/v2:v2.8.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/sylabs/sif/v2@v2.8.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/sylabs/squashfs",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-sylabs-squashfs-1413f087d01dff48",
          "PackageVersion": "v0.6.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e2182f1e70fd2469585b04f46cf60db7dcdacf6de6015dc9b3e544810a111984"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:sylabs:squashfs:v0.6.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/sylabs/squashfs@v0.6.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/tchap/go-patricia/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-tchap-go-patricia-v2-d08e2423b4d5a6c3",
          "PackageVersion": "v2.3.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "eab429dfd96021867e30799d12ae31cee935b7b39d0b7e73ff19b404685391eb"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tchap:go-patricia\\/v2:v2.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tchap:go_patricia\\/v2:v2.3.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/tchap/go-patricia/v2@v2.3.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/therootcompany/xz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-therootcompany-xz-1ec779a350980559",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0a63adb27d426ed9b2622bac6df9a19a4a400044e3d300481fa90261a5fec73c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:therootcompany:xz:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/therootcompany/xz@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/ugorji/go/codec",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-ugorji-go-codec-ae02e1eebdaa74a5",
          "PackageVersion": "v1.2.11",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "04c696a7505be9f1f012d6e9946046278f7cc03f8b2a5352976e4c8dd658e1d5"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:ugorji:go\\/codec:v1.2.11:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/ugorji/go/codec@v1.2.11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/ulikunitz/xz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-ulikunitz-xz-6864e94d1f76a81e",
          "PackageVersion": "v0.5.11",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "92915abafdbb6faca7cc1353fd7cbed64f9f2b85acc2137fe8f3795a11401b0f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:ulikunitz:xz:v0.5.11:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/ulikunitz/xz@v0.5.11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/uptrace/opentelemetry-go-extra/otelutil",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-uptrace-opentelemetry-go-extra-otelutil-7bf733983e4c96e0",
          "PackageVersion": "v0.2.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "08dce758792b6c0ea8d6ad87fc1b07e2d2077f8cdb28db6775ea15f801fccf45"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry-go-extra\\/otelutil:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry_go_extra\\/otelutil:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/uptrace/opentelemetry-go-extra/otelutil@v0.2.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/uptrace/opentelemetry-go-extra/otelzap",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-uptrace-opentelemetry-go-extra-otelzap-b1fe14e9f2ec8bec",
          "PackageVersion": "v0.2.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bb2ad6d3aa098b8896be18cf2d57e4e2aad23f6666d00328cca2839a9ea2e291"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry-go-extra\\/otelzap:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:opentelemetry_go_extra\\/otelzap:v0.2.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/uptrace/opentelemetry-go-extra/otelzap@v0.2.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/uptrace/uptrace-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-uptrace-uptrace-go-6ea0b87835d129f9",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "458d79ab2d7d0b48ab6ded940b141b8de9e4f16c9476f515ef9e91f59a6a0862"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:uptrace-go:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:uptrace:uptrace_go:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/uptrace/uptrace-go@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/vbatts/go-mtree",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-vbatts-go-mtree-d1ff1a1967d58a8b",
          "PackageVersion": "v0.5.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4bf8d895f1bcad9f9ad1b85977e4403577a3cbb33826cf1fabd53e5e8593779c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:vbatts:go-mtree:v0.5.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:vbatts:go_mtree:v0.5.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/vbatts/go-mtree@v0.5.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/vbatts/tar-split",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-vbatts-tar-split-a87cc99d2d9d234b",
          "PackageVersion": "v0.11.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5626ba5ea26bd2171e5b8c1f7f7411cc3e60024fed6ad330ff8640edc4e520c1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:vbatts:tar-split:v0.11.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:vbatts:tar_split:v0.11.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/vbatts/tar-split@v0.11.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/vifraa/gopom",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-vifraa-gopom-a75837b32c2969fa",
          "PackageVersion": "v0.2.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "31854c00cca21b35cf3f2d74130a23cca20bebbd2497965b69efa8ddf16f4043"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:vifraa:gopom:v0.2.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/vifraa/gopom@v0.2.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/wagoodman/go-partybus",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-wagoodman-go-partybus-8207d210645d7ee7",
          "PackageVersion": "v0.0.0-20210627031916-db1f5573bbc5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a614cb3e03110d84e2ceb0522ac35239adb3b61a02d8ab09b1a63ff2c837ac3f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:wagoodman:go-partybus:v0.0.0-20210627031916-db1f5573bbc5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:wagoodman:go_partybus:v0.0.0-20210627031916-db1f5573bbc5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/wagoodman/go-partybus@v0.0.0-20210627031916-db1f5573bbc5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/wagoodman/go-progress",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-wagoodman-go-progress-f3ef1719d5efd61c",
          "PackageVersion": "v0.0.0-20230301185719-21920a456ad5",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "970813b13cb5f2762a0129c7e7cab27d15bf95d8fb1addb3cc1be060fcdd038b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:wagoodman:go-progress:v0.0.0-20230301185719-21920a456ad5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:wagoodman:go_progress:v0.0.0-20230301185719-21920a456ad5:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/wagoodman/go-progress@v0.0.0-20230301185719-21920a456ad5",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/xeipuuv/gojsonpointer",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-xeipuuv-gojsonpointer-f7252ef839a373f5",
          "PackageVersion": "v0.0.0-20190905194746-02993c407bfb",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cc658502d88c732af2507a148d4257d3f96dd47dbe8b629ada7f83dc322648da"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:xeipuuv:gojsonpointer:v0.0.0-20190905194746-02993c407bfb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/xeipuuv/gojsonpointer@v0.0.0-20190905194746-02993c407bfb",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/xeipuuv/gojsonreference",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-xeipuuv-gojsonreference-bcbb189eda93e03a",
          "PackageVersion": "v0.0.0-20180127040603-bd5ef7bd5415",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "133256807a2fa27b7b36c723a40c57b0303c4bc04c62f7bc639fbb72e444ed1d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:xeipuuv:gojsonreference:v0.0.0-20180127040603-bd5ef7bd5415:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/xeipuuv/gojsonreference@v0.0.0-20180127040603-bd5ef7bd5415",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/xi2/xz",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-xi2-xz-e58928fb5bc34ee9",
          "PackageVersion": "v0.0.0-20171230120015-48954b6210f8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "9c83e9070689495608c5416c0efdccf287e6c7dc964e883d05fbc8bb4ab8d65a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:xi2:xz:v0.0.0-20171230120015-48954b6210f8:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/xi2/xz@v0.0.0-20171230120015-48954b6210f8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/yashtewari/glob-intersection",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-yashtewari-glob-intersection-94973fcd0b6816ec",
          "PackageVersion": "v0.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "f22b8774df3cc98b82cc2763b748037bee9b02153005e116a93844c6ee784458"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:yashtewari:glob-intersection:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:yashtewari:glob_intersection:v0.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/yashtewari/glob-intersection@v0.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opencensus.io",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opencensus.io-cfa56e1c966c2e58",
          "PackageVersion": "v0.24.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "cbbdee494e89d79ed030fda49f6af7d2fc16d40d96d961704821a7015c5e683d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opencensus.io@v0.24.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/contrib/instrumentation/github.com/gin-gonic/gin/otelgin",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-contrib-instrumentation-github.com-gin-gonic-gin-otelgin-4e53b2a90e678f6a",
          "PackageVersion": "v0.44.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "bd2bb3c065da2779e6f1ae8919e45cd95dbca8fd4d0788914dca1b854ff3dc5b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:contrib:instrumentation\\/github.com\\/gin-gonic\\/gin\\/otelgin:v0.44.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:contrib:instrumentation\\/github.com\\/gin_gonic\\/gin\\/otelgin:v0.44.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/contrib/instrumentation/github.com/gin-gonic/gin/otelgin@v0.44.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/contrib/instrumentation/runtime",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-contrib-instrumentation-runtime-2cc35573477bee98",
          "PackageVersion": "v0.44.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4d7bb6d272f8c987c99507aa1bf0f721ae9bd29d876662df26da3d86a25343f7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:contrib:instrumentation\\/runtime:v0.44.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/contrib/instrumentation/runtime@v0.44.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-a8d62d4cda3fe6e2",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4e0568ccf199d359c7c836712b95863c507d41ec5e4cc5c41fbfad2029567f3b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlpmetric",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlpmetric-ad557b448853b546",
          "PackageVersion": "v0.41.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "93493b84534377c2b888e3095e3eecf2c1da0b89a14e501ea694666572e067a9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlpmetric:v0.41.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlpmetric@v0.41.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlpmetric-otlpmetricgrpc-c4f1f0199454e50f",
          "PackageVersion": "v0.41.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1e06c34c3f298a815d63735173f602bec5a3a903edc1e1b25f16b7d8b8274cec"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlpmetric\\/otlpmetricgrpc:v0.41.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc@v0.41.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlptrace",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlptrace-aff07fc59291d5b6",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "200b65fbb82e6b5df8c5c5773627838491e38ce55e2615c09d87ffd21b308d46"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlptrace:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlptrace@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-otlp-otlptrace-otlptracegrpc-7c3eb9fd5166fd2b",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c84df66b2ee6246da579ccdf444121a16dd57d2648bc7681fa0bd5a35a3c0d0f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/otlp\\/otlptrace\\/otlptracegrpc:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/exporters/stdout/stdouttrace",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-exporters-stdout-stdouttrace-d331d6edb2fd0395",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "852596bc38d71d52eaf4392607eefb7e5f2fefeb7ec98892f9e3648a99432b9e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:exporters\\/stdout\\/stdouttrace:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/exporters/stdout/stdouttrace@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/metric",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-metric-dfe067703e52a1d9",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "270573c3de146266f1dde8fef82c0b51067110e0c38ffa4eb930afce1b51ad24"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:metric:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/metric@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/sdk",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-sdk-e758fc397d6fbae3",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7b76c0074c01dcc9631f7f2c1f3a55fea5ab393085add645d9cb7d17cac191c6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:sdk:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/sdk@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/sdk/metric",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-sdk-metric-f5f8aae88f4689fd",
          "PackageVersion": "v0.41.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "737b00b7dfe94397d22147e5d203ed0a55771e1135f03095cc1c83df747fcec9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:sdk\\/metric:v0.41.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/sdk/metric@v0.41.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/otel/trace",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-otel-trace-320b7520c276229b",
          "PackageVersion": "v1.18.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "358f9ccf06c76e69ddc688d310a892307906d8294d1f63f099c1eb768d09635d"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:otel:trace:v1.18.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/otel/trace@v1.18.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.opentelemetry.io/proto/otlp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.opentelemetry.io-proto-otlp-1bc291aac9f89fda",
          "PackageVersion": "v1.0.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "4f44d7d2d99753c6b709b357cc4286794e6621539d7f4a3290ffaeda521553f2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:proto:otlp:v1.0.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.opentelemetry.io/proto/otlp@v1.0.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.uber.org/multierr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.uber.org-multierr-77907103b338472",
          "PackageVersion": "v1.11.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6e55d72644b14927c1541942efaa71a9e3be2cddda0df2d0a3edf4f7126cb4ed"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.uber.org/multierr@v1.11.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "go.uber.org/zap",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-go.uber.org-zap-9315d69b84acc511",
          "PackageVersion": "v1.26.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b08ee4e8bf795ce292dbcd4d85528e14250d22fbfd7b4c38045f0ddeefad091a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/go.uber.org/zap@v1.26.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/crypto",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-crypto-4b1c1eb33e3ae2c4",
          "PackageVersion": "v0.14.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "c01a865f35895ba9b55eb20a9401f41ecd4927bfbd281c2720ef2feba43d7077"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/crypto:v0.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/crypto@v0.14.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/exp",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-exp-242ee84add261157",
          "PackageVersion": "v0.0.0-20230728194245-b0cb94b80691",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ff244ffb400dee67f90e40f704023a4ce167779d601280c46fca37e63205b60c"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/exp:v0.0.0-20230728194245-b0cb94b80691:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/exp@v0.0.0-20230728194245-b0cb94b80691",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/mod",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-mod-dbf0b352862c8561",
          "PackageVersion": "v0.11.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6d43b4e87aad9d171cffb97bd5705ee1672a4d9fb7007d49e7dcd60c3c0b2a05"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/mod:v0.11.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/mod@v0.11.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/net",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-net-c6cc41776c178497",
          "PackageVersion": "v0.17.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a5569771cbb6a333e30977b07ebd52ef1cdaff37174e2b72f5c09d5d06128c83"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/net:v0.17.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/net@v0.17.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/oauth2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-oauth2-7157bf5989f91098",
          "PackageVersion": "v0.12.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b2654f1b18a793e9f5648e699106bccba7d94f4456d0c8023b96c5a5ea72e01e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/oauth2:v0.12.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/oauth2@v0.12.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sync",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sync-e1897c3cc1594c7b",
          "PackageVersion": "v0.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7ed09880cc7acd3fdab0752b3f0f012cbb1c62d1b39ec2c09e3ab9447f4feba1"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sync:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sync@v0.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sys",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sys-3f052a8cad73e33",
          "PackageVersion": "v0.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "01ff2728f9ae172a625018d5a14f55db41626855ce72e648db5a74c9c5586061"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sys:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sys@v0.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/term",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-term-890b9f0954ca871",
          "PackageVersion": "v0.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6dbf88f5c4df15acc65b9d4c66a055999cbbf89109328b941d351229540b05e9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/term:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/term@v0.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/text",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-text-36b9b9db327234d7",
          "PackageVersion": "v0.13.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "69b950a1251dd2d45d2b165ec0ff3407e05aa9e289b9586e4718ff764aee9f79"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/text:v0.13.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/text@v0.13.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/time",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-time-3346db20e26c1394",
          "PackageVersion": "v0.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ae0e6b2cc8cdccc4b546434bcc21b7f1e6a95a19d82c56170d78f680e96bf23e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/time:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/time@v0.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/xerrors",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-xerrors-48612c072103f709",
          "PackageVersion": "v0.0.0-20220907171357-04be3eba64a2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1f64c3cfc89baa4005e981a109d3778d2f4ed3fb3dd2fd2b261dd7fce2c71149"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/xerrors:v0.0.0-20220907171357-04be3eba64a2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/xerrors@v0.0.0-20220907171357-04be3eba64a2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/api",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-api-26f9ea45c2f0a8bc",
          "PackageVersion": "v0.126.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ab8189abe70074c002ed73fb9e3bd0e2dbe88462e24a5cadb8be014316c867ea"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:api:v0.126.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/api@v0.126.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/appengine",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-appengine-edd30ec4f9af0f4a",
          "PackageVersion": "v1.6.7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "159475ab47b1830c733f3a7f685f9571c1ab49fc5f3e9901aa320812adebbba7"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:appengine:v1.6.7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/appengine@v1.6.7",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-e8de2a0a47b0aa85",
          "PackageVersion": "v0.0.0-20230822172742-b8732ec3820d",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "541bb962a28fbfa5e2275f7d7b177c06bf807adcfea34f05f8f2cc9f02501c06"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20230822172742-b8732ec3820d:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto@v0.0.0-20230822172742-b8732ec3820d",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto/googleapis/api",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-googleapis-api-19a4ea95fc05d0ea",
          "PackageVersion": "v0.0.0-20230913181813-007df8e322eb",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "94ad2895e49cec842c5313b75394e32fd0d696cc691017a687ece907b22a8562"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20230913181813-007df8e322eb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto/googleapis/api@v0.0.0-20230913181813-007df8e322eb",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/genproto/googleapis/rpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-genproto-googleapis-rpc-8a9ef3820938403d",
          "PackageVersion": "v0.0.0-20230913181813-007df8e322eb",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "22c935b121fb6e8bf1f11b62db064ad14645ea8ada0432bbe2ea322c411514dd"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:genproto:v0.0.0-20230913181813-007df8e322eb:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/genproto/googleapis/rpc@v0.0.0-20230913181813-007df8e322eb",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/grpc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-grpc-d62237bc6dd52518",
          "PackageVersion": "v1.58.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0639e95eeb756ed6ed80dffab29f9bac1d8a6e6d8b8cd5e789d62e8c055b4a84"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:grpc:v1.58.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/grpc@v1.58.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-protobuf-7a154043956817c",
          "PackageVersion": "v1.31.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8342c31091e0ac197d37daf5ed1bb7b2a5a1908c76341ebba240473f00bb86cf"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:protobuf:v1.31.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/protobuf@v1.31.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/inf.v0",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-inf.v0-da780a5aa4b0ce72",
          "PackageVersion": "v0.9.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ef73390a86728b764b30ec83950874df50b1e8df4d0c9d95bdf97be840c08037"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/inf.v0@v0.9.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/ini.v1",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-ini.v1-7211b42e439fa027",
          "PackageVersion": "v1.67.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0e09f1fbafa77c4f887f38d410848d7b274f261f405cd36c59b18ff4acc2b0e0"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/ini.v1@v1.67.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/square/go-jose.v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-square-go-jose.v2-4ee8ccc90b5ece70",
          "PackageVersion": "v2.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "34693be164e73ca04d521373417ecf61c4cb523a2aee6cca93638a6efc24da22"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/square/go-jose.v2@v2.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/yaml.v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-yaml.v2-bb68004e5fdbc51d",
          "PackageVersion": "v2.4.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "0fcc60c04098ec262fc7e6369f8b01cfddc99fd251bf1762cb2a3c0937ee29a6"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/yaml.v2@v2.4.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gopkg.in/yaml.v3",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gopkg.in-yaml.v3-2aeba33d4cd7b622",
          "PackageVersion": "v3.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "7f1566fc6cc0cc45aa2c7baf72d23dd4a4bd8613669963a85aed174d8252ec20"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gopkg.in/yaml.v3@v3.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "gorm.io/gorm",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-gorm.io-gorm-bcf60fb1313fd6ba",
          "PackageVersion": "v1.23.10",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "e0d7bd65bcc80fd194c519259713785a324aa6c1f1f186cabde915760c96876e"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/gorm.io/gorm@v1.23.10",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/api",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-api-5af6e0607d21192a",
          "PackageVersion": "v0.27.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "d290a8fc037d84e35acc12a53547614329a69df2d16d26637791f91f77f46d2b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/api@v0.27.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/apimachinery",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-apimachinery-abdaac8265f6b5bf",
          "PackageVersion": "v0.27.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "09dc5f943e0017ad727b0ba27747cb97a6cce1adead388d67a5d0894ff9a623b"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/apimachinery@v0.27.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/client-go",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-client-go-13a793f4ad4b361f",
          "PackageVersion": "v0.27.4",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "be3d984ed489e89e0ac5a0bcf0fe2930f11010258c63c82a3eab138142b3be39"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/client-go@v0.27.4",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/klog/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-klog-v2-ad2a8c7d6679afce",
          "PackageVersion": "v2.100.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "ed608728ae8af1f3614ea7c184848743decaae724d15931c42f2a9ee03ffb668"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klog:v2:v2.100.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/klog/v2@v2.100.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/kube-openapi",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-kube-openapi-3c5401d42a78892a",
          "PackageVersion": "v0.0.0-20230501164219-8b0f38b5fd1f",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "da458f6a43778bf93cd5bd20bc3e42e452769319b55ab4056a759c8722aea868"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/kube-openapi@v0.0.0-20230501164219-8b0f38b5fd1f",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/utils",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-utils-5ce3da73efdb2472",
          "PackageVersion": "v0.0.0-20230726121419-3b25d923346b",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "b209f7654efcdd20a0b5a4898e971556546a77a1929e54cb2a0a4002db49be92"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/utils@v0.0.0-20230726121419-3b25d923346b",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "modernc.org/libc",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-modernc.org-libc-de6b93c514800240",
          "PackageVersion": "v1.16.8",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "531f7c3da38cbe8960a055ff630bac14e1c19da9d77464665a023c722236cf8a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/modernc.org/libc@v1.16.8",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "modernc.org/mathutil",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-modernc.org-mathutil-d7fa20f8dece165c",
          "PackageVersion": "v1.4.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "8a3ddf6067bccc117856efa0d284fb981d3aafcb2a1962ae26ed725de4786f2f"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/modernc.org/mathutil@v1.4.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "modernc.org/memory",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-modernc.org-memory-ac2068fe17629604",
          "PackageVersion": "v1.1.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6c338bd032032d0bfb6d684fde032f22b9e8170f84a3a17b6b640af473c38855"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/modernc.org/memory@v1.1.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "modernc.org/sqlite",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-modernc.org-sqlite-d32f129bca154bfc",
          "PackageVersion": "v1.17.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "884f9ca02e60d7b2ed0720d80d62a947a9b667dd36d98ad28776ee9b03a722b2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/modernc.org/sqlite@v1.17.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "netbase",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-netbase-fdbf312837579aa",
          "PackageVersion": "6.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Marco d'Itri \u003cmd@linux.it\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/netbase/copyright, /var/lib/dpkg/status.d/netbase",
          "PackageLicenseConcluded": "GPL-2.0-only",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "GPL-2.0-only",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:netbase:netbase:6.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/netbase@6.3?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "schneider.vip/problem",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-schneider.vip-problem-239bce8310e97107",
          "PackageVersion": "v1.8.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "a0080b32edbce9a34782f8eea11d4fa30631fbb8720548f2cdbac53d1d5d10c2"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/schneider.vip/problem@v1.8.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/controller-runtime",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-controller-runtime-f5e3b0611c0b0154",
          "PackageVersion": "v0.15.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "30bfb901db77a999cc498c59ee002f7ab04b34f48c40489bb73020a7450fa235"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/controller-runtime@v0.15.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/json",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-json-a2e5ddc7a1b78ddf",
          "PackageVersion": "v0.0.0-20221116044647-bc3834ca7abd",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "1033c15c202ca72195e23425a594ae74f78c9abd5b34979f9eea8bb1102c1d9a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/json@v0.0.0-20221116044647-bc3834ca7abd",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/structured-merge-diff/v4",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-structured-merge-diff-v4-d3c275154454867c",
          "PackageVersion": "v4.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "5196d90197d7d30576cebed8668ac3cfa19744e7c3163e8bbea0919b855454a9"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured-merge-diff:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured_merge_diff:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured-merge:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured_merge:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:structured:v4:v4.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/structured-merge-diff/v4@v4.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "sigs.k8s.io/yaml",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-sigs.k8s.io-yaml-3b75cd53662ef42b",
          "PackageVersion": "v1.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": [
            {
              "Algorithm": "SHA256",
              "Value": "6b655c94bcce1abc0e1c3895f047c11a1be31ef3f8e82b56e63e8f3af858186a"
            }
          ],
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /usr/bin/kubevuln",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/sigs.k8s.io/yaml@v1.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "tzdata",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-tzdata-a257ef3c84e6537f",
          "PackageVersion": "2021a-1+deb11u10",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: GNU Libc Maintainers \u003cdebian-glibc@lists.debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/tzdata/copyright, /var/lib/dpkg/status.d/tzdata",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tzdata:tzdata:2021a-1\\+deb11u10:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/tzdata@2021a-1+deb11u10?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        }
      ],
      "Files": null,
      "OtherLicenses": [
        {
          "LicenseIdentifier": "LicenseRef-GPL",
          "ExtractedText": "NONE",
          "LicenseName": "GPL",
          "LicenseCrossReferences": null,
          "LicenseComment": ""
        }
      ],
      "Relationships": [
        {
          "RefA": "SPDXRef-DOCUMENT",
          "RefB": "SPDXRef-DOCUMENT",
          "Relationship": "DESCRIBES",
          "RelationshipComment": ""
        }
      ],
      "Annotations": null,
      "Snippets": null,
      "Reviews": null
    }
  },
  "Status": {}
}