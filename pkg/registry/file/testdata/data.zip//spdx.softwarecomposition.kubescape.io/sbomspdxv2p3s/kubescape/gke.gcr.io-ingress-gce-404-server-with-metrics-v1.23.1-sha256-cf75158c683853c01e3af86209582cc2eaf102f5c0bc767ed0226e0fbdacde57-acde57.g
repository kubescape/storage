{
  "name": "gke.gcr.io-ingress-gce-404-server-with-metrics-v1.23.1-sha256-cf75158c683853c01e3af86209582cc2eaf102f5c0bc767ed0226e0fbdacde57-acde57",
  "namespace": "kubescape",
  "uid": "cf625c90-e09c-417a-9ebd-48837e1f196b",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:47Z",
  "labels": {
    "kubescape.io/image-id": "gke-gcr-io-ingress-gce-404-server-with-metrics-sha256-cf75158c6",
    "kubescape.io/image-name": "gke-gcr-io-ingress-gce-404-server-with-metrics"
  },
  "annotations": {
    "kubescape.io/image-id": "gke.gcr.io/ingress-gce-404-server-with-metrics@sha256:cf75158c683853c01e3af86209582cc2eaf102f5c0bc767ed0226e0fbdacde57",
    "kubescape.io/status": ""
  },
  "Spec": {
    "Metadata": {
      "Tool": {
        "Name": "",
        "Version": "v0.76.0"
      },
      "Report": {
        "CreatedAt": null
      }
    },
    "SPDX": {
      "DocumentDescribes": null,
      "SPDXVersion": "SPDX-2.3",
      "DataLicense": "CC0-1.0",
      "SPDXIdentifier": "SPDXRef-DOCUMENT",
      "DocumentName": "gke.gcr.io/ingress-gce-404-server-with-metrics@sha256:cf75158c683853c01e3af86209582cc2eaf102f5c0bc767ed0226e0fbdacde57",
      "DocumentNamespace": "https://anchore.com/syft/image/gke.gcr.io/ingress-gce-404-server-with-metrics@sha256-cf75158c683853c01e3af86209582cc2eaf102f5c0bc767ed0226e0fbdacde57-bb76b392-81eb-4f57-8c5a-71ce598f29eb",
      "ExternalDocumentReferences": null,
      "DocumentComment": "",
      "CreationInfo": {
        "LicenseListVersion": "3.20",
        "Creators": [
          "Organization: Anchore, Inc",
          "Tool: syft-v0.76.0"
        ],
        "Created": "2023-11-29T12:45:47Z",
        "CreatorComment": ""
      },
      "Packages": [
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "base-files",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-base-files-4046c56c645e8a80",
          "PackageVersion": "11.1+deb11u7",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Santiago Vila \u003csanvila@debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/base-files/copyright, /var/lib/dpkg/status.d/base-files",
          "PackageLicenseConcluded": "LicenseRef-GPL",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "LicenseRef-GPL",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base-files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base-files:base_files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base-files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base_files:base_files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base-files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:base:base_files:11.1\\+deb11u7:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/base-files@11.1+deb11u7?arch=amd64\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/beorn7/perks",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-beorn7-perks-51eca8bd14d0256d",
          "PackageVersion": "v1.0.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:beorn7:perks:v1.0.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/beorn7/perks@v1.0.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/cespare/xxhash/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-cespare-xxhash-v2-52f52b3c9a819aae",
          "PackageVersion": "v2.2.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:cespare:xxhash\\/v2:v2.2.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/cespare/xxhash/v2@v2.2.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/go-logr/logr",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-go-logr-logr-6fae363ad495b1ec",
          "PackageVersion": "v1.2.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go-logr:logr:v1.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go_logr:logr:v1.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:go:logr:v1.2.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/go-logr/logr@v1.2.3",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/golang/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-golang-protobuf-3c4b3ec939163e95",
          "PackageVersion": "v1.5.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:protobuf:v1.5.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/golang/protobuf@v1.5.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/matttproud/golang_protobuf_extensions",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-matttproud-golang-protobuf-extensions-76f24a405159807a",
          "PackageVersion": "v1.0.2",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang-protobuf-extensions:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:matttproud:golang_protobuf_extensions:v1.0.2:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/matttproud/golang_protobuf_extensions@v1.0.2",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_golang",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-golang-971db3b9211bead5",
          "PackageVersion": "v1.14.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-golang:v1.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_golang:v1.14.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_golang@v1.14.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/client_model",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-client-model-4c64943886a9bce1",
          "PackageVersion": "v0.3.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client-model:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:client_model:v0.3.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/client_model@v0.3.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/common",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-common-20561f6f2e5390e5",
          "PackageVersion": "v0.37.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:common:v0.37.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/common@v0.37.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "github.com/prometheus/procfs",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-github.com-prometheus-procfs-7a470ecd7bdc8358",
          "PackageVersion": "v0.8.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:prometheus:procfs:v0.8.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/github.com/prometheus/procfs@v0.8.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "golang.org/x/sys",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-golang.org-x-sys-ba392156f15cc198",
          "PackageVersion": "v0.6.0",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:golang:x\\/sys:v0.6.0:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/golang.org/x/sys@v0.6.0",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "google.golang.org/protobuf",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-google.golang.org-protobuf-50b55cd471c51d6b",
          "PackageVersion": "v1.29.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:google:protobuf:v1.29.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/google.golang.org/protobuf@v1.29.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/ingress-gce",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-ingress-gce-ebc88cd5345909a1",
          "PackageVersion": "v0.0.0-20230417161045-608085755ade",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/ingress-gce@v0.0.0-20230417161045-608085755ade",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "k8s.io/klog/v2",
          "PackageSPDXIdentifier": "SPDXRef-Package-go-module-k8s.io-klog-v2-ba6b89c37bf992f2",
          "PackageVersion": "v2.80.1",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": null,
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from go module information: /404-server-with-metrics",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:klog:v2:v2.80.1:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:golang/k8s.io/klog/v2@v2.80.1",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "netbase",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-netbase-fdbf312837579aa",
          "PackageVersion": "6.3",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: Marco d'Itri \u003cmd@linux.it\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/netbase/copyright, /var/lib/dpkg/status.d/netbase",
          "PackageLicenseConcluded": "GPL-2.0-only",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "GPL-2.0-only",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:netbase:netbase:6.3:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/netbase@6.3?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        },
        {
          "HasFiles": null,
          "IsUnpackaged": false,
          "PackageName": "tzdata",
          "PackageSPDXIdentifier": "SPDXRef-Package-deb-tzdata-a257ef3c84e6537f",
          "PackageVersion": "2021a-1+deb11u10",
          "PackageFileName": "",
          "PackageSupplier": null,
          "PackageOriginator": "Person: GNU Libc Maintainers \u003cdebian-glibc@lists.debian.org\u003e",
          "PackageDownloadLocation": "NOASSERTION",
          "FilesAnalyzed": false,
          "IsFilesAnalyzedTagPresent": false,
          "PackageVerificationCode": null,
          "PackageChecksums": null,
          "PackageHomePage": "",
          "PackageSourceInfo": "acquired package info from DPKG DB: /usr/share/doc/tzdata/copyright, /var/lib/dpkg/status.d/tzdata",
          "PackageLicenseConcluded": "NONE",
          "PackageLicenseInfoFromFiles": null,
          "PackageLicenseDeclared": "NONE",
          "PackageLicenseComments": "",
          "PackageCopyrightText": "NOASSERTION",
          "PackageSummary": "",
          "PackageDescription": "",
          "PackageComment": "",
          "PackageExternalReferences": [
            {
              "Category": "SECURITY",
              "RefType": "cpe23Type",
              "Locator": "cpe:2.3:a:tzdata:tzdata:2021a-1\\+deb11u10:*:*:*:*:*:*:*",
              "ExternalRefComment": ""
            },
            {
              "Category": "PACKAGE-MANAGER",
              "RefType": "purl",
              "Locator": "pkg:deb/debian/tzdata@2021a-1+deb11u10?arch=all\u0026distro=debian-11",
              "ExternalRefComment": ""
            }
          ],
          "PackageAttributionTexts": null,
          "PrimaryPackagePurpose": "",
          "ReleaseDate": "",
          "BuiltDate": "",
          "ValidUntilDate": "",
          "Files": null,
          "Annotations": null
        }
      ],
      "Files": null,
      "OtherLicenses": [
        {
          "LicenseIdentifier": "LicenseRef-GPL",
          "ExtractedText": "NONE",
          "LicenseName": "GPL",
          "LicenseCrossReferences": null,
          "LicenseComment": ""
        }
      ],
      "Relationships": [
        {
          "RefA": "SPDXRef-DOCUMENT",
          "RefB": "SPDXRef-DOCUMENT",
          "Relationship": "DESCRIBES",
          "RelationshipComment": ""
        }
      ],
      "Annotations": null,
      "Snippets": null,
      "Reviews": null
    }
  },
  "Status": {}
}