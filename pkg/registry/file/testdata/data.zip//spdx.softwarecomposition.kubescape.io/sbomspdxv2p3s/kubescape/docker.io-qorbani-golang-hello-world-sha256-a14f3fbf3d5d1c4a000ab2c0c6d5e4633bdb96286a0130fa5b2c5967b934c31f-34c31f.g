{
  "name": "docker.io-qorbani-golang-hello-world-sha256-a14f3fbf3d5d1c4a000ab2c0c6d5e4633bdb96286a0130fa5b2c5967b934c31f-34c31f",
  "namespace": "kubescape",
  "uid": "87f80e37-632e-4d28-86b7-d4521e4676c2",
  "resourceVersion": "1",
  "creationTimestamp": "2023-11-29T12:45:50Z",
  "labels": {
    "kubescape.io/image-id": "docker-io-qorbani-golang-hello-world-sha256-a14f3fbf3d5d1c4a000",
    "kubescape.io/image-name": "docker-io-qorbani-golang-hello-world"
  },
  "annotations": {
    "kubescape.io/image-id": "docker.io/qorbani/golang-hello-world@sha256:a14f3fbf3d5d1c4a000ab2c0c6d5e4633bdb96286a0130fa5b2c5967b934c31f",
    "kubescape.io/status": ""
  },
  "Spec": {
    "Metadata": {
      "Tool": {
        "Name": "",
        "Version": "v0.76.0"
      },
      "Report": {
        "CreatedAt": null
      }
    },
    "SPDX": {
      "DocumentDescribes": null,
      "SPDXVersion": "SPDX-2.3",
      "DataLicense": "CC0-1.0",
      "SPDXIdentifier": "SPDXRef-DOCUMENT",
      "DocumentName": "docker.io/qorbani/golang-hello-world@sha256:a14f3fbf3d5d1c4a000ab2c0c6d5e4633bdb96286a0130fa5b2c5967b934c31f",
      "DocumentNamespace": "https://anchore.com/syft/image/docker.io/qorbani/golang-hello-world@sha256-a14f3fbf3d5d1c4a000ab2c0c6d5e4633bdb96286a0130fa5b2c5967b934c31f-afe82312-7110-4095-b804-cb0846424170",
      "ExternalDocumentReferences": null,
      "DocumentComment": "",
      "CreationInfo": {
        "LicenseListVersion": "3.20",
        "Creators": [
          "Organization: Anchore, Inc",
          "Tool: syft-v0.76.0"
        ],
        "Created": "2023-11-29T12:45:50Z",
        "CreatorComment": ""
      },
      "Packages": null,
      "Files": null,
      "OtherLicenses": null,
      "Relationships": [
        {
          "RefA": "SPDXRef-DOCUMENT",
          "RefB": "SPDXRef-DOCUMENT",
          "Relationship": "DESCRIBES",
          "RelationshipComment": ""
        }
      ],
      "Annotations": null,
      "Snippets": null,
      "Reviews": null
    }
  },
  "Status": {}
}