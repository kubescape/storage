{
  "name": "daemonset-gadget",
  "namespace": "gadget",
  "uid": "d71f2242-1f2e-41d4-b71a-7a00501f8b47",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:31Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "daemonset",
    "kubescape.io/workload-name": "gadget",
    "kubescape.io/workload-namespace": "gadget",
    "kubescape.io/workload-resource-version": "666967"
  },
  "annotations": {
    "kubescape.io/status": "complete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-gadget/daemonset-gadget"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:03:31Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:egress": {
            "k:{\"identifier\":\"3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-6443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:ingress": {},
          "f:matchLabels": {
            ".": {},
            "f:k8s-app": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "k8s-app": "gadget"
    },
    "Ingress": [],
    "Egress": [
      {
        "Identifier": "3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-6443",
            "Protocol": "TCP",
            "Port": 6443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "172.18.0.2"
      }
    ]
  }
}