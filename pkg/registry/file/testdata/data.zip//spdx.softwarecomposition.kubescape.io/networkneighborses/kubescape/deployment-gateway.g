{
  "name": "deployment-gateway",
  "namespace": "kubescape",
  "uid": "f71b28b9-96d0-4280-a300-755cf1f4f471",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:36Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "deployment",
    "kubescape.io/workload-name": "gateway",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "667000"
  },
  "annotations": {
    "kubescape.io/status": "complete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-gateway"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:03:36Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:egress": {
            "k:{\"identifier\":\"e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"UDP-53\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:ingress": {
            "k:{\"identifier\":\"24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8001\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8000\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"8ef9ea1e3a7ca7c7d0e1e11accb5299c2daaa7b93c8ba85ba29f04a330d47795\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8001\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:matchLabels": {
            ".": {},
            "f:app.kubernetes.io/instance": {},
            "f:app.kubernetes.io/name": {},
            "f:tier": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "app.kubernetes.io/instance": "kubescape",
      "app.kubernetes.io/name": "gateway",
      "tier": "ks-control-plane"
    },
    "Ingress": [
      {
        "Identifier": "24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8001",
            "Protocol": "TCP",
            "Port": 8001
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "operator",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "operator",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "otel": "enabled",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "8ef9ea1e3a7ca7c7d0e1e11accb5299c2daaa7b93c8ba85ba29f04a330d47795",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8001",
            "Protocol": "TCP",
            "Port": 8001
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "10.244.0.132"
      },
      {
        "Identifier": "336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8000",
            "Protocol": "TCP",
            "Port": 8000
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "10.244.0.1"
      }
    ],
    "Egress": [
      {
        "Identifier": "e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "UDP-53",
            "Protocol": "UDP",
            "Port": 53
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "k8s-app": "kube-dns"
          }
        },
        "NamespaceSelector": {
          "matchLabels": {
            "kubernetes.io/metadata.name": "kube-system"
          }
        },
        "IPAddress": ""
      },
      {
        "Identifier": "eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5",
        "Type": "external",
        "DNS": "api-dev.armosec.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "54.77.214.53"
      }
    ]
  }
}