{
  "name": "deployment-kubevuln",
  "namespace": "kubescape",
  "uid": "75e5d0e6-909f-4dfe-8817-6c5d37cca318",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:44Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "deployment",
    "kubescape.io/workload-name": "kubevuln",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "667086"
  },
  "annotations": {
    "kubescape.io/status": "complete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-kubevuln"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:13:44Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:egress": {
            "k:{\"identifier\":\"06f43bc305bc05025637b2cc0c5474e455dbdc50c8afc14c4efc35c25e0a9df4\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"10f7e4d334d2510d4689854c3c61e815490a39a4dac928698d7f90098eed4e3b\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"1bdc6f464528d43bd8c58f00c1d8227d01dc9e2e925433ff6dfef9f65f4a7b83\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"1cd13cbae6d63acca4863319494291ca8d53a45129857627f29885b05efa7331\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"1cee2b1861879732e111377edcf538b9d9bac5cca053fa5388ccbd8cbaf15c1b\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"2a0ed2ea62a29faf0e7069f4097c797cf45e855cabb0d4e1fd754a75e7268c98\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-6443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"4e32e51ad294f4a8795e408f8fcc801165e7769d40f45a1c6f5bb0a64e5f1317\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"4fee761fdac9a37cc71ad7d3e81711437ca8f7c673308bab561cc7d4c0631e98\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"60f0170de210ed5d0ff301eb442a0869081a6d8bcc8bbad033291afc963a84ba\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"95296b92adee3a4ce1343c6bc9228f23a94dc6e195d8ab6e9c0085468c2cdc07\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"ad98a9e00a1e4a5efbbd827f432595a31085d0e8dcec365dbdfd8141bf3cbe3e\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"b7160419fe0a734f69ba4d59902288efd51e80b954c9d49c97e36b6ab1c2dde6\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"e0840d6ec12193d2b285b9486b7101f2830cee2810d4de5ddd914b0e0f021b97\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"UDP-53\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"fbe6526d5c15b5bb7ce4eb3884f1f9dcbbae415b171fc2db6ed15edfa161a0ef\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"fcff5c8dcd6c32f04eac621b3cfb90ba09e89f04094b55928a4b7545aec9b3b7\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:ingress": {
            "k:{\"identifier\":\"24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8080\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8080\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:matchLabels": {
            ".": {},
            "f:app.kubernetes.io/instance": {},
            "f:app.kubernetes.io/name": {},
            "f:tier": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "app.kubernetes.io/instance": "kubescape",
      "app.kubernetes.io/name": "kubevuln",
      "tier": "ks-control-plane"
    },
    "Ingress": [
      {
        "Identifier": "336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8080",
            "Protocol": "TCP",
            "Port": 8080
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "10.244.0.1"
      },
      {
        "Identifier": "24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8080",
            "Protocol": "TCP",
            "Port": 8080
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "operator",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "operator",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "otel": "enabled",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      }
    ],
    "Egress": [
      {
        "Identifier": "2a0ed2ea62a29faf0e7069f4097c797cf45e855cabb0d4e1fd754a75e7268c98",
        "Type": "external",
        "DNS": "ghcr.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "140.82.121.33"
      },
      {
        "Identifier": "ad98a9e00a1e4a5efbbd827f432595a31085d0e8dcec365dbdfd8141bf3cbe3e",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "otel-collector"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "1bdc6f464528d43bd8c58f00c1d8227d01dc9e2e925433ff6dfef9f65f4a7b83",
        "Type": "external",
        "DNS": "auth.docker.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "54.198.86.24"
      },
      {
        "Identifier": "1cee2b1861879732e111377edcf538b9d9bac5cca053fa5388ccbd8cbaf15c1b",
        "Type": "external",
        "DNS": "production.cloudflare.docker.com.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "104.16.101.207"
      },
      {
        "Identifier": "4fee761fdac9a37cc71ad7d3e81711437ca8f7c673308bab561cc7d4c0631e98",
        "Type": "external",
        "DNS": "cdn03.quay.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "104.18.37.147"
      },
      {
        "Identifier": "eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5",
        "Type": "external",
        "DNS": "api-dev.armosec.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "54.77.214.53"
      },
      {
        "Identifier": "fbe6526d5c15b5bb7ce4eb3884f1f9dcbbae415b171fc2db6ed15edfa161a0ef",
        "Type": "external",
        "DNS": "toolbox-data.anchore.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "104.26.1.250"
      },
      {
        "Identifier": "95296b92adee3a4ce1343c6bc9228f23a94dc6e195d8ab6e9c0085468c2cdc07",
        "Type": "external",
        "DNS": "toolbox-data.anchore.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "104.26.0.250"
      },
      {
        "Identifier": "3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-6443",
            "Protocol": "TCP",
            "Port": 6443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "172.18.0.2"
      },
      {
        "Identifier": "10f7e4d334d2510d4689854c3c61e815490a39a4dac928698d7f90098eed4e3b",
        "Type": "external",
        "DNS": "europe-west9-docker.pkg.dev.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "108.177.15.82"
      },
      {
        "Identifier": "1cd13cbae6d63acca4863319494291ca8d53a45129857627f29885b05efa7331",
        "Type": "external",
        "DNS": "auth.docker.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "54.236.113.205"
      },
      {
        "Identifier": "60f0170de210ed5d0ff301eb442a0869081a6d8bcc8bbad033291afc963a84ba",
        "Type": "external",
        "DNS": "api-dev.armosec.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "52.208.150.132"
      },
      {
        "Identifier": "b7160419fe0a734f69ba4d59902288efd51e80b954c9d49c97e36b6ab1c2dde6",
        "Type": "external",
        "DNS": "registry.k8s.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "34.96.108.209"
      },
      {
        "Identifier": "fcff5c8dcd6c32f04eac621b3cfb90ba09e89f04094b55928a4b7545aec9b3b7",
        "Type": "external",
        "DNS": "quay.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "52.206.59.27"
      },
      {
        "Identifier": "e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "UDP-53",
            "Protocol": "UDP",
            "Port": 53
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "k8s-app": "kube-dns"
          }
        },
        "NamespaceSelector": {
          "matchLabels": {
            "kubernetes.io/metadata.name": "kube-system"
          }
        },
        "IPAddress": ""
      },
      {
        "Identifier": "e0840d6ec12193d2b285b9486b7101f2830cee2810d4de5ddd914b0e0f021b97",
        "Type": "external",
        "DNS": "auth.docker.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "54.227.20.253"
      },
      {
        "Identifier": "4e32e51ad294f4a8795e408f8fcc801165e7769d40f45a1c6f5bb0a64e5f1317",
        "Type": "external",
        "DNS": "pkg-containers.githubusercontent.com.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "185.199.109.154"
      },
      {
        "Identifier": "06f43bc305bc05025637b2cc0c5474e455dbdc50c8afc14c4efc35c25e0a9df4",
        "Type": "external",
        "DNS": "toolbox-data.anchore.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "172.67.71.75"
      }
    ]
  }
}