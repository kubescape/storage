{
  "name": "deployment-nginx",
  "namespace": "default",
  "uid": "91a52861-56fe-4ee5-8ede-52ad5504a653",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:23Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "deployment",
    "kubescape.io/workload-name": "nginx",
    "kubescape.io/workload-namespace": "default",
    "kubescape.io/workload-resource-version": "666918"
  },
  "annotations": {
    "kubescape.io/status": "incomplete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-default/deployment-nginx"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:01:23Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:matchLabels": {
            ".": {},
            "f:app": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "app": "nginx"
    },
    "Ingress": null,
    "Egress": null
  }
}