{
  "name": "deployment-redis",
  "namespace": "default",
  "uid": "a965bdcd-a0b4-4e9f-84eb-4a9630ae60bb",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:27Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "deployment",
    "kubescape.io/workload-name": "redis",
    "kubescape.io/workload-namespace": "default",
    "kubescape.io/workload-resource-version": "666946"
  },
  "annotations": {
    "kubescape.io/status": "incomplete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-default/deployment-redis"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:01:27Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:matchLabels": {
            ".": {},
            "f:app": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "app": "redis"
    },
    "Ingress": null,
    "Egress": null
  }
}