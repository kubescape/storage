{
  "name": "statefulset-kollector",
  "namespace": "kubescape",
  "uid": "83a6999b-63b3-40a8-bb14-08b7b2966aba",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:41Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "statefulset",
    "kubescape.io/workload-name": "kollector",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "667050"
  },
  "annotations": {
    "kubescape.io/status": "complete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/statefulset-kollector"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:03:41Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:egress": {
            "k:{\"identifier\":\"3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-6443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"5bca24c2b9628bbc0dff00fd5645b9483e04c9e505cbd482aa966f8796a3bc28\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-80\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"ad98a9e00a1e4a5efbbd827f432595a31085d0e8dcec365dbdfd8141bf3cbe3e\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"UDP-53\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:ingress": {
            "k:{\"identifier\":\"336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8000\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:matchLabels": {
            ".": {},
            "f:app.kubernetes.io/instance": {},
            "f:app.kubernetes.io/name": {},
            "f:tier": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "app.kubernetes.io/instance": "kubescape",
      "app.kubernetes.io/name": "kollector",
      "tier": "ks-control-plane"
    },
    "Ingress": [
      {
        "Identifier": "336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8000",
            "Protocol": "TCP",
            "Port": 8000
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "10.244.0.1"
      }
    ],
    "Egress": [
      {
        "Identifier": "5bca24c2b9628bbc0dff00fd5645b9483e04c9e505cbd482aa966f8796a3bc28",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-80",
            "Protocol": "TCP",
            "Port": 80
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "169.254.169.254"
      },
      {
        "Identifier": "eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5",
        "Type": "external",
        "DNS": "api-dev.armosec.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "54.77.214.53"
      },
      {
        "Identifier": "e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "UDP-53",
            "Protocol": "UDP",
            "Port": 53
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "k8s-app": "kube-dns"
          }
        },
        "NamespaceSelector": {
          "matchLabels": {
            "kubernetes.io/metadata.name": "kube-system"
          }
        },
        "IPAddress": ""
      },
      {
        "Identifier": "ad98a9e00a1e4a5efbbd827f432595a31085d0e8dcec365dbdfd8141bf3cbe3e",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "otel-collector"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-6443",
            "Protocol": "TCP",
            "Port": 6443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "172.18.0.2"
      }
    ]
  }
}