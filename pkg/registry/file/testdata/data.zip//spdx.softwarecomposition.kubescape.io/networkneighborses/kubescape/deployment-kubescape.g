{
  "name": "deployment-kubescape",
  "namespace": "kubescape",
  "uid": "210deec6-aa37-4129-9651-c620edc878ec",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:40Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "deployment",
    "kubescape.io/workload-name": "kubescape",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "667033"
  },
  "annotations": {
    "kubescape.io/status": "complete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-kubescape"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:03:40Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:egress": {
            "k:{\"identifier\":\"3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-6443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"60f0170de210ed5d0ff301eb442a0869081a6d8bcc8bbad033291afc963a84ba\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"ad98a9e00a1e4a5efbbd827f432595a31085d0e8dcec365dbdfd8141bf3cbe3e\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"c72de74b78ca866b7b455d4717580b25ec15be2c5c00999590bce727f5f73a40\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"UDP-53\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:ingress": {
            "k:{\"identifier\":\"24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8080\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-8080\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:matchLabels": {
            ".": {},
            "f:app.kubernetes.io/instance": {},
            "f:app.kubernetes.io/name": {},
            "f:tier": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "app.kubernetes.io/instance": "kubescape",
      "app.kubernetes.io/name": "kubescape",
      "tier": "ks-control-plane"
    },
    "Ingress": [
      {
        "Identifier": "24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8080",
            "Protocol": "TCP",
            "Port": 8080
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "operator",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "operator",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "otel": "enabled",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "336a2ae983dc6ed68fc44228eaaf0c50d2d104f4c5d66b49bfe7905e170eb0ab",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-8080",
            "Protocol": "TCP",
            "Port": 8080
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "10.244.0.1"
      }
    ],
    "Egress": [
      {
        "Identifier": "c72de74b78ca866b7b455d4717580b25ec15be2c5c00999590bce727f5f73a40",
        "Type": "external",
        "DNS": "us-central1-elated-pottery-310110.cloudfunctions.net.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "216.239.36.54"
      },
      {
        "Identifier": "60f0170de210ed5d0ff301eb442a0869081a6d8bcc8bbad033291afc963a84ba",
        "Type": "external",
        "DNS": "api-dev.armosec.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "52.208.150.132"
      },
      {
        "Identifier": "e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "UDP-53",
            "Protocol": "UDP",
            "Port": 53
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "k8s-app": "kube-dns"
          }
        },
        "NamespaceSelector": {
          "matchLabels": {
            "kubernetes.io/metadata.name": "kube-system"
          }
        },
        "IPAddress": ""
      },
      {
        "Identifier": "ad98a9e00a1e4a5efbbd827f432595a31085d0e8dcec365dbdfd8141bf3cbe3e",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "otel-collector"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "3d5b16a1404c0107763a05f192a72da9d454075e6491c3d6b35f702cccce0317",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-6443",
            "Protocol": "TCP",
            "Port": 6443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "172.18.0.2"
      }
    ]
  }
}