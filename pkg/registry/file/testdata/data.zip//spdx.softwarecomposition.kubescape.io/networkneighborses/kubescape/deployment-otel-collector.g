{
  "name": "deployment-otel-collector",
  "namespace": "kubescape",
  "uid": "a309dfc6-ca9a-4434-9085-deb83d4782e0",
  "resourceVersion": "1",
  "creationTimestamp": "2023-12-06T09:01:48Z",
  "labels": {
    "kubescape.io/workload-api-group": "apps",
    "kubescape.io/workload-api-version": "v1",
    "kubescape.io/workload-kind": "deployment",
    "kubescape.io/workload-name": "otel-collector",
    "kubescape.io/workload-namespace": "kubescape",
    "kubescape.io/workload-resource-version": "667116"
  },
  "annotations": {
    "kubescape.io/status": "complete",
    "kubescape.io/wlid": "wlid://cluster-kind-kind/namespace-kubescape/deployment-otel-collector"
  },
  "managedFields": [
    {
      "manager": "node-agent",
      "operation": "Update",
      "apiVersion": "spdx.softwarecomposition.kubescape.io/v1beta1",
      "time": "2023-12-06T09:03:49Z",
      "fieldsType": "FieldsV1",
      "fieldsV1": {
        "f:metadata": {
          "f:annotations": {
            ".": {},
            "f:kubescape.io/status": {},
            "f:kubescape.io/wlid": {}
          },
          "f:labels": {
            ".": {},
            "f:kubescape.io/workload-api-group": {},
            "f:kubescape.io/workload-api-version": {},
            "f:kubescape.io/workload-kind": {},
            "f:kubescape.io/workload-name": {},
            "f:kubescape.io/workload-namespace": {},
            "f:kubescape.io/workload-resource-version": {}
          }
        },
        "f:spec": {
          "f:egress": {
            "k:{\"identifier\":\"e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"UDP-53\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-443\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:ingress": {
            "k:{\"identifier\":\"07da9543cfb31d941337c3fa92519fa72c78098c5dd75e20187edc76edd6bbc8\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"69c237d98c463f09d4b948ba22deeac09e5db3172aac950fdab383da04729a3e\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"8ef9ea1e3a7ca7c7d0e1e11accb5299c2daaa7b93c8ba85ba29f04a330d47795\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"972a528dc429ef7a119dd073a579074c77207446725393376923d9abea2370a9\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"9dbea2383782912be222fbd106431620221ce82b8addfe663594a3e4ff9ef9ee\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"c5fb4ce75ba64e8ad2f073fb941dba084afaec93b9dbef7fb5e7d27b2e0e5814\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            },
            "k:{\"identifier\":\"ef45e06890a04624d566c39c202453eaf47d1d148ec4c8094525bb5282407914\"}": {
              ".": {},
              "f:dns": {},
              "f:identifier": {},
              "f:ipAddress": {},
              "f:namespaceSelector": {},
              "f:podSelector": {},
              "f:ports": {
                ".": {},
                "k:{\"name\":\"TCP-4317\"}": {
                  ".": {},
                  "f:name": {},
                  "f:port": {},
                  "f:protocol": {}
                }
              },
              "f:type": {}
            }
          },
          "f:matchLabels": {
            ".": {},
            "f:app.kubernetes.io/instance": {},
            "f:app.kubernetes.io/name": {},
            "f:tier": {}
          }
        }
      }
    }
  ],
  "Spec": {
    "matchLabels": {
      "app.kubernetes.io/instance": "kubescape",
      "app.kubernetes.io/name": "otel-collector",
      "tier": "ks-control-plane"
    },
    "Ingress": [
      {
        "Identifier": "07da9543cfb31d941337c3fa92519fa72c78098c5dd75e20187edc76edd6bbc8",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app.kubernetes.io/component": "apiserver",
            "app.kubernetes.io/name": "storage",
            "app.kubernetes.io/part-of": "kubescape-storage",
            "otel": "enabled"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "69c237d98c463f09d4b948ba22deeac09e5db3172aac950fdab383da04729a3e",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "10.244.0.131"
      },
      {
        "Identifier": "ef45e06890a04624d566c39c202453eaf47d1d148ec4c8094525bb5282407914",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "alt-name": "node-agent",
            "app": "node-agent",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "node-agent",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "otel": "enabled",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "24eda6f8e12486a4c5b17bccdbaf417ccadb002017159df07578e477e26c6277",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "operator",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "operator",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "otel": "enabled",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "9dbea2383782912be222fbd106431620221ce82b8addfe663594a3e4ff9ef9ee",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "kubescape",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "kubescape",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "otel": "enabled",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "c5fb4ce75ba64e8ad2f073fb941dba084afaec93b9dbef7fb5e7d27b2e0e5814",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "kollector",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "kollector",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "statefulset.kubernetes.io/pod-name": "kollector-0",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      },
      {
        "Identifier": "8ef9ea1e3a7ca7c7d0e1e11accb5299c2daaa7b93c8ba85ba29f04a330d47795",
        "Type": "external",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "10.244.0.132"
      },
      {
        "Identifier": "972a528dc429ef7a119dd073a579074c77207446725393376923d9abea2370a9",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "TCP-4317",
            "Protocol": "TCP",
            "Port": 4317
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "app": "kubevuln",
            "app.kubernetes.io/instance": "kubescape",
            "app.kubernetes.io/name": "kubevuln",
            "helm.sh/chart": "kubescape-operator-1.16.4",
            "otel": "enabled",
            "tier": "ks-control-plane"
          }
        },
        "NamespaceSelector": null,
        "IPAddress": ""
      }
    ],
    "Egress": [
      {
        "Identifier": "eb8dcb14b8de47db3e25d1825193f9c87fbdb117bd8ac782e771fdb018cb6ed5",
        "Type": "external",
        "DNS": "api-dev.armosec.io.",
        "Ports": [
          {
            "Name": "TCP-443",
            "Protocol": "TCP",
            "Port": 443
          }
        ],
        "PodSelector": null,
        "NamespaceSelector": null,
        "IPAddress": "54.77.214.53"
      },
      {
        "Identifier": "e5e8ca3d76f701a19b7478fdc1c8c24ccc6cef9902b52c8c7e015439e2a1ddf3",
        "Type": "internal",
        "DNS": "",
        "Ports": [
          {
            "Name": "UDP-53",
            "Protocol": "UDP",
            "Port": 53
          }
        ],
        "PodSelector": {
          "matchLabels": {
            "k8s-app": "kube-dns"
          }
        },
        "NamespaceSelector": {
          "matchLabels": {
            "kubernetes.io/metadata.name": "kube-system"
          }
        },
        "IPAddress": ""
      }
    ]
  }
}